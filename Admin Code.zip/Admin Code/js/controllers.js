// dev
var TokenStatus = {
    "Available": "JZYLXzAItW",
    "Booked": "5K1EtKrhir",
    "Serviced": "4be3BHwafe",
    "Servicing": "Klob8Odiqb",
    "Cancelled": "vkWS1kW2Uk"
}
var userTypes = [
    /*{
        "id": "7ukn8rSUhi",
        "userType": "Doctor"
    }, {
        "id": "48AOHFLgvg",
        "userType": "Patient"
        }, */
    {
        "id": "w2n6I1XAMI",
        "userType": "Admin"
    }]
var doctype = 'LZpZ395Bzj';
var admintype = 'w2n6I1XAMI';
var pnttype = "48AOHFLgvg";
//Prod userType
/*var userTypes = [
    {
        "id": "7ukn8rSUhi",
        "userType": "Doctor"
    }, {
        "id": "48AOHFLgvg",
        "userType": "Patient"
        }, 
    {
        "id": "xfwqRLljZW",
        "userType": "Admin"
    }]*/
/*var doctype = 'LZpZ395Bzj';
var admintype = 'xfwqRLljZW';
var pnttype = "48AOHFLgvg";*/
angular.module('nGageRX.controllers', [])
    .controller('AppCtrl', function ($scope, $rootScope, $ionicModal, $timeout, $state, $ionicPopup, $ionicLoading, $localstorage, $ionicHistory, $cordovaToast, ionicMaterialInk) {
        $rootScope.isDoctor = window.localStorage['isDoctor'];
        $rootScope.isPatient = window.localStorage['isPatient'];
        $rootScope.isAdmin = window.localStorage['isAdmin'];
        var currentUser = Parse.User.current();
        $rootScope.user = null;
        $rootScope.UserProfile = null;
        $rootScope.isLoggedIn = false;
        //console.log(currentUser)
        if (currentUser) {
            console.log(window.localStorage['isDoctor'])
            if (window.localStorage['isDoctor'] != undefined || window.localStorage['isPatient'] != undefined || window.localStorage['isAdmin'] != undefined) {
                $rootScope.user = currentUser;
                $rootScope.isLoggedIn = true;
                $rootScope.isDoctor = window.localStorage['isDoctor'];
                $rootScope.isPatient = window.localStorage['isPatient'];
                $rootScope.isAdmin = window.localStorage['isAdmin'];
                if ($rootScope.isDoctor == 'true') {
                    console.log('isDoctor')
                        //$state.go('tab.home');
                } else if ($rootScope.isPatient == 'true') {
                    console.log('isPatient')
                        //$state.go('tab.AdminHome');
                } else if ($rootScope.isAdmin == 'true') {
                    console.log('isAdmin')
                    $state.go('tab.AdminHome');
                }
            } else {
                Parse.User.logOut();
                $state.go('login');
            }
        } else {
            console.log('login')
            $state.go('login');
        }
        // Form data for the login modal
        $scope.loginData = {};
        // Create the login modal that we will use later
        $ionicModal.fromTemplateUrl('templates/more.html', {
            scope: $scope
        }).then(function (modal) {
            $scope.modal = modal;
        });
        $scope.dashBoard = function () {
                if ($rootScope.isDoctor == 'true') {
                    console.log('isDoctor')
                        //$state.go('tab.home');
                } else if ($rootScope.isPatient == 'true') {
                    console.log('isAdmin')
                        //$state.go('tab.AdminHome');
                } else if ($rootScope.isAdmin == 'true') {
                    console.log('isAdmin')
                    $state.go('tab.AdminHome');
                }
            }
            // Triggered in the login modal to close it
        $scope.closeLogin = function () {
            $scope.modal.hide();
        };
        // Open the login modal
        $scope.more = function () {
            $scope.modal.show();
        };
        // Show Popup     
        $rootScope.showAlert = function (msg) {
            var alertPopup = $ionicPopup.alert({
                title: 'CureBooth Admin',
                cssClass: 'cbpopup',
                template: msg
            });
            alertPopup.then(function (res) {
                console.log('Thank you');
            });
        };
        $scope.logOut = function () {
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {
                var confirmPopup = $ionicPopup.confirm({
                    title: 'CureBooth Admin',
                    template: 'Are you sure ! <br/> You want to logout?'
                });

                confirmPopup.then(function (res) {
                    if (res) {
                        //$scope.logOutfn();
                        var targetUser = new Parse.User();
                        targetUser.id = $rootScope.user.id;
                        ParsePushPlugin.getInstallationId(function (id) {
                                console.log(id)
                                var query = new Parse.Query(Parse.Installation);
                                query.equalTo('installationId', id);
                                query.equalTo('UserPointer', targetUser);
                                query.find({
                                    success: function (results) {
                                        var point = results[0];
                                        //point.set("UserPointer", targetUser);
                                        point.set("Active", false);
                                        point.save(null, {
                                            success: function (point) {
                                                //$ionicLoading.hide();
                                                $scope.logOutfn();
                                                console.log('User Pointer saved in Installation table');
                                            },
                                            error: function (point, error) {
                                                $ionicLoading.hide();
                                            }
                                        });
                                    },
                                    error: function (error) {
                                        $ionicLoading.hide();

                                        //alert("Error: " + error.code + " " + error.message);
                                    }
                                });
                            },
                            function (e) {
                                //alert('error');
                            });
                    }
                })
            }
        }
        $scope.logOutfn = function () {
            // $ionicLoading.show();
            Parse.User.logOut()
            var currentUser = Parse.User.current();
            console.log('CurrentUser : ' + currentUser)
            if (currentUser) {
                $rootScope.user = currentUser;
                $rootScope.isLoggedIn = true;
                $state.go('tab.Home');
            } else {
                $localstorage.clearAll();
                $ionicHistory.clearCache();
                $ionicHistory.clearHistory()
                $ionicLoading.hide();
                $rootScope.isDoctor = '';
                window.localStorage['isDoctor'] = '';
                $rootScope.isPatient = '';
                window.localStorage['isPatient'] = '';
                $rootScope.isAdmin = '';
                window.localStorage['isAdmin'] = '';
                $state.go("login");
                navigator.app.exitApp();

            }
        };
        ////ionicMaterialInk.displayEffect();
    })
    .controller('LoginController', function ($scope, $state, $rootScope, $ionicLoading, $ionicHistory, $ionicModal, $ionicPopup, ionicMaterialInk) {
        $scope.user = {
            username: null,
            password: null
        };

        $scope.error = {};
        $rootScope.showAlert = function (msg) {
            var alertPopup = $ionicPopup.alert({
                title: 'CureBooth Admin',
                cssClass: 'balance',
                template: msg
            });
            alertPopup.then(function (res) {
                console.log('Thank you');
            });
        };
        // logout function
        $scope.logOutfn = function () {
            // $ionicLoading.show();
            Parse.User.logOut()
            var currentUser = Parse.User.current();
            console.log('CurrentUser : ' + currentUser)
            if (currentUser) {
                $rootScope.user = currentUser;
                $rootScope.isLoggedIn = true;
                $state.go('tab.Home');
            } else {
                $localstorage.clearAll();
                $ionicHistory.clearCache();
                $ionicHistory.clearHistory()
                $ionicLoading.hide();
                $rootScope.isDoctor = '';
                window.localStorage['isDoctor'] = '';
                $rootScope.isPatient = '';
                window.localStorage['isPatient'] = '';
                $rootScope.isAdmin = '';
                window.localStorage['isAdmin'] = '';
                $state.go("login");
                navigator.app.exitApp();

            }
        };
        $scope.login = function () {
            if ($scope.user.username == null) {
                $rootScope.showAlert('Please enter User Name')

            } else if ($scope.user.password == null) {
                $rootScope.showAlert('Please enter password')
            } else {
                $scope.loading = $ionicLoading.show({
                    content: 'Logging in',
                    animation: 'fade-in',
                    showBackdrop: true,
                    maxWidth: 200,
                    showDelay: 0
                });

                var user = $scope.user;
                Parse.User.logIn(('' + user.username).toLowerCase(), user.password, {
                    success: function (user) {
                        $ionicLoading.hide();
                        $rootScope.user = user;
                        $rootScope.isLoggedIn = true;
                        $scope.user = {};
                        if (user.get('phoneVerified')) {
                            var page = '';
                            document.addEventListener("deviceready", function () {

                            }, false);
                            $scope.InstallationObj(user.id);
                            if (user.get('UserTypeObjectId') == admintype) {
                                $rootScope.isAdmin = 'true';
                                window.localStorage['isDoctor'] = 'false';
                                window.localStorage['isPatient'] = 'false';
                                window.localStorage['isAdmin'] = 'true';
                                var name = window.localStorage['isAdmin'] || 'you';
                                page = 'tab.AdminHome';
                            } else {
                                $rootScope.showAlert('invalid login parameters');
                                var targetUser = new Parse.User();
                                targetUser.id = $rootScope.user.id;
                                ParsePushPlugin.getInstallationId(function (id) {
                                        console.log(id)
                                        var query = new Parse.Query(Parse.Installation);
                                        query.equalTo('installationId', id);
                                        query.equalTo('UserPointer', targetUser);
                                        query.find({
                                            success: function (results) {
                                                var point = results[0];
                                                //point.set("UserPointer", targetUser);
                                                point.set("Active", false);
                                                point.save(null, {
                                                    success: function (point) {
                                                        //$ionicLoading.hide();
                                                        $scope.logOutfn();
                                                        console.log('User Pointer saved in Installation table');
                                                    },
                                                    error: function (point, error) {
                                                        $ionicLoading.hide();
                                                    }
                                                });
                                            },
                                            error: function (error) {
                                                $ionicLoading.hide();

                                                //alert("Error: " + error.code + " " + error.message);
                                            }
                                        });
                                    },
                                    function (e) {
                                        //alert('error');
                                    });
                            }
                            $state.go(page);

                        } else {
                            $rootScope.OTPUser = user;
                            $rootScope.resend = true;
                            $state.go('otp', {
                                clear: true
                            });
                        }
                    },
                    error: function (user, err) {
                        $ionicLoading.hide();
                        $rootScope.showAlert(err.message);
                        if (err.code === 101) {
                            $scope.error.message = 'Invalid login credentials';
                            //$rootScope.showAlert($scope.error.message);
                        } else {
                            $scope.error.message = 'An unexpected error has ' +
                                'occurred, please try again.';
                            //$rootScope.showAlert($scope.error.message);
                        }
                        $scope.$apply();
                    }

                });
            }
        };
        $scope.InstallationObj = function (userid) {
            var targetUser = new Parse.User();
            targetUser.id = userid;
            ParsePushPlugin.getInstallationId(function (id) {
                    var query = new Parse.Query(Parse.Installation);
                    query.equalTo('installationId', id);
                    query.find({
                        success: function (results) {
                            var point = results[0];
                            point.set("UserPointer", targetUser);
                            point.set("Active", true);
                            point.save(null, {
                                success: function (point) {
                                    $ionicLoading.hide();
                                    console.log('User Pointer saved in Installation table');
                                },
                                error: function (point, error) {
                                    $ionicLoading.hide();
                                }
                            });
                        },
                        error: function (error) {
                            $ionicLoading.hide();

                            //alert("Error: " + error.code + " " + error.message);
                        }
                    });
                },
                function (e) {
                    //alert('error');
                });

        }

        $scope.forgot = function () {
            $state.go('forgot');
        };
        $ionicModal.fromTemplateUrl('my-modal.html', {
            scope: $scope,
            animation: 'fade-in-up'
        }).then(function (modal) {
            $scope.modal = modal;
            console.log($scope.modal)
        });
        $scope.openModal = function () {
            $scope.modal.show();
        };
        $scope.closeModal = function () {
            $scope.modal.hide();
        };
        //Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function () {
            $scope.modal.remove();
        });

        $scope.otpsend = false;
        $scope.errormsg = false;
        $scope.Error = [];
        $scope.phonedata = {
            mobileno: '',
            userotp: ''
        }
        $scope.phoneReg = function (data) {
            console.log(data.mobileno.toString().length)
            if (!$scope.otpsend) {
                if (typeof data.mobileno === 'undefined' || data.mobileno === null) {
                    $rootScope.showAlert("Please enter Phone number");
                } else if (data.mobileno.toString().length != 10) {
                    $rootScope.showAlert("Please enter 10 digit Mobile number only");
                } else {
                    // $ionicLoading.show();
                    Parse.Cloud.run('SendOTP', {
                        mobileNo: data.mobileno
                    }, {
                        success: function (results) {
                            $ionicLoading.hide();
                            $scope.errormsg = false;
                            $scope.otpsend = true;
                        },
                        error: function (error) {
                            $ionicLoading.hide();
                            $scope.errormsg = true;
                            $scope.Error = error;
                            console.log($scope.Error)
                            $scope.$apply();
                        }
                    });
                }
            } else {
                // $ionicLoading.show();
                Parse.Cloud.run('VerifyOTP', {
                    mobileNo: data.mobileno,
                    code: data.userotp
                }, {
                    success: function (results) {
                        $ionicLoading.hide();
                        $scope.errormsg = false;
                        $rootScope.UserMobile = data.mobileno;
                        $scope.closeModal();
                        $state.go('register', {
                            clear: true
                        });


                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        $scope.errormsg = true;
                        $scope.Error = error;
                        /*$state.go('register', {
                            clear: true
                        });*/
                    }
                });
            }

        }


        //ionicMaterialInk.displayEffect();
    })
    .controller('ForgotPasswordController', function ($rootScope, $scope, $state, $ionicLoading, $ionicPopup, ionicMaterialInk) {
        $scope.user = {};
        $scope.error = {};
        $scope.state = {
            success: false
        };
        $scope.resetPass = {};


        $scope.showAlert = function (msg) {
            var alertPopup = $ionicPopup.alert({
                title: 'CureBooth Admin',
                cssClass: 'balance',
                template: msg
            });
            alertPopup.then(function (res) {
                console.log('Thank you');
            });
        };
        $scope.reset1 = function () {
            $scope.loading = $ionicLoading.show({
                content: 'Sending',
                animation: 'fade-in',
                showBackdrop: true,
                maxWidth: 200,
                showDelay: 0
            });

            /*      Parse.User.requestPasswordReset($scope.user.email, {
                      success: function () {
                          // TODO: show success
                          $ionicLoading.hide();
                          $scope.state.success = true;
                          $scope.$apply();
                      },
                      error: function (err) {
                          $ionicLoading.hide();
                          if (err.code === 125) {
                              $scope.errorr.message = 'Email address does not exist';
                              $rootScope.showAlert($scope.errorr.message);
                          } else {
                              $scope.error.message = 'An unknown error has occurred, ' +
                                  'please try again';
                              $rootScope.showAlert($scope.errorr.message);
                          }
                          $scope.$apply();
                      }
                  });*/
        };
        $scope.otpsend = false;
        $scope.reset = function (data) {
            if (typeof data.mobileNumber === 'undefined' || data.mobileNumber === null) {
                $scope.showAlert("Please enter Mobile number");
            } else if (data.mobileNumber.toString().length != 10) {
                $scope.showAlert("Please enter 10 digit Mobile number only");
            } else {
                // $ionicLoading.show();
                Parse.Cloud.run('SendSMS', {
                    mobileNo: data.mobileNumber
                }, {
                    success: function (results) {
                        $ionicLoading.hide();
                        $scope.otpsend = true;
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        $scope.showAlert(error.message);
                    }
                });
            }
        }
        $scope.resetpassword = function (data) {
            if (typeof data.OTP === 'undefined' || data.OTP === null) {
                $scope.showAlert("Please enter OTP");
            } else if (typeof data.Password === 'undefined' || data.Password === null) {
                $scope.showAlert("Please Enter Password");
            } else if (typeof data.cPassword === 'undefined' || data.cPassword === null) {
                $scope.showAlert("Please Enter Confirm Password");
            } else if (data.Password != data.cPassword) {
                $scope.showAlert("Please Enter Same Password and Confirm Password ");
            } else {
                // $ionicLoading.show();
                Parse.Cloud.run('SetForgotPassword', {
                    username: data.mobileNumber,
                    code: data.OTP,
                    password: data.Password
                }, {
                    success: function (results) {
                        $ionicLoading.hide();
                        var alertPopup = $ionicPopup.alert({
                            title: 'CureBooth Admin',
                            cssClass: 'balance',
                            template: 'Password changed Successfully !<br> Please login again'
                        });
                        alertPopup.then(function (res) {
                            $scope.login();
                        });
                    },
                    error: function (error) {
                        $scope.showAlert(error.message);
                        $ionicLoading.hide();
                    }
                });
            }
        };

        $scope.login = function () {
            $state.go('login');
        };
        //ionicMaterialInk.displayEffect();
    })
    .controller('RegisterController', function ($scope, $state, $ionicLoading, $ionicPopup, $rootScope, $http, ionicMaterialInk) {
        $scope.user = {};
        $scope.error = {};
        $scope.userTypes = userTypes;
        $scope.user.phone = parseInt($rootScope.UserMobile);
        $scope.user.CountryCode = '91';
        $scope.userTypeDoctor = false;
        $scope.userType = function (data) {
            console.log(data)
            if (data == doctype)
                $scope.userTypeDoctor = true;
            else
                $scope.userTypeDoctor = false;
        }

        $scope.Validate = function () {
            var ErrorArr = new Array();
            if (typeof $scope.user === 'undefined' || $scope.user === null)
                throw 'Basic info is not entered';
            else {
                if (typeof $scope.user.userType === 'undefined' || $scope.user.userType === null) {
                    $rootScope.showAlert("Please Select UserType");
                    ErrorArr.push('Client \'Date of Birth\' is required.');
                } else if (typeof $scope.user.fullName === 'undefined' || $scope.user.fullName === null) {
                    $rootScope.showAlert('Please enter some valid value into - Full Name.');
                    ErrorArr.push('Client \'FirstName\' is required.');
                } else if (typeof $scope.user.email === 'undefined' || $scope.user.email === null) {
                    $rootScope.showAlert('Please enter some valid value into - Email');
                    ErrorArr.push('Client \'Surname\' is required.');
                } else if (typeof $scope.user.phone === 'undefined' || $scope.user.phone === null) {
                    $rootScope.showAlert("Please enter Phone number");
                    ErrorArr.push('Client \'Date of Birth\' is required.');
                } else if ($scope.user.userType == doctype && $scope.user.MciNo === null) {
                    $rootScope.showAlert("Please enter MCI Registration Number");
                    ErrorArr.push('Client \'Date of Birth\' is required.');
                } else if (typeof $scope.user.password === 'undefined' || $scope.user.password === null) {
                    $rootScope.showAlert("Please enter Password");
                    ErrorArr.push('Client \'Date of Birth\' is required.');
                } else if (typeof $scope.user.Cpassword === 'undefined' || $scope.user.Cpassword === null) {
                    $rootScope.showAlert("Please enter Confirm Password");
                    ErrorArr.push('Client \'Date of Birth\' is required.');
                } else if ($scope.user.password != $scope.user.Cpassword) {
                    $rootScope.showAlert("Please enter same Password and Confirm Password");
                    ErrorArr.push('Client \'Date of Birth\' is required.');
                }


            }
            if (ErrorArr.length > 0)
                return false;

            return true; //_isValidVM
        }
        $scope.register = function () {
            if ($scope.Validate()) {
                $ionicLoading.show();
                var phone = $scope.user.phone;
                phone = phone.toString()
                var user = new Parse.User();
                user.set("fullName", $scope.user.fullName);
                user.set("username", phone);
                user.set("password", $scope.user.password);
                user.set("OriginalPwd", $scope.user.password);
                user.set("email", $scope.user.email);
                user.set("PhoneNumber", phone);
                user.set("phoneVerified", true);
                user.set("ExotelNumber", "0");
                user.set("UserTypeObjectId", $scope.user.userType);
                user.set("MciNo", $scope.user.MciNo);
                user.signUp(null, {
                    success: function (user) {
                        $rootScope.isLoggedIn = true;
                        // Default Profile function
                        myObject = user;
                        $scope.SetDefaultProfile(myObject.get("fullName"), myObject.get("MciNo"), myObject.get("UserTypeObjectId"));
                        // Verify the user
                        var point = myObject;
                        point.set("phoneVerified", true);
                        // Save
                        point.save(null, {
                            success: function (point) {
                                $ionicLoading.hide();
                            },
                            error: function (point, error) {
                                $ionicLoading.hide();
                            }
                        });
                        // Create user Wallet
                        $scope.InstallationObj(myObject.id);
                        var ParseWallet = new Parse.Object.extend("Wallet");
                        var objWallet = new ParseWallet();
                        objWallet.set("UserObjectId", myObject.id);
                        objWallet.set("Amount", parseFloat(0.00));
                        objWallet.save();

                        // Navigation based on usertype
                        if (myObject.get('UserTypeObjectId') == admintype) {
                            $state.go('tab.AdminHome', {
                                //clear: true
                            });
                            $rootScope.isDoctor = 'true';
                            window.localStorage['isAdmin'] = true;
                            window.localStorage['isPatient'] = 'false';
                            var name = window.localStorage['isDoctor'] || 'you';
                            console.log('Hello, ' + name);
                        } else {
                            $state.go('login', {
                                //clear: true
                            });
                        }
                    },
                    error: function (user, error) {
                        console.log(error)
                        $ionicLoading.hide();
                        if (error.code === 125) {
                            $scope.error.message = '  Please specify a valid email ' +
                                'address';
                            $rootScope.showAlert($scope.error.message);
                        } else if (error.code === 202) {
                            $scope.error.message = 'Phone Number is already registered, Please login';
                            var alertPopup = $ionicPopup.alert({
                                title: 'CureBooth Admin',
                                cssClass: 'balance',
                                template: $scope.error.message
                            });
                            alertPopup.then(function (res) {
                                $state.go('login');
                            });

                            $rootScope.showAlert($scope.error.message);
                        } else if (error.code === 203) {
                            $scope.error.message = 'Email is already registered';
                            $rootScope.showAlert($scope.error.message);
                        } else {
                            $scope.error.message = error.message;
                            $rootScope.showAlert($scope.error.message);
                        }
                        //$scope.$apply();
                    }
                });
            }
        };
        $scope.InstallationObj = function (userid) {
            var targetUser = new Parse.User();
            targetUser.id = userid;
            ParsePushPlugin.getInstallationId(function (id) {
                    var query = new Parse.Query(Parse.Installation);
                    query.equalTo('installationId', id);
                    query.find({
                        success: function (results) {
                            var point = results[0];
                            point.set("UserPointer", targetUser);
                            point.set("Active", true);
                            point.save(null, {
                                success: function (point) {
                                    $ionicLoading.hide();
                                    console.log('User Pointer saved in Installation table');
                                },
                                error: function (point, error) {
                                    $ionicLoading.hide();
                                }
                            });
                        },
                        error: function (error) {
                            $ionicLoading.hide();

                            //alert("Error: " + error.code + " " + error.message);
                        }
                    });
                },
                function (e) {
                    //alert('error');
                });

        }
        $scope.SendSMS = function (phone) {
            // $ionicLoading.show();
            Parse.Cloud.run('SendSMS', {
                mobileNo: phone
            }, {
                success: function (results) {
                    $ionicLoading.hide();
                    $state.go('otp', {
                        clear: true
                    });
                },
                error: function (error) {
                    $ionicLoading.hide();
                    // error
                }
            });
        };


        // Resend OTP SMS
        //$rootScope.resend = false;
        var currentUser = Parse.User.current();

        $scope.ReSendSMS = function () {
            if ($rootScope.OTPUser != null) {
                $rootScope.resend = true;
                $scope.SendSMS($rootScope.OTPUser.get('PhoneNumber'))

            } else {
                $scope.SendSMS(phone);
            }

        }


        $scope.SetDefaultProfile = function (name, mci, id) {
            // $ionicLoading.show();
            Parse.Cloud.run('SetDefaultProfile', {
                FirstName: name,
                MciNo: mci,
                UserTypeObjectId: id
            }, {
                success: function (results) {
                    $ionicLoading.hide();
                },
                error: function (error) {
                    $ionicLoading.hide();
                    // error
                }
            });
        };
        $scope.checkOtp = function () {
                console.log($scope.user.otp)
                if ($scope.user.otp) {
                    myObject = $rootScope.user;
                    myObject.fetch({
                        success: function (myObject) {
                            if (myObject.get("OTP") == $scope.user.otp) {
                                // Default Profile function
                                $scope.SetDefaultProfile(myObject.get("fullName"), myObject.get("UserTypeObjectId"));
                                // Verify the user
                                var point = myObject;
                                point.set("phoneVerified", true);
                                // Save
                                point.save(null, {
                                    success: function (point) {
                                        $ionicLoading.hide();
                                    },
                                    error: function (point, error) {
                                        $ionicLoading.hide();
                                    }
                                });
                                // Create user Wallet
                                var ParseWallet = new Parse.Object.extend("Wallet");
                                var objWallet = new ParseWallet();
                                objWallet.set("UserObjectId", myObject.id);
                                objWallet.set("Amount", parseFloat(0.00));
                                objWallet.save();

                                // Navigation based on usertype
                                if (myObject.get('UserTypeObjectId') == doctype) {
                                    $state.go('tab.home', {
                                        clear: true
                                    });
                                    $rootScope.isDoctor = 'true';
                                    window.localStorage['isDoctor'] = true;
                                    window.localStorage['isPatient'] = 'false';
                                    var name = window.localStorage['isDoctor'] || 'you';
                                    console.log('Hello, ' + name);
                                } else if (myObject.get('UserTypeObjectId') == pnttype) {
                                    $state.go('tab.PatientHome', {
                                        clear: true
                                    });
                                    $rootScope.isPatient = 'true';
                                    window.localStorage['isDoctor'] = 'false';
                                    window.localStorage['isPatient'] = 'true';
                                    var name = window.localStorage['isPatient'] || 'you';
                                    console.log('Hello, ' + name);
                                }
                            } else {
                                $rootScope.resend = true;
                                $rootScope.showAlert("Please enter correct OTP");
                            }
                        },
                        error: function (myObject, error) {
                            // The object was not refreshed successfully.
                            // error is a Parse.Error with an error code and message.
                        }
                    });
                }

            }
            //ionicMaterialInk.displayEffect();
    })
    .controller('HomeCtrl', function ($scope, $http, $rootScope, $ionicModal, $ionicPopup, $ionicHistory, $ionicScrollDelegate, $state, $ionicLoading, $localstorage, $cordovaToast, ionicMaterialInk) {
        /* var req = {
             method: 'POST',
             url: 'https://www.payumoney.com/payment/op/getPaymentResponse?merchantkey=5357137&merchantTransactionIds=qw96102427141',
             headers: {
                 "Content-Type": "application/json",
                 "Authorization": "F4/XvYSYwl4HOwql15F73gzEbcO1DCTURYwDjtn1w40="
             }
         }
         $http(req).then(function () {}, function () {});
         $http({
             method: 'POST',
             url: 'https://www.payumoney.com/payment/op/getPaymentResponse',
             data: 'merchantkey=5357137&merchantTransactionIds=qw96102427141',
             headers: {
                 "Content-Type": "application/x-www-form-urlencoded",
                 "Authorization": "F4/XvYSYwl4HOwql15F73gzEbcO1DCTURYwDjtn1w40="
             }
         }).then(function (response) {
             if (response.data == 'ok') {
                 // success
             } else {
                 // failed
             }
         });yx7*/
        $scope.selectedDiv = 'Patient';
        $rootScope.profile = '';
        $scope.Status = {
            statusType: ''
        }
        if (window.ParsePushPlugin) {
            ParsePushPlugin.on('receivePN', function (pn) {
                //alert('yo i got this push notification:' + JSON.stringify(pn));
            });
            ParsePushPlugin.on('openPN', function (pn) {
                //you can do things like navigating to a different view here
                console.log(JSON.stringify(pn));
                console.log('Yo, I get this when the user clicks open a notification from the tray');
                if (pn.type == 1) {
                    $scope.selectedDiv = 'Patient';
                }
                if (pn.type == 2) {
                    $scope.selectedDiv = 'Call';
                }
                if (pn.type == 3) {
                    $scope.selectedDiv = 'Message';
                }
                /* if(pn.type==4){
                      $state.go('tab.wallet');
                 }*/
            });
            //
            //you can also listen to your own custom subevents
            //
            //ParsePushPlugin.on('receivePN:chat', chatEventHandler);
            //ParsePushPlugin.on('receivePN:serverMaintenance', serverMaintenanceHandler);
        }
        $ionicHistory.clearHistory()
        $scope.showTabCantent = function (option) {
            $scope.selectedDiv = option; //'Client';
            $ionicScrollDelegate.scrollTop();
        }

        // View Patient
        $scope.ViewPatient = function (item) {
            $rootScope.PtData = item;
            $state.go('tab.DrPatientHome');
        }
        $scope.chat = function (item) {
            $rootScope.chatUser = item;
            $rootScope.chatArchived = item.IsArchive;
            //console.log($rootScope.chatUser.get('PatientProfileObjectId').get('ProfileImage').url())

        }
        $scope.ViewProfile = function () {
                $state.go('tab.profile');
            }
            // list of status
        $scope.getStatusType = function () {
                if ($localstorage.getObject('StatusType') === null) {
                    // $ionicLoading.show();
                }
                var query = new Parse.Query('StatusType');
                query.find({
                    success: function (results) {
                        $ionicLoading.hide();
                        //$scope.StatusType = results
                        $localstorage.setObject('StatusType', results);
                        $scope.StatusType = $localstorage.getObject('StatusType');
                        $scope.$apply();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        if (error.code == 209)
                            $state.go('login');
                        //alert("Error: " + error.code + " " + error.message);
                    }
                });
            }
            // User current status no need of it
        $scope.getStatus = function () {
                if ($localstorage.getObject('StatusName') === null) {}
                // $ionicLoading.show();

                var query = new Parse.Query('UserStatus');
                query.equalTo('UserId', $rootScope.user.id);
                query.find({
                    success: function (results) {
                        if (results.length > 0) {
                            console.log(results[0].get('StatusName'));
                            $ionicLoading.hide();
                            $scope.Status.statusType = results[0].get('StatusName')
                                //alert(object.id + ' - ' + object.get('playerName'));
                        }
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        //alert("Error: " + error.code + " " + error.message);
                    }
                });
            }
            // Dr Patient list
        $scope.PatientListfn = function (id) {
            Parse.Cloud.run('PatientList', {
                DoctorProfileId: id //'PRpuqlmbtC'
            }, {
                success: function (status) {
                    /*  if (status.length > 0) {
                          $localstorage.setObject('DoctorPatientList', status);
                          $scope.PatientList = $localstorage.getObject('DoctorPatientList');
                          $scope.$apply();
                      }*/
                    if (status.length > 0) {
                        $scope.DoctorList1 = [];
                        for (i = 0; i < status.length; i++) {
                            var ProfileImage;
                            if (status[i].get('PatientProfileObjectId').get('ProfileImage') != undefined) {
                                ProfileImage = status[i].get('PatientProfileObjectId').get('ProfileImage').url();
                            } else {
                                ProfileImage = "img/patient_icon_default.png";
                            }
                            var temp = {
                                    chatThreadId: status[i].attributes.chatThreadId,
                                    UserObjectId: status[i].attributes.PatientUserObjectId,
                                    id: status[i].attributes.PatientProfileObjectId.id,
                                    DoctorUserObjectId: status[i].attributes.DoctorUserObjectId,
                                    IsFollowed: status[i].attributes.IsFollowed,
                                    IsPriority: status[i].attributes.IsPriority,
                                    IsVerfied: status[i].attributes.IsVerfied,
                                    FirstName: status[i].attributes.PatientProfileObjectId.attributes.FirstName,
                                    FullName: status[i].attributes.PatientProfileObjectId.attributes.FullName,
                                    LastName: status[i].attributes.PatientProfileObjectId.attributes.LastName,
                                    Phone: status[i].attributes.PatientProfileObjectId.attributes.Phone,
                                    Health_Summary: status[i].attributes.PatientProfileObjectId.attributes.Health_Summary,
                                    Address: status[i].attributes.PatientProfileObjectId.attributes.Address,
                                    ProfileImage: ProfileImage,
                                    ProfileLinkId: status[i].id,
                                    isMute: status[i].attributes.DoctorMuted
                                }
                                // console.log(temp)
                            $scope.DoctorList1.push(temp);
                        }
                        $localstorage.setObject('DoctorPatientList', $scope.DoctorList1);
                        $scope.PatientList = $localstorage.getObject('DoctorPatientList');
                        $scope.$apply();
                    } else
                        $scope.PatientList = '';
                },
                error: function (error) {

                }
            });
        }
        $scope.chatListfn = function (id) {
                Parse.Cloud.run('ChatList', {
                    ProfileId: id,
                    IsDoctor: 1
                }, {
                    success: function (status) {
                        if (status.length > 0) {
                            //$scope.ChatList = status
                            /* $localstorage.setObject('DoctorChatList', status);
                             $scope.ChatList = $localstorage.getObject('DoctorChatList');
                             $scope.$apply();*/
                            $scope.ChatList1 = [];
                            for (i = 0; i < status.length; i++) {
                                var ProfileImage;
                                if (status[i].get('PatientProfileObjectId').get('ProfileImage') != undefined) {
                                    ProfileImage = status[i].get('PatientProfileObjectId').get('ProfileImage').url();
                                } else {
                                    ProfileImage = "img/patient_icon_default.png";
                                }
                                var RecentMsg;
                                if (status[i].get('RecentMsg') != undefined) {
                                    RecentMsg = status[i].get('RecentMsg').get('message');
                                    RecentMsgtime = status[i].get('RecentMsg').get('createdAt');
                                } else {
                                    RecentMsg = "";
                                    RecentMsgtime = ''
                                }
                                var temp = {
                                    chatThreadId: status[i].attributes.chatThreadId,
                                    UserObjectId: status[i].attributes.PatientUserObjectId,
                                    id: status[i].attributes.PatientProfileObjectId.id,
                                    DoctorUserObjectId: status[i].attributes.DoctorUserObjectId,
                                    IsFollowed: status[i].attributes.IsFollowed,
                                    IsPriority: status[i].attributes.IsPriority,
                                    IsVerfied: status[i].attributes.IsVerfied,
                                    FirstName: status[i].attributes.PatientProfileObjectId.attributes.FirstName,
                                    FullName: status[i].attributes.PatientProfileObjectId.attributes.FullName,
                                    LastName: status[i].attributes.PatientProfileObjectId.attributes.LastName,
                                    Phone: status[i].attributes.PatientProfileObjectId.attributes.Phone,
                                    Health_Summary: status[i].attributes.PatientProfileObjectId.attributes.Health_Summary,
                                    Address: status[i].attributes.PatientProfileObjectId.attributes.Address,
                                    ProfileImage: ProfileImage,
                                    RecentMsg: RecentMsg,
                                    RecentMsgtime: RecentMsgtime,
                                    ProfileLinkId: status[i].id,
                                    isMute: status[i].attributes.DoctorMuted
                                }
                                $scope.ChatList1.push(temp);
                            }
                            $localstorage.setObject('DoctorChatList', $scope.ChatList1);
                            $scope.ChatList = $localstorage.getObject('DoctorChatList');
                            $scope.$apply();
                        }
                    },
                    error: function (error) {
                        // debugger;
                        // error
                    }
                });
            }
            //PatientRequestCount
        $scope.PatientRequestCount = function (id) {
                Parse.Cloud.run('PatientRequestCount', {
                    ProfileId: id
                }, {
                    success: function (status) {
                        if (status != 0)
                            $scope.RequestCount = status
                            //console.log($scope.RequestCount)
                    },
                    error: function (error) {
                        // debugger;
                        // error
                    }
                });
            }
            //BroadcastChat
        $scope.BroadcastChat = function (msg) {
            Parse.Cloud.run('BroadcastChat', {
                message: msg
            }, {
                success: function (status) {
                    $scope.rechargeAmount.msg = '';
                    $scope.closeRechargeModal();
                    $cordovaToast.show('Broadcast message sent successfully', 'short', 'center')
                },
                error: function (error) {
                    // debugger;
                    // error
                }
            });
        }
        $scope.rechargeAmount = [];
        $scope.showaddmoney = function () {
                $scope.Recharge = true;
                $scope.Rechargebtn = true;
                $scope.openRechargeModal();
                //
            }
            /* $ionicModal.fromTemplateUrl('my-modal.html', {
                 scope: $scope,
                 animation: 'fade-in-up'
             }).then(function (modal) {
                 $scope.MsgModal = modal;
             });*/
        $scope.MsgModal = $ionicModal.fromTemplate('<ion-modal-view class="signup"><ion-header-bar class="bar bar-stable fix-buttons"><button class="button  bar bar-stable" ng-click="closeRechargeModal()" style="max-width: 100px; padding: 5px 10px; min-width: 80px; box-shadow: none;">Cancel</button><h1 class="title">Broadcast Message</h1></ion-header-bar><ion-content><div class="card" style="padding: 5px 10px 0;"><ion-input class="item item-input  item-floating-label"><ion-label>Enter Broadcast Message</ion-label> <input type="text" placeholder="Enter Broadcast Message" ng-model="rechargeAmount.msg"></ion-input><button ng-disabled="!rechargeAmount.msg" class="button button-full button-outline button-positive" ng-click="showaddMoneyfn()" style="color: rgb(255, 255, 255); background: rgb(0, 189, 189) none repeat scroll 0% 0%; box-shadow: none;">  Submit</button></div></ion-content></ion-modal-view>', {
            scope: $scope,
            animation: 'slide-in-up'
        });
        $scope.openRechargeModal = function () {
            if ($rootScope.NetworkStatus)
                $scope.MsgModal.show();
            else
                $cordovaToast.show('no connection available', 'short', 'center')

        };
        $scope.closeRechargeModal = function () {
            $scope.MsgModal.hide();
        };
        //Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function () {
            $scope.MsgModal.remove();
        });
        $scope.showaddMoneyfn = function () {
            if ($scope.rechargeAmount.msg != undefined && $scope.rechargeAmount.msg != null) {

                var confirmPopup = $ionicPopup.confirm({
                    title: 'CureBooth Admin',
                    template: 'Broadcast Message to your Patients ?'
                });
                confirmPopup.then(function (res) {
                    if (res) {
                        $scope.BroadcastChat($scope.rechargeAmount.msg);
                    }
                });

            } else {
                $rootScope.showAlert('Please enter Broadcast Message.');
            }
        };
        // Call History Funtion 
        $scope.callhistoryfn = function (id) {
            if ($localstorage.getObject('Doctorcalllist') === null) {} // $ionicLoading.show();

            Parse.Cloud.run('GetCallHistory', {
                UserProfileId: id
            }, {
                success: function (results) {
                    $ionicLoading.hide();
                    $scope.calllist1 = [] // results;
                    for (i = 0; i < results.length; i++) {
                        if ($rootScope.user.id == results[i].get("ToProfileObjectId").get("UserObjectId")) {
                            results[i]['Incoming'] = true
                            $scope.calllist1.push(results[i]);
                        } else if ($rootScope.user.id == results[i].get("FromProfileObjectId").get("UserObjectId")) {
                            results[i]['Incoming'] = false
                            $scope.calllist1.push(results[i]);
                        }
                    }
                    //console.log($scope.calllist1)
                    $localstorage.setObject('Doctorcalllist', $scope.calllist1);
                    $scope.calllist = $localstorage.getObject('Doctorcalllist');
                    //console.log($scope.calllist)
                    $scope.$apply();
                },
                error: function (error) {
                    $ionicLoading.hide();
                    // error
                }
            });
        };

        // Change user status

        $scope.status = function () {
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {
                Parse.Cloud.run('ProfileStatus', {
                    StatusObjectId: $scope.Status.id,
                    ProfileId: $rootScope.user.ProfileId
                }, {
                    success: function (status) {
                        $ionicLoading.hide();
                        $cordovaToast.show('Status Updated Successfully', 'short', 'center')
                            .then(function (success) {
                                // success
                            }, function (error) {
                                // error
                            });
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        $rootScope.showAlert(error);
                    }
                });
            }
        }
        $scope.getProfile = function () {
            if ($localstorage.getObject('DoctorProfile') === null) {} // $ionicLoading.show();


            Parse.Cloud.run('GetProfile', {
                UserObjectId: $rootScope.user.id,
            }, {
                success: function (results) {
                    $ionicLoading.hide();
                    if (results != undefined && results != null) {
                        $scope.PatientListfn(results.id);
                        $scope.PatientRequestCount(results.id)
                        $scope.callhistoryfn(results.id);
                        $scope.chatListfn(results.id);
                        $rootScope.user.ProfileId = results.id;
                        //$rootScope.UserProfile = results;
                        $rootScope.UserName = results.get('FullName')
                        $scope.FirstName = results.get('FirstName');
                        $scope.LastName = (results.get('LastName') == undefined) ? '' : results.get('LastName');
                        if (typeof results.attributes.StatusPointer !== 'undefined' && results.attributes.StatusPointer != null)
                            $scope.Status.id = results.get('StatusPointer').id;
                        if (typeof results.attributes.ProfileImage === 'undefined') {
                            //console.log(results.get('ProfileImage'))
                            $rootScope.ProfileImage = "img/doctor_icon_default.png";
                        } else
                            $rootScope.ProfileImage = results.get('ProfileImage').url();

                        $localstorage.setObject('DoctorProfile', results);
                        $rootScope.UserProfile = $localstorage.getObject('DoctorProfile')
                        $scope.$apply();
                    }
                },
                error: function (error) {
                    $ionicLoading.hide();
                    if (error.code == 209)
                        $state.go('login');
                    //$rootScope.showAlert(error);
                }
            });
        }

        var currentUser = Parse.User.current();
        $rootScope.user = null;
        $rootScope.UserProfile = null;
        $rootScope.isLoggedIn = false;
        //console.log(currentUser)
        if (currentUser) {
            console.log(window.localStorage['isDoctor'])
            if (window.localStorage['isDoctor'] != undefined || window.localStorage['isPatient'] != undefined) {
                $rootScope.user = currentUser;
                $rootScope.isLoggedIn = true;
                $rootScope.isDoctor = window.localStorage['isDoctor'];
                $rootScope.isPatient = window.localStorage['isPatient'];
                $rootScope.isAdmin = window.localStorage['isAdmin'];
                if ($rootScope.isDoctor == 'true') {
                    console.log('isDoctor' + $rootScope.NetworkStatus)
                    if ($rootScope.NetworkStatus) {
                        $scope.StatusType = $localstorage.getObject('StatusType');
                        $scope.PatientList = $localstorage.getObject('DoctorPatientList');
                        $scope.ChatList = $localstorage.getObject('DoctorChatList');
                        $scope.calllist = $localstorage.getObject('Doctorcalllist');
                        $rootScope.UserProfile = $localstorage.getObject('DoctorProfile')
                        $scope.getProfile();
                        $scope.getStatusType();
                    } else {
                        $scope.StatusType = $localstorage.getObject('StatusType');
                        $scope.PatientList = $localstorage.getObject('DoctorPatientList');
                        $scope.ChatList = $localstorage.getObject('DoctorChatList');
                        $scope.calllist = $localstorage.getObject('Doctorcalllist');
                        $rootScope.UserProfile = $localstorage.getObject('DoctorProfile')
                    }

                } else if ($rootScope.isPatient == 'true') {
                    console.log('isPatient')
                    $state.go('tab.PatientHome');
                } else if ($rootScope.isAdmin == 'true') {
                    console.log('isAdmin')
                    $state.go('tab.AdminHome');
                }
            } else {
                Parse.User.logOut();
                $state.go('login');
            }
        } else {
            console.log('login')
            $state.go('login');
        }

        //$scope.getStatus();
        //ionicMaterialInk.displayEffect();
    })
    .controller('DrPatientHomeCtrl', function ($scope, $state, $ionicLoading, $ionicPopup, $ionicModal, $cordovaToast, $rootScope, $http, $ionicScrollDelegate, ionicMaterialInk) {
        $scope.selectedDiv = 'Call'
        $scope.showTabCantent = function (option) {
            $scope.selectedDiv = option; //'Client';
            $ionicScrollDelegate.scrollTop();
        }
        $scope.calllist = []
        $scope.PtDrProfile = [];
        results = $rootScope.PtData;
        $scope.PtDrProfile.id = results.id;
        $scope.PtDrProfile.FullName = results.FullName;
        $scope.PtDrProfile.ObjectId = results.UserObjectId;
        $scope.PtDrProfile.ProfileId = results.id;
        $scope.PtDrProfile.PriorityPatient = $rootScope.PtData.IsPriority; //attributes.IsPriority;
        $scope.PtDrProfile.IsArchive = $rootScope.PtData.IsArchive;
        $scope.PtDrProfile.ProfileImage = results.ProfileImage;
        $scope.PtDrProfile.chatThreadId = $rootScope.PtData.chatThreadId;
        $scope.PtDrProfile.UserObjectId = results.UserObjectId;
        $scope.PtDrProfile.isMute = results.DoctorMuted
            /*  console.log($rootScope.user.ProfileId);
              console.log('PriorityPatient ' + $scope.PtDrProfile.PriorityPatient)
              if (results.ProfileImage != undefined)
                  $scope.PtDrProfile.ProfileImage = results.ProfileImage;
              else
                  $scope.PtDrProfile.ProfileImage = "img/doctor_icon_default.png";*/
            /* $scope.DrProfile.BriefOverview = results.get('BriefOverview');
             $scope.DrProfile.Qualification = results.get('Qualification');
             $scope.DrProfile.Speciality = results.get('Speciality');
             $scope.DrProfile.Clinic = results.get('Clinic');*/
            // 
        $scope.chat = function (item) {
            $rootScope.chatUser = item //results.get('DoctorProfileObjectId');
                //console.log($rootScope.chatUser.get('PatientProfileObjectId').get('ProfileImage').url())

        }
        $scope.AddWallet = function (amt) {
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {
                // $ionicLoading.show();
                Parse.Cloud.run('AddWallet', {
                    FromUserId: $rootScope.user.id,
                    ToUserId: results.UserObjectId,
                    Amount: amt,
                    FromProfileObjectId: $rootScope.user.ProfileId,
                    ToProfileObjectId: results.id
                }, {
                    success: function (status) {
                        // debugger;
                        $ionicLoading.hide();
                        $scope.Recharge = false;
                        $scope.Rechargebtn = false;
                        $scope.closeRechargeModal();
                        $scope.rechargeAmount.amount = '';
                        //$rootScope.showAlert('Amount added successfully in Patient wallet');
                        // te Profile table updated successfully
                        $cordovaToast.show("Health Credits added successfully to Patient's Account", 'short', 'center')
                            .then(function (success) {
                                // success
                            }, function (error) {
                                // error
                            });
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        $rootScope.showAlert(error.message);
                        // debugger;
                        // error
                    }
                });
            }
        }
        $scope.SetArchivePatient = function (amt) {
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {
                // $ionicLoading.show();
                Parse.Cloud.run('SetArchivePatient', {
                    //DocProfileId: $rootScope.user.ProfileId,
                    IsArchive: amt,
                    PatientUserId: $scope.PtDrProfile.ObjectId
                }, {
                    success: function (status) {
                        $ionicLoading.hide();
                        var msg = '';
                        if (status.get('IsArchive')) {
                            msg = 'Patient ' + $scope.PtDrProfile.FullName + ' is blocked successfully'
                        } else {
                            msg = 'Patient ' + $scope.PtDrProfile.FullName + ' is unblocked successfully'

                        }
                        $cordovaToast.show(msg, 'short', 'center')
                            .then(function (success) {
                                // success
                            }, function (error) {
                                // error
                            });
                        // $rootScope.showAlert('patient priority updated');
                        // te Profile table updated successfully
                    },
                    error: function (error) {
                        console.log(error)
                        $ionicLoading.hide();
                        $rootScope.showAlert(error.message);
                        // debugger;
                        // error
                    }
                });
            }
        }
        $scope.SetPatientPriority = function (amt) {
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {
                // $ionicLoading.show();
                Parse.Cloud.run('SetPatientPriority', {
                    DocProfileId: $rootScope.user.ProfileId,
                    IsPriority: amt,
                    PatProfileId: results.id
                }, {
                    success: function (status) {
                        $ionicLoading.hide();
                        // $rootScope.showAlert('patient priority updated');
                        // te Profile table updated successfully
                        if (status.get('IsPriority')) {
                            $cordovaToast.show('Patient ' + $scope.PtDrProfile.FullName + ' is a priority patient now', 'short', 'center')
                        } else {
                            $cordovaToast.show('Patient ' + $scope.PtDrProfile.FullName + ' is not a priority patient now', 'short', 'center')
                        }
                    },
                    error: function (error) {
                        console.log(error)
                        $ionicLoading.hide();
                        $rootScope.showAlert(error.message);
                        // debugger;
                        // error
                    }
                });
            }
        }
        $scope.Recharge = false;
        $scope.Rechargebtn = false;
        $scope.rechargeAmount = [];
        $scope.showaddmoney = function () {
            $scope.Recharge = true;
            $scope.Rechargebtn = true;
            $scope.openRechargeModal();
        }
        $ionicModal.fromTemplateUrl('recharge-Patient.html', {
            scope: $scope,
            animation: 'fade-in-up'
        }).then(function (modal) {
            $scope.rechargeModal = modal;
        });
        $scope.openRechargeModal = function () {
            if ($rootScope.NetworkStatus)
                $scope.rechargeModal.show();
            else
                $cordovaToast.show('no connection available', 'short', 'center')

        };
        $scope.closeRechargeModal = function () {
            $scope.rechargeModal.hide();
        };
        //Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function () {
            $scope.rechargeModal.remove();
        });
        $scope.showaddMoneyfn = function () {
            if ($scope.rechargeAmount.amount != undefined || $scope.rechargeAmount.amount != null) {
                var confirmPopup = $ionicPopup.confirm({
                    title: 'CureBooth Admin',
                    template: 'Add Health Credits ' + $scope.rechargeAmount.amount + ' ?'
                });
                confirmPopup.then(function (res) {
                    if (res) {
                        $scope.AddWallet($scope.rechargeAmount.amount);
                    }
                });
            } else {
                $rootScope.showAlert('Please enter Health Credits.');
            }
            // An elaborate, custom popup
            /*           var myPopup = $ionicPopup.show({
                           template: '<input type="number" ng-model="data.wifi">',
                           title: 'Enter amount to add in Patient Wallet',
                           scope: $scope,
                           buttons: [
                               {
                                   text: 'Cancel'
                               },
                               {
                                   text: '<b>Add</b>',
                                   type: 'button-positive',
                                   onTap: function (e) {
                                       if (!$scope.data.wifi) {
                                           //don't allow the user to close unless he enters wifi password
                                           e.preventDefault();
                                       } else {
                                           $scope.AddWallet($scope.data.wifi);
                                           return $scope.data.wifi;
                                       }
                                   }
                 }
               ]
                       });

                       myPopup.then(function (res) {
                           console.log('Tapped!', res);
                       });*/
        };
    })
    .controller('ProfileCtrl', function ($scope, $state, $ionicPopup, $ionicLoading, $rootScope, $http, $ionicModal, $cordovaCamera, $ionicScrollDelegate, ionicMaterialInk, $cordovaToast, $filter, $localstorage) {
        //console.log(Parse.User.current().getEmail())
        $scope.profile = {};
        $scope.selectedDiv = 'Profile';
        $scope.showTabCantent = function (option) {
            $scope.selectedDiv = option; //'Client';
            $ionicScrollDelegate.scrollTop();
        }
        $scope.GetDoctorSpeciality = function () {
            if (!$rootScope.NetworkStatus) {} else {
                if ($localstorage.getObject('DoctorSpeciality') === null) {} // $ionicLoading.show();
                Parse.Cloud.run('GetDocSpeciality', {
                    //SearchString: search
                }, {
                    success: function (status) {

                        if (status.length > 0) {
                            $scope.searchList = [];
                            $localstorage.setObject('DoctorSpeciality', status)
                            $scope.DoctorSpeciality = $localstorage.getObject('DoctorSpeciality')
                                //$scope.searchList = JSON.stringify(status);
                            $scope.$apply;
                        }

                        $ionicLoading.hide();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                    }
                });
            }
        };
        /*      $scope.GetDoctorSpeciality = function () {
                  if (!$rootScope.NetworkStatus) {} else {
                      // $ionicLoading.show();
                      Parse.Cloud.run('GetDocSpeciality', {
                          //SearchString: search
                      }, {
                          success: function (status) {

                              if (status.length > 0) {
                                  $scope.searchList = [];
                                  $localstorage.setObject('DoctorSpeciality', status)
                                  $scope.DoctorSpeciality = $localstorage.getObject('DoctorSpeciality')
                                      //$scope.searchList = JSON.stringify(status);
                                  $scope.$apply;
                              }

                              $ionicLoading.hide();
                          },
                          error: function (error) {
                              $ionicLoading.hide();
                          }
                      });
                  }
              };*/

        $scope.editable = true;
        $scope.edit = function (id) {
                if ($rootScope.NetworkStatus) {
                    $scope.editable = id;
                    //$scope.profile.SpecialityId = $filter('filter')($scope.DoctorSpeciality, $scope.profile.Speciality)[0].objectId
                    console.log($scope.profile.SpecialityId)
                    $scope.$apply;
                } else
                    $cordovaToast.show('no connection available', 'short', 'center')
            }
            // To retirve dat form table
            /*$scope.getProfile = function () {
                //$ionicLoading.show();
                var query = new Parse.Query('Profile');
                query.equalTo('UserObjectId', $rootScope.user.id);
                query.equalTo('IsParent', true);
                query.include('Specialist')
                query.include('UserPointer')
                query.find({
                    success: function (results) {
                        $ionicLoading.hide();
                        if (results.length > 0) {
                            $rootScope.profile.result = results;
                            $scope.UserProfile = results[0];
                            $scope.profile.FullName = results[0].get('FullName');
                            $scope.profile.BriefOverview = results[0].get('BriefOverview');
                            $scope.profile.Qualification = results[0].get('Qualification');
                            $scope.profile.Speciality = results[0].get('Specialist').get('Speciality');
                            $scope.profile.Clinic = results[0].get('Clinic');
                            if (typeof results[0].attributes.ProfileImage === 'undefined') {
                                //console.log(results.get('ProfileImage'))
                                $rootScope.ProfileImage = "img/doctor_icon_default.png";
                            } else
                                $rootScope.ProfileImage = results[0].get('ProfileImage').url();
                            if (typeof results[0].attributes.PinCode === 'undefined') {
                                $scope.profile.PinCode = $rootScope.PinCode
                            } else
                                $scope.profile.PinCode = results[0].get('PinCode');

                            $scope.profile.MciNo = results[0].get('MciNo');
                        } else {
                            $scope.profile.result = null;
                            $scope.profile.PinCode = $rootScope.PinCode

                        }
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        //alert("Error: " + error.code + " " + error.message);
                    }
                });
            }*/
        $scope.getProfile = function () {
                if ($localstorage.getObject('DoctorProfile') === null) {} // $ionicLoading.show();


                Parse.Cloud.run('GetProfile', {
                    UserObjectId: $rootScope.user.id,
                }, {
                    success: function (results) {
                        $ionicLoading.hide();
                        if (results != undefined && results != null) {
                            $rootScope.profile.result = results;
                            $scope.UserProfile = results;
                            $scope.profile.FullName = results.get('FullName');
                            $scope.profile.BriefOverview = results.get('BriefOverview');
                            $scope.profile.Qualification = results.get('Qualification');
                            $scope.profile.Clinic = results.get('Clinic');
                            if (typeof results.attributes.ProfileImage === 'undefined') {
                                //console.log(results.get('ProfileImage'))
                                $rootScope.ProfileImage = "img/doctor_icon_default.png";
                            } else
                                $rootScope.ProfileImage = results.get('ProfileImage').url();
                            if (typeof results.attributes.PinCode === 'undefined') {
                                $scope.profile.PinCode = $rootScope.PinCode
                            } else
                                $scope.profile.PinCode = results.get('PinCode');
                            $scope.profile.CbNo = results.get('UserPointer').get('ExotelNumber');
                            $scope.profile.MciNo = results.get('MciNo');
                            $scope.$apply();
                        } else {
                            $scope.profile.result = null;
                            $scope.profile.PinCode = $rootScope.PinCode

                        }
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        if (error.code == 209)
                            $state.go('login');
                        //$rootScope.showAlert(error);
                    }
                });
            }
            // to upload data to cloud code for updating table

        $scope.updateProfile = function () {
            // $ionicLoading.show();
            if (!$rootScope.NetworkStatus) {} else {
                // $ionicLoading.show();
                if ($scope.profile.PinCode.length < 4) {
                    $rootScope.showAlert("Please enter Pincode");
                    //ErrorArr.push('Client \'Date of Birth\' is required.');
                } else {
                    Parse.Cloud.run('UpdateProfile', {
                        ProfileObjectId: $scope.UserProfile.id,
                        FullName: $scope.profile.FullName,
                        /*LastName: $scope.profile.LastName,*/
                        BriefOverview: $scope.profile.BriefOverview,
                        //SpecialityId: $scope.profile.SpecialityId,
                        Qualification: $scope.profile.Qualification,
                        Clinic: $scope.profile.Clinic,
                        Pincode: $scope.profile.PinCode,
                        MciNo: $scope.profile.MciNo,
                        LatLong: $rootScope.Currentlatlng
                    }, {
                        success: function (results) {
                            if (results) {
                                $scope.searchList = [];
                                $scope.edit(true);
                                $cordovaToast.show('Profile Updated Successfully', 'short', 'center')
                                $rootScope.profile.result = results;
                                $scope.UserProfile = results;
                                $scope.profile.FullName = results.get('FullName');
                                $scope.profile.BriefOverview = results.get('BriefOverview');
                                $scope.profile.Qualification = results.get('Qualification');
                                $scope.profile.Speciality = results.get('Specialist').get('Speciality');
                                $scope.profile.Clinic = results.get('Clinic');
                                if (typeof results.attributes.ProfileImage === 'undefined') {
                                    $rootScope.ProfileImage = "img/doctor_icon_default.png";
                                } else
                                    $rootScope.ProfileImage = results.get('ProfileImage').url();
                                if (typeof results.attributes.PinCode === 'undefined') {
                                    $scope.profile.PinCode = $rootScope.PinCode
                                } else
                                    $scope.profile.PinCode = results.get('PinCode');

                                $scope.profile.MciNo = results.get('MciNo');
                            } else {
                                $scope.profile.result = null;
                                $scope.profile.PinCode = $rootScope.PinCode

                            }
                            $scope.$apply;
                        },
                        error: function (error) {
                            $ionicLoading.hide();
                        }
                    });
                }
            }
            /*var point = $scope.UserProfile;
            point.set("FullName", $scope.profile.FirstName + ' ' + $scope.profile.LastName)
            point.set("FirstName", $scope.profile.FirstName);
            point.set("LastName", $scope.profile.LastName);
            point.set("BriefOverview", $scope.profile.BriefOverview);
            point.set("Qualification", $scope.profile.Qualification);
            point.set("Speciality", $scope.profile.Speciality);
            point.set("Clinic", $scope.profile.Clinic);
            point.set("PinCode", $scope.profile.PinCode);
            point.set("LatLong", $scope.profile.Clinic);
            point.set("UserTypeObjectId", doctype);

            var Specility = new Parse.Object.extend('DoctorSpeciality');
            var docSpec = new Speciality();
            Speciality.id = $scope.profile.Speciality;
            point.set("Specialist", docSpec);
            // Save
            point.save(null, {
                success: function (point) {
                    $ionicLoading.hide();
                    $scope.editable = true;
                    $rootScope.showAlert('Profile Saved successfully.');
                    // Saved successfully.
                },
                error: function (point, error) {
                    $ionicLoading.hide();
                    $rootScope.showAlert(error);
                }
            });*/
        }
        $scope.imageData = "";


        // Upload Image
        $scope.uploadImg = function () {
            // $ionicLoading.show();
            var ProfileParse = $scope.UserProfile;
            var objProfileLink = $scope.UserProfile;
            if ($scope.imageData != "") {
                var parseFile = new Parse.File("ProfileImg.jpg", {
                    base64: $scope.imageData
                });
                objProfileLink.set("ProfileImage", parseFile);
                console.log('create profile link');
                objProfileLink.save(null, {
                    success: function (employee) {
                        $ionicLoading.hide();
                        var alertPopup = $ionicPopup.alert({
                            title: 'CureBooth Admin',
                            cssClass: 'balance',
                            template: 'Profile image updated successfully.'
                        });
                        alertPopup.then(function (res) {
                            $scope.closeProfileModal();
                        });
                        //$rootScope.showAlert('Profile image updated successfully.');
                    },
                    error: function (employee, error) {
                        $ionicLoading.hide();
                        //alert('error:' + error.message.toString());
                    }
                });
            }
        }
        document.addEventListener("deviceready", function () {
            $scope.takePhoto = function (data) {
                if (data == 1)
                    $scope.cemera();
                else
                    $scope.gallery();
            }
        }, false);
        $scope.cemera = function () {
            var options = {
                quality: 65,
                destinationType: Camera.DestinationType.DATA_URL,
                sourceType: Camera.PictureSourceType.CAMERA,
                allowEdit: true,
                encodingType: Camera.EncodingType.JPEG,
                targetWidth: 100,
                targetHeight: 100,
                popoverOptions: CameraPopoverOptions,
                saveToPhotoAlbum: false,
                correctOrientation: true
            };

            $cordovaCamera.getPicture(options).then(function (imageData) {
                $scope.imageData = imageData;
                $scope.ProfileImage = "data:image/jpeg;base64," + imageData;
            }, function (err) {
                // error
            });

        }
        $scope.gallery = function () {
            var options = {
                quality: 65,
                destinationType: Camera.DestinationType.DATA_URL,
                sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
                allowEdit: true,
                encodingType: Camera.EncodingType.JPEG,
                targetWidth: 100,
                targetHeight: 100,
                popoverOptions: CameraPopoverOptions,
                saveToPhotoAlbum: false,
                correctOrientation: true
            };

            $cordovaCamera.getPicture(options).then(function (imageData) {
                $scope.imageData = imageData;
                $scope.ProfileImage = "data:image/jpeg;base64," + imageData;
            }, function (err) {
                // error
            });

        }
        $ionicModal.fromTemplateUrl('profile-img.html', {
            scope: $scope,
            animation: 'fade-in-up'
        }).then(function (modal) {
            $scope.profilemodal = modal;
        });
        $scope.openProfileModal = function () {
            if ($rootScope.NetworkStatus)
                $scope.profilemodal.show();
            else
                $cordovaToast.show('no connection available', 'short', 'center')

        };
        $scope.closeProfileModal = function () {
            $scope.profilemodal.hide();
        };
        //Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function () {
            $scope.profilemodal.remove();
        });
        console.log('$rootScope.NetworkStatus: ' + $rootScope.NetworkStatus)
        if ($rootScope.NetworkStatus) {
            $scope.profile = $rootScope.UserProfile;
            //$scope.profile.CbNo = $scope.profile.UserPointer.ExotelNumber;
            //$scope.profile.Speciality = $scope.profile.Specialist.Speciality;
            $scope.getProfile();
            //$scope.GetDoctorSpeciality();
        } else {
            $scope.profile = $rootScope.UserProfile;
            //$scope.profile.CbNo = $scope.profile.UserPointer.ExotelNumber;
            //$scope.profile.Speciality = $scope.profile.Specialist.Speciality;
        }
        //ionicMaterialInk.displayEffect();
    })
    .controller('SettingCtrl', function ($scope, $state, $ionicLoading, $rootScope, $http, $ionicPopup, $localstorage, $cordovaToast, ionicMaterialInk) {
        //console.log(Parse.User.current().getEmail())
        $scope.setting = {};
        $scope.chargesSetting = [];
        $scope.editable = false;
        $scope.ConsultSetting = false;
        $scope.changePassword = false;

        $scope.edit = function (id) {
            if ($rootScope.NetworkStatus) {
                $scope.editable = id;
                $scope.ConsultSetting = false;
                $scope.changePassword = false;
            } else
                $cordovaToast.show('no connection available', 'short', 'center')

        }

        $scope.ConsultSettingfn = function (param) {
            if ($rootScope.NetworkStatus) {
                $scope.ConsultSetting = param;
                $scope.editable = false;
                $scope.changePassword = false;
            } else
                $cordovaToast.show('no connection available', 'short', 'center')
        }

        $scope.getProfile = function () {
                //$ionicLoading.show();
                Parse.Cloud.run('GetProfile', {
                    UserObjectId: $rootScope.user.id,
                }, {
                    success: function (results) {
                        $ionicLoading.hide();
                        if (results != undefined && results != null) {
                            $scope.Profile = results;
                            $scope.chargesSetting.FirstMin = $scope.Profile.get('FirstMin');
                            $scope.chargesSetting.ChargesPerMin = $scope.Profile.get('ChargesPerMin');
                            $scope.chargesSetting.IsOfflineCall = $scope.Profile.get('IsOfflineCall');
                            $scope.chargesSetting.ForMins = $scope.Profile.get('ForMins');
                            $scope.chargesSetting.IsConnectedCall = !$scope.Profile.get('IsAnyOneCall');
                            $scope.chargesSetting.IsAnyOneCall = $scope.Profile.get('IsAnyOneCall');
                            if ($scope.chargesSetting.ForMins != 0)
                                $scope.chargesSetting.NA = true
                            else
                                $scope.chargesSetting.NA = false
                        }
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                    }
                });
            }
            //GetShareMsg
        $scope.GetShareMsg = function () {
            //$ionicLoading.show();
            Parse.Cloud.run('GetShareMsg', {
                //UserObjectId: $rootScope.user.id,
            }, {
                success: function (results) {
                    $ionicLoading.hide();
                    $scope.GetShareMsgdata = results;
                    console.log($scope.GetShareMsgdata[0])
                    console.log($scope.GetShareMsgdata[1])
                },
                error: function (error) {
                    $ionicLoading.hide();
                }
            });
        }
        $scope.shareApp = function () {
            var options = {
                message: 'share this', // not supported on some apps (Facebook, Instagram)
                subject: 'the subject', // fi. for email
                files: ['', ''], // an array of filenames either locally or remotely
                url: 'https://www.website.com/foo/#bar?a=b',
                chooserTitle: 'Pick an app' // Android only, you can override the default share sheet title
            }

            /*var onSuccess = function (result) {
                console.log("Share completed? " + result.completed); // On Android apps mostly return false even while it's true
                console.log("Shared to app: " + result.app); // On Android result.app is currently empty. On iOS it's empty when sharing is cancelled (result.completed=false)
            }

            var onError = function (msg) {
                console.log("Sharing failed with message: " + msg);
            }

            window.plugins.socialsharing.share(options, onSuccess, onError);*/
            window.plugins.socialsharing.share($scope.GetShareMsgdata[0], 'CureBooth', null, $scope.GetShareMsgdata[1]);
        }
        $scope.getSetting = function () {
            if ($localstorage.getObject('Doctorsetting') === null) {} // $ionicLoading.show();
            console.log('getSetting')
            var query = new Parse.Query('DocAccountSetting');
            query.equalTo('UserObjectId', $rootScope.user.id);
            query.find({
                success: function (results) {
                    $ionicLoading.hide();
                    if (results.length > 0) {
                        $scope.setting = results[0];
                        /*   $scope.setting.TimeFee = results[0].get('TimeFee');
                           $scope.setting.Charges = results[0].get('Charges');
                           $scope.setting.Amount = results[0].get('Amount');*/
                        //$scope.setting.BankName = results[0].get('BankName');
                        //$scope.setting.AccountNumber = results[0].get('AccountNumber');
                        //$scope.setting.BankCode = results[0].get('BankCode');
                        $localstorage.setObject('Doctorsetting', $scope.setting);
                        $scope.setting = $localstorage.getObject('Doctorsetting');
                        $scope.setting.AccountNumber = parseInt($scope.setting.AccountNumber)
                            ////alert(results.get('LastName'));
                    } else {
                        $scope.setting.result = null;
                    }
                },
                error: function (error) {
                    $ionicLoading.hide();

                    ////alert("Error: " + error.code + " " + error.message);
                }
            });
        }


        $scope.NotApplicable = function () {
            console.log($scope.chargesSetting.NA)
            if (!$scope.chargesSetting.NA) {
                $scope.chargesSetting.FirstMin = 0;
                $scope.chargesSetting.ForMins = 0;
            }
        }
        $scope.PatientAccess = function (id) {
            $scope.chargesSetting.IsConnectedCall = !id;
        }
        $scope.PatientAccess1 = function (id) {
            $scope.chargesSetting.IsAnyOneCall = !id;
        }
        $scope.SetDoctorCharges = function () {
            if ($scope.chargesSetting.NA) {
                if (typeof $scope.chargesSetting.FirstMin === 'undefined' || $scope.chargesSetting.FirstMin === null || $scope.chargesSetting.FirstMin < 0) {
                    $rootScope.showAlert("Please Enter Minimum Charges")
                    return false;
                }
                /*else if (typeof $scope.chargesSetting.ForMins === 'undefined' || $scope.chargesSetting.ForMins === null || $scope.chargesSetting.FirstMin <= 0) {
                                   $rootScope.showAlert("Please Enter For Minutes")
                                   return false;
                               }*/
            }
            if (typeof $scope.chargesSetting.ChargesPerMin === 'undefined' || $scope.chargesSetting.ChargesPerMin === null || $scope.chargesSetting.ChargesPerMin < 0) {
                $rootScope.showAlert("Please Enter Charges Per Minute");
                return false;
            } else {
                var confirmPopup = $ionicPopup.confirm({
                    title: 'CureBooth Admin',
                    template: 'Are you sure ! <br/> You want to update your charges?'
                });

                confirmPopup.then(function (res) {
                    if (res) {
                        // $ionicLoading.show();
                        Parse.Cloud.run('SetDoctorCharges', {
                            ProfileId: $scope.Profile.id,
                            FirstMin: $scope.chargesSetting.FirstMin,
                            PerMin: $scope.chargesSetting.ChargesPerMin,
                            OfflineCall: $scope.chargesSetting.IsOfflineCall,
                            IsAnyOneCall: $scope.chargesSetting.IsAnyOneCall
                        }, {
                            success: function (results) {
                                $ionicLoading.hide();
                                $scope.ConsultSetting = false;
                            },
                            error: function (error) {
                                $ionicLoading.hide();
                                $scope.getProfile();
                                //$rootScope.showAlert(error.message);
                                $cordovaToast.show(error.message, 'short', 'center')
                            }
                        });
                    }
                })
            }
        };

        $scope.changePass = function (param) {
            if ($rootScope.NetworkStatus) {
                $scope.changePassword = param;
                $scope.editable = false;
                $scope.ConsultSetting = false;
            } else
                $cordovaToast.show('no connection available', 'short', 'center')
        }
        $scope.changePasword = [];
        $scope.UpdatePassword = function () {
            if (typeof $scope.changePasword.Password === 'undefined' || $scope.changePasword.Password === null) {
                $rootScope.showAlert("Please enter Current Password");
                return false;
            } else if (typeof $scope.changePasword.NewPassword === 'undefined' || $scope.changePasword.NewPassword === null) {
                $rootScope.showAlert("Please enter New Password");
                return false;
            } else if (typeof $scope.changePasword.cNewPassword === 'undefined' || $scope.changePasword.cNewPassword === null) {
                $rootScope.showAlert("Please enter Confirm New Password");
                return false;
            } else if ($scope.changePasword.NewPassword != $scope.changePasword.cNewPassword) {
                $rootScope.showAlert("Please enter same New Password and Confirm New Password");
                return false;
            } else if ($scope.changePasword.Password == $scope.changePasword.cNewPassword) {
                $rootScope.showAlert("Please enter same New Password and Confirm New Password");
                return false;
            } else {
                var confirmPopup = $ionicPopup.confirm({
                    title: 'CureBooth Admin',
                    template: 'Are you sure ! <br/> You want to change your password?'
                });

                confirmPopup.then(function (res) {
                    if (res) {
                        // $ionicLoading.show();
                        Parse.Cloud.run('UpdatePassword', {
                            //username: $scope.Profile.get('Phone'),
                            oldPassword: $scope.changePasword.Password,
                            newPassword: $scope.changePasword.NewPassword
                        }, {
                            success: function (results) {
                                $ionicLoading.hide();
                                $scope.changePassword = false;
                                var alertPopup = $ionicPopup.alert({
                                    title: 'CureBooth Admin',
                                    cssClass: 'balance',
                                    template: 'Password changed successfully !<br> Please login again'
                                });
                                alertPopup.then(function (res) {
                                    $scope.logOut();
                                });
                            },
                            error: function (error) {
                                console.log(error)
                                $ionicLoading.hide();
                                $rootScope.showAlert(error.message);
                            }
                        });
                    }
                });
            }

        };
        //$scope.ForgotPassword();
        $scope.saveSetting = function () {
            // $ionicLoading.show();
            if ($scope.setting.result != null) {
                var point = $scope.setting.result[0];
                point.set("BankName", $scope.setting.BankName);
                point.set("AccountNumber", $scope.setting.AccountNumber);
                point.set("BankCode", $scope.setting.BankCode);
                point.set("UserObjectId", $rootScope.user.id);
                point.set("ProfileObjectId", $scope.Profile.id);
                point.save(null, {
                    success: function (point) {
                        $ionicLoading.hide();
                        $rootScope.showAlert('Setting Saved successfully.');
                        $scope.editable = false;
                        // Saved successfully.
                    },
                    error: function (point, error) {
                        $ionicLoading.hide();
                        $rootScope.showAlert(error);

                        // The save failed.
                        // error is a Parse.Error with an error code and description.
                    }
                });
            } else {

                var Point = Parse.Object.extend("DocAccountSetting");
                var point = new Point();
                point.set("BankName", $scope.setting.BankName);
                point.set("AccountNumber", $scope.setting.AccountNumber);
                point.set("BankCode", $scope.setting.BankCode);
                point.set("UserObjectId", $rootScope.user.id);
                point.set("ProfileObjectId", $scope.Profile.id);
                /*  point.set("Charges", $scope.setting.Charges);
                  point.set("Amount", $scope.setting.Amount);*/
                //point.set("usertypeobjectid", $scope.profile.usertypeobjectid);
                // Save
                point.save(null, {
                    success: function (point) {
                        $ionicLoading.hide();
                        $rootScope.showAlert('Setting Created successfully.');
                        $scope.editable = false;
                        // Saved successfully.
                    },
                    error: function (point, error) {
                        $ionicLoading.hide();
                        $rootScope.showAlert(error);

                        // The save failed.
                        // error is a Parse.Error with an error code and description.
                    }
                });
            }
        }
        if ($rootScope.NetworkStatus) {
            $scope.chargesSetting = $rootScope.UserProfile;
            $scope.chargesSetting.IsConnectedCall = !$scope.chargesSetting.IsAnyOneCall;
            $scope.setting = $localstorage.getObject('Doctorsetting');
            $scope.setting.AccountNumber = parseInt($scope.setting.AccountNumber)
            $scope.getSetting();
            $scope.getProfile();
            $scope.GetShareMsg();
        } else {
            $scope.chargesSetting = $rootScope.UserProfile;
            $scope.chargesSetting.IsConnectedCall = !$scope.chargesSetting.IsAnyOneCall;
            $scope.setting = $localstorage.getObject('Doctorsetting');
            $scope.setting.AccountNumber = parseInt($scope.setting.AccountNumber)
        }
        //ionicMaterialInk.displayEffect();
    })
    .controller('ReceivableCtrl', function ($scope, $http, $state, $ionicPopup, $ionicLoading, $rootScope, $http, $ionicModal, $timeout, $localstorage, ionicMaterialInk, $cordovaToast) {
        $scope.setting = [];
        //GetShareMsg

        $scope.getReceivable = function () {
            if ($localstorage.getObject('WalletBalance') === null) {} // $ionicLoading.show();
            var query = new Parse.Query('Wallet');
            query.equalTo('UserObjectId', $rootScope.user.id);
            query.find({
                success: function (results) {
                    $ionicLoading.hide();
                    //$scope.setting.Revenue = results[0].get('Amount');
                    $localstorage.setObject('WalletBalance', results[0].get('Amount'));
                    $scope.setting.Revenue = $localstorage.getObject('WalletBalance');
                    $scope.$apply();
                },
                error: function (error) {
                    $ionicLoading.hide();
                    //alert("Error: " + error.code + " " + error.message);
                }
            });
        }
        var myVar;
        $scope.payment = function () {
            //$scope.paymetHistory("qw49501894647")
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'long', 'center')
            } else {
                var txnid = "qw" + Math.floor(Math.random() * 100000000000);
                key = "cSozgo" //"0EcShr1i"//
                salt = "8QHHmL7C" //"aDLdm1csq3"
                var payu_params = {};
                var UserProfile = $rootScope.UserProfile;
                payu_params.key = key //checkEmptyValue(key);
                payu_params.txnid = txnid //checkEmptyValue(txnid);
                payu_params.amount = $scope.user.money //checkEmptyValue($scope.user.money);
                payu_params.productinfo = 'Add Maney to Wallet' //checkEmptyValue('Add Manoy to Wallet');
                payu_params.firstname = UserProfile.FullName //checkEmptyValue(UserProfile[0].get("FirstName"));
                payu_params.email = UserProfile.UserPointer.email //checkEmptyValue(UserProfile[0].get("Email"));
                payu_params.user_credentials = "cSozgo:unique_id" //checkEmptyValue("0MQaQP:unique_id");
                payu_params.phone = UserProfile.Phone //checkEmptyValue(" ");
                payu_params.udf1 = $rootScope.user.id //checkEmptyValue(" ");
                payu_params.udf2 = "" //checkEmptyValue(" ");
                payu_params.udf3 = "" //checkEmptyValue(" ");
                payu_params.udf4 = "" //checkEmptyValue(" ");
                payu_params.udf5 = "" //checkEmptyValue(" ");
                payu_params.offer_key = "" //checkEmptyValue(" ");
                payu_params.card_bin = ""
                payu_params.surl = encodeURI("https://www.payumoney.com/mobileapp/payumoney/success.php"); // url needs to be encoded
                payu_params.furl = encodeURI("https://www.payumoney.com/mobileapp/payumoney/failure.php"); // url needs to be encoded
                function checkEmptyValue(str) {
                    var value = str //.trim();
                    if (value.length == 0 || value == null || value == 'undefined' || value == "") {
                        return "";
                    } else {
                        return value;
                    }
                }
                var hash_string = payu_params.key + "|" + payu_params.txnid + "|" + payu_params.amount + "|" +
                    payu_params.productinfo + "|" + payu_params.firstname + "|" +
                    payu_params.email + "|" + payu_params.udf1 + "|" + payu_params.udf2 + "|" +
                    payu_params.udf3 + "|" + payu_params.udf4 + "|" + payu_params.udf5 + "||||||8QHHmL7C";
                payu_params.hash = CryptoJS.SHA512(hash_string).toString(CryptoJS.enc.Base64);
                payu_params.service_provider = "payu_paisa";
                console.log("Hash = " + payu_params.hash);
                console.log(payu_params);
                var payu_params_string = '';
                for (var key in payu_params) {
                    payu_params_string += key + "=" + payu_params[key] + "&";
                }

                // trim last character (&)
                payu_params_string = payu_params_string.slice(0, -1);


                var browserWindow = window.open('http://default-environment.2dmee9yyxr.ap-southeast-1.elasticbeanstalk.com/cbpayment.html', '_blank', 'location=no,hidden=yes,hardwareback=no');
                var transitionLoaded = false;
                var finalURL = 'https://secure.payu.in/_payment';
                var paramName = 'key';
                var paramValue = 'cSozgo';

                function injectForm() {
                    console.log(payu_params.key)
                    console.log(payu_params.firstname)
                    console.log(payu_params.email)
                    console.log(payu_params.hash)
                    browserWindow.executeScript({
                        code: "var formdata;formdata = $(document.createElement('form')).css({ display: 'none'}).attr('method', 'POST').attr('action', '" + finalURL + "');$('body').append(formdata);var inputfld = $(document.createElement('input')).attr('name', '" + paramName + "').val('" + paramValue + "');formdata.append(inputfld);var inputfld1 = $(document.createElement('input')).attr('name', 'txnid').val('" + payu_params.txnid + "');formdata.append(inputfld1);var inputfld2 = $(document.createElement('input')).attr('name', 'amount').val('" + payu_params.amount + "');formdata.append(inputfld2);var inputfld3 = $(document.createElement('input')).attr('name', 'productinfo').val('" + payu_params.productinfo + "');formdata.append(inputfld3);var inputfld4 = $(document.createElement('input')).attr('name', 'firstname').val('" + payu_params.firstname + "');formdata.append(inputfld4);var inputfld5 = $(document.createElement('input')).attr('name', 'email').val('" + payu_params.email + "');formdata.append(inputfld5);var inputfld6 = $(document.createElement('input')).attr('name', 'user_credentials').val('" + payu_params.user_credentials + "');formdata.append(inputfld6);var inputfld7 = $(document.createElement('input')).attr('name', 'phone').val('" + payu_params.phone + "');formdata.append(inputfld7);var inputfld8 = $(document.createElement('input')).attr('name', 'udf1').val('" + payu_params.udf1 + "');formdata.append(inputfld8);var inputfld9 = $(document.createElement('input')).attr('name', 'surl').val('" + payu_params.surl + "');formdata.append(inputfld9);var inputfld10 = $(document.createElement('input')).attr('name', 'furl').val('" + payu_params.furl + "');formdata.append(inputfld10);var inputfld11 = $(document.createElement('input')).attr('name', 'hash').val('" + payu_params.hash + "');formdata.append(inputfld11);var inputfld12 = $(document.createElement('input')).attr('name', 'service_provider').val('" + payu_params.service_provider + "');formdata.append(inputfld12);formdata.submit();"

                    }, function (e) {
                        console.log(e)
                        console.log('Form injected')
                        transitionLoaded = true;
                    });
                }
                browserWindow.addEventListener('loadstop', function (event) {
                    if (event.url.indexOf('http://default-environment.2dmee9yyxr.ap-southeast-1.elasticbeanstalk.com/cbpayment.html') !== -1 && !transitionLoaded) {
                        console.log('Form injected hehehehehehe')
                        injectForm();
                    }
                    var sucess = "payumoney/success.php"
                    var fail = "payumoney/failure.php"
                    console.log(event.url.indexOf(sucess) + '...' + event.url.indexOf(fail))
                    if (event.url.indexOf(sucess) > -1 || event.url.indexOf(fail) > -1) {
                        $scope.paymetHistory(txnid)
                        $scope.user.money = '';
                        $scope.closeProfileModal();
                        $scope.GetTransactionHistory();
                        browserWindow.close();
                    }

                });

                browserWindow.show();


                //postForm.CDATA_SECTION_NODE(payu_params_string)
                /*   var bodyTag = document.getElementsByTagName('body')[0];
                   bodyTag.appendChild(postForm);
                   postForm.submit();
                   var myiframe = document.getElementById('myiframe');
                   myiframe.onreadystatechange = function () {
                           console.log(this.contentWindow.location.href)
                           if (myiframe.readyState == 'complete') {
                               $ionicLoading.hide();
                           }
                       }
                   
                   $timeout(function () {
                       $ionicLoading.hide();
                       //console.log('current Url of Iframe')
                       console.log(document.getElementById("myiframe").contentWindow.location.href);
                   }, 3000);
                   myVar = window.setInterval(function () {
                       console.log('current Url of Iframe')
                       console.log(document.getElementById("myiframe").contentWindow.location.href);
                       var string = document.getElementById("myiframe").contentWindow.location.href;
                       var sucess = "payumoney/success.php"
                       var fail = "payumoney/failure.php"
                       console.log(string.indexOf(sucess) + '...' + string.indexOf(fail))
                       if (string.indexOf(sucess) > -1 || string.indexOf(fail) > -1) {
                           $scope.paymetHistory(txnid)
                           clearInterval(myVar);
                           $timeout(function () {
                               $scope.closeProfileModal();
                               $scope.GetTransactionHistory();
                           }, 5000);

                       }
                   }, 2000);*/

            }
        }
        $scope.paymetHistory = function (taxid) {
            var paymetHtory = Parse.Object.extend("MerchantTransaction");
            var point = new paymetHtory();
            point.set("merchantTransactionId", taxid)
            point.set("userObjectId", $rootScope.user.id);
            point.set("Amount", $scope.user.money);
            point.save(null, {
                success: function (point) {
                    $ionicLoading.hide();
                    //$scope.editable = true;
                    //$rootScope.showAlert('Profile Saved successfully.');
                    // Saved successfully.
                },
                error: function (point, error) {
                    $ionicLoading.hide();
                    //$rootScope.showAlert(error);
                }
            });
            $http({
                method: 'GET',
                url: 'http://default-environment.2dmee9yyxr.ap-southeast-1.elasticbeanstalk.com/Payment/GetPaymentObject?merchantTransactionId=' + taxid,
            }).then(function (response) {
                if (response.data == 'ok') {
                    $scope.user.money = '';
                } else {
                    $scope.user.money = '';
                }
            });
        }

        $scope.TransactionHistory = [];
        $scope.GetTransactionHistory = function () {
            if ($localstorage.getObject('PatientTransactionHistory') === null) {} // $ionicLoading.show();
            Parse.Cloud.run('GetTransactionHistory', {
                UserProfileId: $rootScope.user.ProfileId
            }, {
                success: function (results) {
                    $ionicLoading.hide();
                    //$scope.TransactionHistory = results;
                    $localstorage.setObject('PatientTransactionHistory', results);
                    $scope.TransactionHistory = $localstorage.getObject('PatientTransactionHistory');
                    $scope.$apply();
                },
                error: function (error) {
                    $ionicLoading.hide();
                    // error
                }
            });
        };
        $ionicModal.fromTemplateUrl('payumoney.html', {
            scope: $scope,
            animation: 'fade-in-up'
        }).then(function (modal) {
            $scope.profilemodal = modal;
        });
        $scope.openProfileModal = function () {
            $scope.profilemodal.show();
            //// $ionicLoading.show();
        };
        $scope.closeProfileModal = function () {
            clearInterval(myVar);
            $scope.profilemodal.hide();
        };
        //Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function () {
            clearInterval(myVar);
            $scope.profilemodal.remove();
        });
        $scope.hideProgress = function () {
            $ionicLoading.hide();
        }



        $scope.rechargeAmount = [];
        $scope.showaddmoney = function () {
            $scope.Recharge = true;
            $scope.Rechargebtn = true;
            $scope.openRechargeModal();
        }
        $ionicModal.fromTemplateUrl('encash.html', {
            scope: $scope,
            animation: 'fade-in-up'
        }).then(function (modal) {
            $scope.rechargeModal = modal;
        });
        $scope.openRechargeModal = function () {
            if ($rootScope.NetworkStatus)
                $scope.rechargeModal.show();
            else
                $cordovaToast.show('no connection available', 'short', 'center')

        };
        $scope.closeRechargeModal = function () {
            $scope.rechargeModal.hide();
        };
        //Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function () {
            $scope.rechargeModal.remove();
        });
        $scope.showaddMoneyfn = function () {
            if ($scope.rechargeAmount.amount != undefined && $scope.rechargeAmount.amount != null) {
                if ($scope.rechargeAmount.amount > $scope.setting.Revenue || $scope.rechargeAmount.amount == 0 || $scope.rechargeAmount.amount == undefined) {
                    $rootScope.showAlert('Please enter valid Health Credits.');
                } else {
                    var confirmPopup = $ionicPopup.confirm({
                        title: 'CureBooth Admin',
                        template: 'Encash Health Credits ' + $scope.rechargeAmount.amount + ' ?.'
                    });
                    confirmPopup.then(function (res) {
                        if (res) {
                            $scope.EncashCredits($scope.rechargeAmount.amount);
                        }
                    });
                }
            } else {
                $rootScope.showAlert('Please enter encash credits.');
            }
        };
        $scope.EncashCredits = function (amt) {
            //$ionicLoading.show();
            Parse.Cloud.run('EncashCredits', {
                Amount: amt,
            }, {
                success: function (results) {
                    $ionicLoading.hide();
                    if (results != undefined && results != null) {
                        $scope.getReceivable();
                        $scope.GetTransactionHistory();
                        $scope.closeRechargeModal();
                        $cordovaToast.show('Encash request sent successfully', 'short', 'center')
                    }
                },
                error: function (error) {
                    $cordovaToast.show(error.message, 'short', 'center')
                    $ionicLoading.hide();
                }
            });
        }

        // Intialize the controller 
        if ($rootScope.NetworkStatus) {
            $scope.setting.Revenue = $localstorage.getObject('WalletBalance');
            $scope.TransactionHistory = $localstorage.getObject('PatientTransactionHistory');
            $scope.GetTransactionHistory();
            $scope.getReceivable();
        } else {
            $scope.setting.Revenue = $localstorage.getObject('WalletBalance');
            $scope.TransactionHistory = $localstorage.getObject('PatientTransactionHistory');
        }
        $scope.$on('$ionicView.beforeLeave', function () {
            clearInterval(myVar);
        });
        //ionicMaterialInk.displayEffect();
    })
    .controller('WalletStatmntCtrl', function ($scope, $state, $ionicLoading, $rootScope, $http, ionicMaterialInk) {
        $scope.TransactionHistory = [];
        $scope.GetTransactionHistory = function () {
            // $ionicLoading.show();
            Parse.Cloud.run('GetTransactionHistory', {
                UserProfileId: $rootScope.user.ProfileId
            }, {
                success: function (results) {
                    $ionicLoading.hide();
                    $scope.TransactionHistory = results;
                    /*for (i = 0; i < results.length; i++) {
                        $scope.TransactionHistory = results;
                        if ($scope.PtDrProfile.ObjectId == results[i].UserInfo.id)
                            $scope.calllist.push(results[i]);
                    }*/
                },
                error: function (error) {
                    $ionicLoading.hide();
                    // error
                }
            });
        };
        $scope.GetTransactionHistory();
        //ionicMaterialInk.displayEffect();
    })
    .controller('AddPatientCtrl', function ($scope, $state, $ionicLoading, $rootScope, $http, $ionicModal, $ionicScrollDelegate, $ionicPopup, $cordovaToast, ionicMaterialInk) {
        $scope.Patient = {};
        $scope.PtDrProfile = []
        $scope.selectedDiv = 'Info'
        $scope.bookingTokenId = "xxxxx"
        $scope.showTabCantent = function (option) {
            $scope.selectedDiv = option; //'Client';
            $ionicScrollDelegate.scrollTop();
        }
        results = $rootScope.DrPtData;
        //$scope.PtDrProfile.FirstName = results.FirstName;
        //$scope.PtDrProfile.LastName = results.LastName;
        $scope.PtDrProfile.FullName = results.FullName
        $scope.PtDrProfile.BriefOverview = results.BriefOverview;
        $scope.PtDrProfile.Qualification = results.Qualification;
        $scope.PtDrProfile.Speciality = results.Speciality;
        $scope.PtDrProfile.Clinic = results.Clinic;
        $scope.PtDrProfile.ObjectId = results.UserObjectId;
        $scope.PtDrProfile.FirstMin = results.FirstMin;
        $scope.PtDrProfile.ChargesPerMin = results.ChargesPerMin;
        $scope.PtDrProfile.DrProfileId = results.id;
        $scope.PtDrProfile.DoctorFollowed = results.IsFollowed;
        $scope.PtDrProfile.IsCallAllowed = results.IsCallAllowed
        $scope.PtDrProfile.ProfileImage = results.ProfileImage;
        $scope.PtDrProfile.ExotelNumber = results.ExotelNumber;
        $scope.PtDrProfile.RecommendCounter = results.RecommendCounter;
        $scope.PtDrProfile.IsPriority = results.IsPriority;
        $scope.PtDrProfile.IsOfflineCall = results.IsOfflineCall;
        $scope.PtDrProfile.IsFollowed = results.IsFollowed
        $scope.PtDrProfile.IsVerfied = results.IsVerfied
        $scope.PtDrProfile.isMute = results.isMute
        $scope.PtDrProfile.id = results.id

        // Clinic data of doctor
        $scope.ClinicListdata = [];
        $scope.ClinicList = function () {
            if (!$rootScope.NetworkStatus) {} else {
                Parse.Cloud.run('ClinicList', {
                    DoctorProfile: $scope.PtDrProfile.id,
                    AdminProfile:$rootScope.UserProfile.objectId
                }, {
                    success: function (status) {
                        if (status.length > 0) {
                            var ln = status.length;
                            for (i = 0; i < ln; i++) {
                                var tmp = {
                                    Name: status[i].get('Name'),
                                    Admin: status[i].get('AdminProfile').id,
                                    Address: status[i].get('Address'),
                                    Pincode: parseInt(status[i].get('Pincode')),
                                    id: status[i].id,
                                    city: status[i].get('city'),
                                    area: status[i].get('Area'),
                                    DoctorProfileId: status[i].get('DoctorProfileId'),
                                    DoctorUserId: status[i].get('DoctorUserId'),
                                    ConsultationFee: status[i].get('ConsultationFee')

                                }
                                $scope.ClinicListdata.push(tmp)
                            }

                            $scope.$apply;
                        } else {
                            $scope.ClinicListdata = [];
                        }
                        $ionicLoading.hide();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                    }
                });
            }
        };
        /*Show Clinic Details*/
        $ionicModal.fromTemplateUrl('ClinicDetails.html', {
            scope: $scope,
            animation: 'fade-in-up'
        }).then(function (modal) {
            $scope.ClinicDetailsModal = modal;
        });
        $scope.openClinicDetailsModal = function (item) {
            if ($rootScope.NetworkStatus) {
                $scope.clinic = item;
                $scope.ClinicListWithSchedule = [];
                $ionicLoading.show();
                Parse.Cloud.run('ClinicListWithSchedule', {
                    DoctorProfile: $scope.PtDrProfile.id,
                    ClinicId: item.id
                }, {
                    success: function (status) {
                        if (status.length > 0) {
                            var ln = status.length;
                            var start = status[0].get('StartSlot');
                            var end = status[0].get('EndSlot');
                            $scope.tmpdata = [];
                            var clinic = {}
                            $scope.ClinicListWithSchedule = [];
                            var sun = []
                            var mon = []
                            var tue = []
                            var wed = []
                            var thu = []
                            var fri = []
                            var sat = []
                            for (i = 0; i < ln; i++) {
                                switch (status[i].get('DayId')) {
                                case 0:
                                    var tmp1 = {
                                        start: formatTimeToAMPM(status[i].get('StartSlot')),
                                        end: formatTimeToAMPM(status[i].get('EndSlot')),
                                        start1: status[i].get('StartSlot'),
                                        end1: status[i].get('EndSlot'),
                                        TokenDuration: status[i].get('TokenDuration'),
                                        SlotId: status[i].get('SlotId')
                                    }
                                    sun.push(tmp1);
                                    break;
                                case 1:
                                    var tmp2 = {
                                        start: formatTimeToAMPM(status[i].get('StartSlot')),
                                        end: formatTimeToAMPM(status[i].get('EndSlot')),
                                        start1: status[i].get('StartSlot'),
                                        end1: status[i].get('EndSlot'),
                                        TokenDuration: status[i].get('TokenDuration'),
                                        SlotId: status[i].get('SlotId')
                                    }
                                    mon.push(tmp2);
                                    break;
                                case 2:
                                    var tmp3 = {
                                        start: formatTimeToAMPM(status[i].get('StartSlot')),
                                        end: formatTimeToAMPM(status[i].get('EndSlot')),
                                        start1: status[i].get('StartSlot'),
                                        end1: status[i].get('EndSlot'),
                                        TokenDuration: status[i].get('TokenDuration'),
                                        SlotId: status[i].get('SlotId')
                                    }
                                    tue.push(tmp3);
                                    break;
                                case 3:
                                    var tmp4 = {
                                        start: formatTimeToAMPM(status[i].get('StartSlot')),
                                        end: formatTimeToAMPM(status[i].get('EndSlot')),
                                        start1: status[i].get('StartSlot'),
                                        end1: status[i].get('EndSlot'),
                                        TokenDuration: status[i].get('TokenDuration'),
                                        SlotId: status[i].get('SlotId')
                                    }
                                    wed.push(tmp4);
                                    break;
                                case 4:
                                    var tmp5 = {
                                        start: formatTimeToAMPM(status[i].get('StartSlot')),
                                        end: formatTimeToAMPM(status[i].get('EndSlot')),
                                        start1: status[i].get('StartSlot'),
                                        end1: status[i].get('EndSlot'),
                                        TokenDuration: status[i].get('TokenDuration'),
                                        SlotId: status[i].get('SlotId')
                                    }
                                    thu.push(tmp5);
                                    break;
                                case 5:
                                    var tmp6 = {
                                        start: formatTimeToAMPM(status[i].get('StartSlot')),
                                        end: formatTimeToAMPM(status[i].get('EndSlot')),
                                        start1: status[i].get('StartSlot'),
                                        end1: status[i].get('EndSlot'),
                                        TokenDuration: status[i].get('TokenDuration'),
                                        SlotId: status[i].get('SlotId')
                                    }
                                    fri.push(tmp6);
                                    break;
                                case 6:
                                    var tmp7 = {
                                        start: formatTimeToAMPM(status[i].get('StartSlot')),
                                        end: formatTimeToAMPM(status[i].get('EndSlot')),
                                        start1: status[i].get('StartSlot'),
                                        end1: status[i].get('EndSlot'),
                                        TokenDuration: status[i].get('TokenDuration'),
                                        SlotId: status[i].get('SlotId')
                                    }
                                    sat.push(tmp7);
                                    break;
                                }


                            }
                            var t1 = {
                                Day: "Sunday",
                                schedule: sun
                            }
                            $scope.ClinicListWithSchedule.push(t1)
                            var t2 = {
                                Day: "Monday",
                                schedule: mon
                            }
                            $scope.ClinicListWithSchedule.push(t2)
                            var t3 = {
                                Day: "Tuesday",
                                schedule: tue
                            }
                            $scope.ClinicListWithSchedule.push(t3)
                            var t4 = {
                                Day: "Wednesday",
                                schedule: wed
                            }
                            $scope.ClinicListWithSchedule.push(t4)
                            var t5 = {
                                Day: "Thursday",
                                schedule: thu
                            }
                            $scope.ClinicListWithSchedule.push(t5)
                            var t6 = {
                                Day: "Friday",
                                schedule: fri
                            }
                            $scope.ClinicListWithSchedule.push(t6)
                            var t7 = {
                                Day: "Saturday",
                                schedule: sat
                            }
                            $scope.ClinicListWithSchedule.push(t7)
                            console.log($scope.ClinicListWithSchedule);

                            $scope.$apply;
                        }
                        $ionicLoading.hide();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                    }
                });


                $scope.ClinicDetailsModal.show();
            } else
                $cordovaToast.show('no connection available', 'short', 'center')

        };
        $scope.closeClinicDetailsModal = function () {
            $scope.PatientSearchList = [];
            $scope.ClinicDetailsModal.hide();
        };
        //Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function () {
            $scope.ClinicDetailsModal.remove();
        });
        /*Get Clinic Schedule*/
        function formatTimeToAMPM(date) {
            var hours = date.split(":")[0];
            var minutes = date.split(":")[1];
            var ampm = hours >= 12 ? 'PM' : 'AM';
            hours = hours % 12;
            hours = hours ? hours : 12;
            var strTime = hours + ':' + minutes + ' ' + ampm;
            return strTime;
        }

        $scope.Validate = function () {
            var ErrorArr = new Array();
            if (typeof $scope.user === 'undefined' || $scope.user === null)
                throw 'Basic info is not entered';
            else {
                if (typeof $scope.Patient.Name === 'undefined' || $scope.Patient.Name === null) {
                    $rootScope.showAlert('Please enter some valid value into - Name.');
                    ErrorArr.push('name required.');
                }
                /* else if (typeof $scope.Patient.email === 'undefined' || $scope.Patient.email === null) {
                                    $rootScope.showAlert('Please enter some valid value into - Email');
                                    ErrorArr.push('Client \'Surname\' is required.');
                                }*/
                else if (typeof $scope.Patient.phone === 'undefined' || $scope.Patient.phone === null) {
                    $rootScope.showAlert("Please enter Phone number");
                    ErrorArr.push('Phone is required.');
                }

            }
            if (ErrorArr.length > 0)
                return false;

            return true; //_isValidVM
        }
        $scope.AddNewPatient = function () {
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {
                if ($scope.Validate()) {
                    // $ionicLoading.show();
                    Parse.Cloud.run('AddNewPatient', {
                        DoctorUserId: $rootScope.DrPtData.DoctorUserObjectId,
                        DoctorProfileId: $rootScope.DrPtData.id,
                        Phone: $scope.Patient.phone,
                        Name: $scope.Patient.Name,
                        Email: $scope.Patient.email,
                        AdminProfileId: $rootScope.UserProfile.objectId
                    }, {
                        success: function (results) {
                            $ionicLoading.hide();
                            if (results != undefined) {
                                $scope.Patient = []
                                var alertPopup = $ionicPopup.alert({
                                    title: 'CureBooth Admin',
                                    template: 'Patient added successfully'
                                });
                                alertPopup.then(function (res) {
                                    $scope.closeBookAppoitmentModal();
                                    var item = []
                                    item.objectId = results.id;
                                    if ($scope.bookingTokenId != "xxxxx")
                                        $scope.BookAppointment(item);
                                    else
                                        $state.go('tab.AdminHome');
                                });
                            } else {
                                $scope.FriendRequest = null;
                            }

                            // te Profile table updated successfully
                        },
                        error: function (error) {
                            //$rootScope.showAlert(error.message);
                            var alertPopup = $ionicPopup.alert({
                                title: 'CureBooth Admin',
                                template: error.message
                            });
                            alertPopup.then(function (res) {
                                $state.go('tab.AdminHome');
                            });
                            $ionicLoading.hide();
                            // error
                        }
                    });
                }
            }
        }
        $scope.AddPatient = function (Phoneno) {
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {
                // $ionicLoading.show();
                Parse.Cloud.run('AddPatient', {
                    DoctorUserId: $rootScope.DrPtData.DoctorUserObjectId,
                    DoctorProfileId: $rootScope.DrPtData.id,
                    PatientUserId: Phoneno.UserObjectId,
                    PatientProfileId: Phoneno.objectId,
                    DoctorName: $rootScope.DrPtData.FullName,
                    AdminProfileId: $rootScope.UserProfile.objectId
                }, {
                    success: function (results) {
                        $ionicLoading.hide();
                        $scope.PatientList = [];
                        if (results != undefined) {
                            $scope.PatientList = [];
                            var alertPopup = $ionicPopup.alert({
                                title: 'CureBooth Admin',
                                template: 'Patient added successfully'
                            });
                            alertPopup.then(function (res) {
                                $state.go('tab.AdminHome');
                            });
                            //$rootScope.showAlert("Patient added successfully");
                            //$scope.FriendRequest = results;
                        } else {
                            $scope.FriendRequest = null;
                        }

                        // te Profile table updated successfully
                    },
                    error: function (error) {
                        // $rootScope.showAlert(error.message);
                        var alertPopup = $ionicPopup.alert({
                            title: 'CureBooth Admin',
                            template: error.message
                        });
                        alertPopup.then(function (res) {
                            $state.go('tab.AdminHome');
                        });
                        $ionicLoading.hide();
                        // error
                    }
                });
            }
        }
        $scope.addnewPatient = false;
        $scope.PatientSearchResult = false;
        $scope.PatientSearchList = [];
        $scope.PatientSearch = function (search) {
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {
                if (search.toString().length != 10) {
                    $rootScope.showAlert('Please enter 10 digit mobile number');
                } else {
                    // $ionicLoading.show();
                    Parse.Cloud.run('PatientSearch', {
                        Phone: search
                    }, {
                        success: function (data) {
                            console.log(data.length)
                            $ionicLoading.hide();
                            if (data != undefined) {
                                $scope.PatientSearchList = data;
                                $scope.addnewPatient = false;
                                $scope.PatientSearchResult = true;
                            } else {
                                $scope.PatientSearchList = [];
                                $scope.addnewPatient = true;
                                $scope.Patient.phone = search;
                            }
                            $scope.$apply;
                        },
                        error: function (error) {
                            console.log(error)
                            $scope.PatientSearchList = [];
                            $scope.PatientList = null
                            $scope.addnewPatient = true;
                            $scope.Patient.phone = search;
                            $ionicLoading.hide();
                        }
                    });
                }
            }
        };
        // Dr Patient list
        $scope.PatientListfn = function () {
            Parse.Cloud.run('PatientList', {
                DoctorProfileId: $rootScope.user.ProfileId,
                Archived: true //'PRpuqlmbtC'
            }, {
                success: function (status) {
                    if (status.length > 0) {
                        //console.log(JSON.stringify(status.object.toJSON()))
                        $scope.PatientList = [];
                        $scope.PatientList = status
                        $scope.$apply();
                    } else
                        $scope.PatientList = ''
                },
                error: function (error) {
                    // debugger;
                    // error
                }
            });
        }
        $scope.unlock = function (data) {
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {
                Parse.Cloud.run('SetArchivePatient', {
                    //DocProfileId: $rootScope.user.ProfileId,
                    IsArchive: false,
                    PatientUserId: data.attributes.PatientUserObjectId
                }, {
                    success: function (status) {
                        $ionicLoading.hide();
                        $scope.PatientListfn();
                        $cordovaToast.show('Patient unblocked successfully', 'short', 'center')
                            // $rootScope.showAlert('patient priority updated');
                            // te Profile table updated successfully
                    },
                    error: function (error) {
                        console.log(error)
                        $ionicLoading.hide();
                        $rootScope.showAlert(error.message);
                        // debugger;
                        // error
                    }
                });
            }
        }

        $scope.FriendRequest = {};
        $scope.FriendRequestfn = function () {
            // $ionicLoading.show();
            Parse.Cloud.run('PatientRequestList', {
                ProfileId: $rootScope.user.ProfileId
            }, {
                success: function (results) {
                    $ionicLoading.hide();
                    if (results.length > 0) {
                        $scope.FriendRequest = results;
                    } else {
                        $scope.FriendRequest = null;
                    }
                },
                error: function (error) {
                    $ionicLoading.hide();
                    // error
                }
            });
        }
        $scope.GetDoctorAction = {};
        $scope.approvePatient;
        $scope.rejectPatient;
        $scope.GetDoctorAction = function () {
            // $ionicLoading.show();
            Parse.Cloud.run('GetDoctorAction', {
                //ProfileId: $rootScope.user.ProfileId
            }, {
                success: function (results) {
                    $ionicLoading.hide();
                    if (results.length > 0) {
                        for (i = 0; i < results.length; i++) {
                            if (results[i].get('actionName') == 'Rejected')
                                $scope.rejectPatient = results[i].id;
                            else if (results[i].get('actionName') == 'Approved')
                                $scope.approvePatient = results[i].id;
                        }
                        $scope.GetDoctorAction = results;
                    } else {
                        //$scope.FriendRequest = null;
                    }
                },
                error: function (error) {
                    $ionicLoading.hide();
                    // error
                }
            });
        }

        $scope.accept = function (data) {
            var confirmPopup = $ionicPopup.confirm({
                title: 'CureBooth Admin',
                template: 'Accept  patient request?'
            });

            confirmPopup.then(function (res) {
                if (res) {
                    // $ionicLoading.show();
                    Parse.Cloud.run('PatientConnectAction', {
                        ActionId: $scope.approvePatient,
                        ProfileLInkId: data
                    }, {
                        success: function (results) {
                            $ionicLoading.hide();
                            /* if (results.length > 0) {*/
                            $rootScope.showAlert("Patient Request Accepted Successfully");
                            //$scope.GetDoctorAction = results;
                            $scope.FriendRequestfn();
                            /* } else {
                                 $scope.FriendRequest = null;
                             }*/
                        },
                        error: function (error) {
                            $ionicLoading.hide();
                            $rootScope.showAlert(error.message);
                        }
                    })
                } else {
                    console.log('You are not sure');
                }
            });

        }
        $scope.reject = function (data) {
            var confirmPopup = $ionicPopup.confirm({
                title: 'CureBooth Admin',
                template: 'Reject patient request?'
            });

            confirmPopup.then(function (res) {
                if (res) {
                    // $ionicLoading.show();
                    Parse.Cloud.run('PatientConnectAction', {
                        ActionId: $scope.rejectPatient,
                        ProfileLInkId: data
                    }, {
                        success: function (results) {
                            $ionicLoading.hide();
                            /* if (results.length > 0) {*/
                            //$cordovaToast.show('Doctor followed Successfully', 'short', 'center')
                            $rootScope.showAlert("Patient Request Rejected Successfully");
                            //$scope.GetDoctorAction = results;
                            $scope.FriendRequestfn();
                            /* } else {
                                 $scope.FriendRequest = null;
                             }*/
                        },
                        error: function (error) {
                            $ionicLoading.hide();
                            $rootScope.showAlert(error.message);
                        }
                    })
                } else {
                    console.log('You are not sure');
                }
            });
        }
        $scope.showPopup = function () {
            $scope.data = {};

            // An elaborate, custom popup
            var myPopup = $ionicPopup.show({
                template: '<input type="number" ng-model="data.otp">',
                title: 'Please enter Admin code',
                scope: $scope,
                buttons: [
                    {
                        text: 'Cancel',
                        onTap: function (e) {;
                            $state.go('tab.AdminHome');
                        }
                    },
                    {
                        text: '<b>Verify</b>',
                        type: 'button-positive',
                        onTap: function (e) {
                            if (!$scope.data.otp) {
                                $rootScope.showAlert("Please enter Admin code");
                                //don't allow the user to close unless he enters wifi password
                                e.preventDefault();
                            } else {
                                Parse.Cloud.run('VerifyDoctorAdmin', {
                                    LinkingId: $rootScope.DrPtData.LinkingId,
                                    ActivationKey: $scope.data.otp
                                }, {
                                    success: function (results) {
                                        $ionicLoading.hide();
                                        $scope.PatientList = [];
                                        if (results != undefined) {
                                            var alertPopup = $ionicPopup.alert({
                                                title: 'CureBooth Admin',
                                                template: 'Doctor added successfully'
                                            });
                                            alertPopup.then(function (res) {
                                                $state.go('tab.AdminHome');
                                            });
                                            //$rootScope.showAlert("Patient added successfully");
                                            //$scope.FriendRequest = results;
                                        } else {
                                            $scope.FriendRequest = null;
                                        }

                                        // te Profile table updated successfully
                                    },
                                    error: function (error) {
                                        //$rootScope.showAlert(error.message);
                                        var alertPopup = $ionicPopup.alert({
                                            title: 'CureBooth Admin',
                                            template: error.message
                                        });
                                        alertPopup.then(function (res) {
                                            $state.go('tab.AdminHome');
                                        });
                                        $ionicLoading.hide();
                                        // error
                                    }
                                });
                            }
                        }
      }
    ]
            });

            myPopup.then(function (res) {
                console.log('Tapped!', res);
            });
        };

        // Appointment list
        $scope.DaysList = [];
        $scope.TokenStatus = TokenStatus;
        var weekday = [
    'S',
    'M',
    'T',
    'W',
    'T',
    'F',
    'S'
];
        var now = new Date();
        $scope.currentDay = now.getDay();
        for (i = 0; i < 7; i++) {
            //var dayName = weekday[(now.getDay() + i) % 7];
            var temp = {
                name: weekday[(now.getDay() + i) % 7],
                id: (now.getDay() + i) % 7
            }

            $scope.DaysList.push(temp)
        }
        $scope.changeDay = function (id) {
            $scope.currentDay = id;
            $scope.getTokenList();
        }
        $scope.DummyToken = false;
        $scope.TokenList = [];
        $scope.DummyTokenList = [];
        $scope.Patient = {};
        $scope.getTokenList = function (id) {
                if (id != null)
                    $scope.currentClinicId = id;
                else {}
                //$cordovaToast.show('Please choose clinic', 'short', 'center')
                //if ($localstorage.getObject('DoctorProfile') === null) {}
                $ionicLoading.show();
                Parse.Cloud.run('TokenList', {
                    DoctorProfile: $scope.PtDrProfile.id,
                    ClinicId: $scope.currentClinicId,
                    DayId: $scope.currentDay
                }, {
                    success: function (results) {
                        $ionicLoading.hide();
                        if (results.length > 0) {
                            $scope.TokenList = [];
                            $scope.DummyTokenList = [];
                            var ln = results.length;
                            for (i = 0; i < ln; i++) {
                                var tmp = '';
                                if (results[i].get('TokenType') == "1") {
                                    if (i + 2 < ln) {
                                        //console.log(i + 2)
                                        tmp = results[i].get('Start') + ' - ' + results[i + 2].get('End');
                                    } else {
                                        tmp = results[i].get('Start') + ' - ' + results[ln - 1].get('End');
                                    }

                                    var tmp = {
                                        timestamp: tmp,
                                        id: results[i].id,
                                        ClinicId: results[i].get('ClinicId'),
                                        End: results[i].get('End'),
                                        EndTime: results[i].attributes.EndTime.toString(),
                                        ScheduleId: results[i].get('ScheduleId'),
                                        Start: results[i].get('Start'),
                                        StartTime: results[i].attributes.StartTime.toString(), //.get('StartTime').ios,
                                        Status: results[i].get('Status').get('Name'),
                                        StatusId: results[i].get('Status').id,
                                        TokenId: results[i].get('TokenId'),
                                        StartTime: results[i].get('StartTime').iso
                                    }
                                    $scope.TokenList.push(tmp);
                                } else {
                                    $scope.DummyToken = true;
                                    var tmp = {
                                        // timestamp: tmp,
                                        id: results[i].id,
                                        ClinicId: results[i].get('ClinicId'),
                                        End: results[i].get('End'),
                                        EndTime: results[i].attributes.EndTime.toString(),
                                        ScheduleId: results[i].get('ScheduleId'),
                                        Start: results[i].get('Start'),
                                        StartTime: results[i].attributes.StartTime.toString(), //.get('StartTime').ios,
                                        Status: results[i].get('Status').get('Name'),
                                        StatusId: results[i].get('Status').id,
                                        TokenId: results[i].get('TokenId')
                                    }
                                    $scope.DummyTokenList.push(tmp);
                                }
                            }
                            //console.log($scope.TokenList)

                        } else {
                            //$scope.profile.result = null;
                            $scope.DummyTokenList = [];
                            $scope.TokenList = [];
                        }
                        $scope.$apply();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        $scope.DummyTokenList = [];
                        $scope.TokenList = [];
                        if (error.code == 209)
                            $state.go('login');
                        //$rootScope.showAlert(error);
                    }
                });
            }
            // book function to check wheter token booked for not
        $scope.book = function (item) {
                $scope.bookingTokenId = item.id;
                if (item.StatusId == $scope.TokenStatus.Booked) {

                    var alertPopup = $ionicPopup.confirm({
                        title: 'CureBooth',
                        template: 'Do you like to cancel the appointment ?'
                    });
                    alertPopup.then(function (res) {
                        if (res) {
                            $ionicLoading.show();
                            Parse.Cloud.run('CancelAppointment', {
                                TokenId: $scope.bookingTokenId
                            }, {
                                success: function (results) {
                                    $ionicLoading.hide();
                                    $scope.getTokenList();
                                    // te Profile table updated successfully
                                },
                                error: function (error) {
                                    var alertPopup = $ionicPopup.confirm({
                                        title: 'CureBooth',
                                        template: error.message
                                    });
                                    alertPopup.then(function (res) {
                                            $scope.closeBookAppoitmentModal();
                                        })
                                        //$rootScope.showAlert(error.message);

                                    $ionicLoading.hide();
                                    // error
                                }
                            });
                        } else {
                            console.log('You are not sure');
                        }
                    });

                } else if (item.StatusId == $scope.TokenStatus.Available)
                    if ($scope.currentDay == now.getDay() && item.Start.split(":")[0] < now.getHours()) {
                        $rootScope.showAlert("Appointment Token has expired. Please book another Appointment token.")
                    } else {
                        $scope.openBookAppoitmentModal();

                    }
            }
            // BookAppointment
        $scope.BookAppointment = function (item) {
            if (!$rootScope.NetworkStatus) {} else {
                Parse.Cloud.run('BookAppointment', {
                    TokenId: $scope.bookingTokenId,
                    BookedProfile: item.objectId
                }, {
                    success: function (status) {
                        if (status != undefined) {
                            $scope.getTokenList();
                            $scope.closeBookAppoitmentModal();
                            $scope.$apply;
                        }
                        $ionicLoading.hide();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        $scope.closeBookAppoitmentModal();
                        $rootScope.showAlert(error.message);
                    }
                });
            }
        };
        //manage queue
        $scope.manageQueue = function (id) {
                //$rootScope.ScheduleClinic = id;
                $state.go('tab.QueueManagement');
            }
            // booking popup 
        $ionicModal.fromTemplateUrl('bookAppoitment.html', {
            scope: $scope,
            animation: 'fade-in-up'
        }).then(function (modal) {
            $scope.bookAppoitmentModal = modal;
        });
        $scope.openBookAppoitmentModal = function () {
            if ($rootScope.NetworkStatus) {
                $scope.PatientSearchResult = false;
                $scope.PatientSearchList = [];
                $scope.search = [];
                $scope.bookAppoitmentModal.show();
            } else
                $cordovaToast.show('no connection available', 'short', 'center')

        };
        $scope.closeBookAppoitmentModal = function () {
            $scope.PatientSearchList = [];
            $scope.bookAppoitmentModal.hide();
            //$scope.openBookAppoitmentModal.hide();
        };
        if ($rootScope.NetworkStatus) {
            if ($rootScope.DrPtData.IsApproved) {
                // $scope.PatientListfn();
                //$scope.GetDoctorAction();
                // $scope.FriendRequestfn();
                $scope.ClinicList();
            } else {
                $scope.showPopup();
            }
        } else {}

        //ionicMaterialInk.displayEffect();
    })
    .controller('QueueManagement', function ($scope, $state, $ionicLoading, $rootScope, $http, $ionicPopup, $localstorage, $ionicHistory, $localstorage, $ionicModal, $cordovaToast, ionicMaterialInk) {

        // Appointment list
        $scope.TokenList = [];
        $scope.Patient = {};
        $scope.ClinicListdata = [];
        $scope.ScheduleListdata = [];
        $scope.afterFinish = false;
        $scope.addTokenflag = false;
        // get current day
        var now = new Date();
        $scope.currentDay = now.getDay();
        // token status
        $scope.TokenStatus = TokenStatus;
        //change clinic
        $scope.changeClinic = function (id) {
                if (($localstorage.getObject($scope.CurrentSchedule) != null || $localstorage.getObject($scope.CurrentSchedule).length > 0) && $localstorage.getObject(id).Day == $scope.currentDay) {
                    $scope.CurrentToken = $localstorage.getObject(id).CurrentToken;
                    $scope.CurrentSchedule = $localstorage.getObject(id).CurrentSchedule;
                    $scope.CurrentTokenPatientName = $localstorage.getObject(id).CurrentTokenPatientName;
                    $scope.CurrentClinic = $localstorage.getObject(id).CurrentClinic;
                    $scope.clinicid = $scope.CurrentClinic;
                    $scope.ScheduleList($scope.CurrentClinic)
                    $scope.sceduleId = $scope.CurrentSchedule;
                    $scope.getTokenList($scope.sceduleId);
                } else {
                    $scope.CurrentToken = false;
                    $scope.ScheduleList(id)
                }

            }
            //chnage clinic
        $scope.changeSchedule = function (id) {
                if (($localstorage.getObject(id) != null || $localstorage.getObject(id).length > 0) && $localstorage.getObject(id).Day == $scope.currentDay) {
                    $scope.CurrentToken = $localstorage.getObject(id).CurrentToken;
                    $scope.CurrentSchedule = $localstorage.getObject(id).CurrentSchedule;
                    $scope.CurrentTokenPatientName = $localstorage.getObject(id).CurrentTokenPatientName;
                    $scope.CurrentClinic = $localstorage.getObject(id).CurrentClinic;
                    $scope.clinicid = $scope.CurrentClinic;
                    $scope.ScheduleList($scope.CurrentClinic)
                    $scope.sceduleId = $scope.CurrentSchedule;
                    $scope.getTokenList($scope.sceduleId);
                } else {
                    $scope.CurrentToken = false;
                    $scope.getTokenList(id)
                }
                //$scope.getTokenList(id)
            }
            //finish  seating
        $scope.FinishSeating = function () {
                var alertPopup = $ionicPopup.confirm({
                    title: 'CureBooth',
                    template: 'Do you like to finish the seating ?'
                });
                alertPopup.then(function (res) {
                    if (res) {
                        $ionicLoading.show();
                        Parse.Cloud.run('FinishSchedule', {
                            ScheduleId: $scope.CurrentSchedule,
                        }, {
                            success: function (results) {
                                $ionicLoading.hide();
                                $localstorage.removeItem($scope.CurrentSchedule);
                                $localstorage.removeItem("CurrentQueue");
                                $state.go('tab.AdminAddPatient');
                            },
                            error: function (error) {
                                $rootScope.showAlert(error.message);
                                if (error.message == "No more bookings in seating.") {
                                    $localstorage.removeItem($scope.CurrentSchedule);
                                    $localstorage.removeItem("CurrentQueue");
                                    $state.go('tab.AdminAddPatient');
                                }
                                $ionicLoading.hide();
                                // error
                            }
                        });
                    } else {
                        console.log('You are not sure');
                    }
                });

            }
            // Clinic list
        $scope.ClinicList = function () {
            if (!$rootScope.NetworkStatus) {} else {
                //$scope.CurrentToken = false;
                $ionicLoading.show();
                Parse.Cloud.run('ClinicList', {
                    DoctorProfile: $rootScope.DrPtData.id
                }, {
                    success: function (status) {
                        if (status.length > 0) {
                            var ln = status.length;
                            for (i = 0; i < ln; i++) {
                                var tmp = {
                                    Name: status[i].get('Name'),
                                    Admin: status[i].get('AdminProfile').id,
                                    Address: status[i].get('Address'),
                                    PinCode: parseInt(status[i].get('Pincode')),
                                    id: status[i].id
                                }
                                $scope.ClinicListdata.push(tmp)
                            }
                            //$scope.ClinicListdata = status;
                            $scope.$apply;
                        }
                        $ionicLoading.hide();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                    }
                });
            }
        };
        $scope.ScheduleList = function (id) {
            if (!$rootScope.NetworkStatus) {} else {
                $scope.CurrentClinic = id;
                $ionicLoading.show();
                Parse.Cloud.run('ScheduleList', {
                    ClinicId: id
                }, {
                    success: function (status) {
                        if (status.length > 0) {
                            $scope.ScheduleListdata = [];
                            var ln = status.length;
                            for (i = 0; i < ln; i++) {
                                var tmp = {
                                    Name: status[i].get('Day') + ' - ' + status[i].get('SlotId') + ' (' + status[i].get('StartSlot') + ' - ' + status[i].get('EndSlot') + ')',
                                    Day: status[i].get('Day'),
                                    SlotId: status[i].get('SlotId'),
                                    EndSlot: status[i].get('EndSlot'),
                                    StartSlot: status[i].get('TokenDuration'),
                                    TokenDuration: status[i].get('TokenDuration'),
                                    id: status[i].id
                                }
                                $scope.ScheduleListdata.push(tmp)
                            }

                            $scope.$apply;
                        }
                        $ionicLoading.hide();
                    },
                    error: function (error) {
                        $scope.ScheduleListdata = [];
                        $ionicLoading.hide();
                    }
                });
            }
        };
        // StartSchedule Tokens
        $scope.StartSchedule = function () {
            if (!$rootScope.NetworkStatus) {} else {
                $ionicLoading.show();
                Parse.Cloud.run('StartScheduleTokens', {
                    ScheduleId: $scope.CurrentSchedule
                }, {
                    success: function (status) {
                        if (status != undefined) {
                            var currentQueue = {
                                Day: $scope.currentDay,
                                CurrentToken: status.get('TokenId'),
                                CurrentSchedule: $scope.CurrentSchedule,
                                CurrentClinic: $scope.CurrentClinic,
                                CurrentTokenPatientName: status.get('PatientProfile').get('FullName')
                            }
                            $localstorage.setObject($scope.CurrentSchedule, currentQueue);
                            $localstorage.setObject('CurrentQueue', currentQueue);
                            $scope.CurrentToken = status.get('TokenId');
                            $scope.CurrentTokenPatientName = status.get('PatientProfile').get('FullName');
                            $scope.CurrentTokenId = status.id;
                            $scope.getTokenList($scope.CurrentSchedule);
                            $scope.$apply;
                        }
                        $ionicLoading.hide();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        $cordovaToast.show(error.message, 'short', 'center')

                    }
                });
            }
        };
        // Schedule Next Token
        $scope.ScheduleNextToken = function (id) {
            if (!$rootScope.NetworkStatus) {} else {
                $ionicLoading.show();
                Parse.Cloud.run('ScheduleNextToken', {
                    ScheduleId: $scope.CurrentSchedule,
                    IsSkip: id,
                    TokenId: $scope.CurrentTokenId
                }, {
                    success: function (status) {
                        if (status != undefined) {
                            var currentQueue = {
                                Day: $scope.currentDay,
                                CurrentToken: status.get('TokenId'),
                                CurrentSchedule: $scope.CurrentSchedule,
                                CurrentClinic: $scope.CurrentClinic,
                                CurrentTokenPatientName: status.get('PatientProfile').get('FullName')
                            }
                            $localstorage.setObject($scope.CurrentSchedule, currentQueue);
                            $localstorage.setObject('CurrentQueue', currentQueue);
                            $scope.CurrentToken = status.get('TokenId');
                            $scope.CurrentTokenPatientName = status.get('PatientProfile').get('FullName');
                            $scope.CurrentTokenId = status.id;
                            $scope.getTokenList($scope.CurrentSchedule);
                            $scope.$apply;
                        }
                        $ionicLoading.hide();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        if (error.message == "No more bookings in seating.") {
                            //$cordovaToast.show('No more bookings,finishing seating', 'short', 'center');
                            var alertPopup = $ionicPopup.show({
                                title: 'CureBooth',
                                template: 'No more bookings,you can finish seating now?',
                                scope: $scope,
                                buttons: [
                                    {
                                        text: 'Add Token'
                                                },
                                    {
                                        text: 'Finish',
                                        type: 'button-assertive',
                                        onTap: function (e) {
                                            return $scope;
                                            console.log(e)
                                        }
                                    }]
                            });
                            alertPopup.then(function (res) {
                                    console.log(res)
                                    if (res) {
                                        $ionicLoading.show();
                                        Parse.Cloud.run('FinishSchedule', {
                                            ScheduleId: $scope.CurrentSchedule,
                                        }, {
                                            success: function (results) {
                                                $ionicLoading.hide();
                                                $localstorage.removeItem($scope.CurrentSchedule);
                                                $localstorage.removeItem("CurrentQueue");
                                                $state.go('tab.profile');
                                            },
                                            error: function (error) {
                                                $rootScope.showAlert(error.message);
                                                if (error.message == "No more bookings in seating.") {
                                                    $localstorage.removeItem($scope.CurrentSchedule);
                                                    $localstorage.removeItem("CurrentQueue");
                                                    $state.go('tab.profile');
                                                }
                                                $ionicLoading.hide();
                                                // error
                                            }
                                        });
                                    } else {
                                        $scope.afterFinish = true;
                                        $scope.addNewToken();

                                    }
                                })
                                /*$localstorage.removeItem($scope.CurrentSchedule);
$localstorage.removeItem("CurrentQueue");
$state.go('tab.profile');*/

                        }
                        //$cordovaToast.show(error.message, 'short', 'center')

                    }
                });
            }
        };
        // Schedule Token Using Id
        $scope.ScheduleTokenUsingId = function (id) {
            if (!$rootScope.NetworkStatus) {} else {
                $ionicLoading.show();
                Parse.Cloud.run('ScheduleTokenUsingId', {
                    ScheduleId: $scope.CurrentSchedule,
                    //IsSkip: "false",
                    TokenId: id
                }, {
                    success: function (status) {
                        if (status != undefined) {
                            $scope.CurrentToken = status.get('TokenId');
                            $scope.CurrentTokenId = status.id;
                            $scope.getTokenList($scope.CurrentSchedule);
                            $scope.$apply;
                        }
                        $ionicLoading.hide();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        $rootScope.showAlert(error.message);
                    }
                });
            }
        };
        // get appointment list 
        $scope.getTokenList = function (id) {
                if (id != null)
                    $scope.CurrentSchedule = id;

                //$cordovaToast.show('Please choose clinic', 'short', 'center')
                if ($localstorage.getObject('DoctorProfile') === null) {} //$ionicLoading.show();
                Parse.Cloud.run('TokenListUsingSchedule', {
                    ScheduleId: $scope.CurrentSchedule
                }, {
                    success: function (results) {
                        $ionicLoading.hide();
                        if (results.length > 0) {
                            $scope.TokenList = []
                            var ln = results.length;
                            for (i = 0; i < ln; i++) {
                                var tmp = '';
                                if (i + 2 < ln) {
                                    //console.log(i + 2)
                                    tmp = results[i].get('Start') + ' - ' + results[i + 2].get('End');
                                } else {
                                    tmp = results[i].get('Start') + ' - ' + results[ln - 1].get('End');
                                }

                                var tmp = {
                                    timestamp: tmp,
                                    id: results[i].id,
                                    ClinicId: results[i].get('ClinicId'),
                                    End: results[i].get('End'),
                                    EndTime: results[i].attributes.EndTime.toString(),
                                    ScheduleId: results[i].get('ScheduleId'),
                                    Start: results[i].get('Start'),
                                    StartTime: results[i].attributes.StartTime.toString(), //.get('StartTime').ios,
                                    Status: results[i].get('Status').get('Name'),
                                    StatusId: results[i].get('Status').id,
                                    TokenId: results[i].get('TokenId'),
                                    TokenType: results[i].get('TokenType')
                                }
                                $scope.TokenList.push(tmp);
                            }
                            /* if ($localstorage.getObject('CurrentQueue') != null) {
                                 //$scope.CurrentToken = $localstorage.getObject('CurrentQueue').CurrentToken;
                                 $scope.CurrentSchedule = $localstorage.getObject('CurrentQueue').CurrentSchedule;
                                 //$scope.CurrentClinic = $localstorage.getObject('CurrentQueue').CurrentClinic;
                                 //$scope.clinicid = $scope.CurrentClinic;
                                 //getTokenList($scope.CurrentSchedule)
                             }*/
                            //console.log($scope.TokenList)
                            var element = document.getElementsByClassName("ActiveToken");
                            if (element.length > 0) {
                                element.scrollIntoView();
                                element.scrollIntoView(false);
                                element.scrollIntoView({
                                    block: "end"
                                });
                                element.scrollIntoView({
                                    block: "end",
                                    behavior: "smooth"
                                });
                            }
                            $scope.$apply();
                        } else {
                            $scope.TokenList = []
                                //$scope.profile.result = null;

                        }
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        $scope.TokenList = []
                        if (error.code == 209)
                            $state.go('login');
                        //$rootScope.showAlert(error);
                    }
                });
            }
            // Change token for service
        $scope.ChangeToken = function (item) {
            if (!$scope.CurrentToken) {
                //$cordovaToast.show('no connection available', 'short', 'center')
            } else {

                if (item.StatusId == $scope.TokenStatus.Booked && parseInt(item.TokenId.replace(/[A-Z]/g, '')) < parseInt($scope.CurrentToken.replace(/[A-Z]/g, '')) && item.TokenType == 1) {
                    var alertPopup = $ionicPopup.confirm({
                        title: 'CureBooth',
                        template: 'Service Now ?'
                    });
                    alertPopup.then(function (res) {
                        if (res)
                            $scope.ScheduleTokenUsingId(item.id)
                    });
                }

                if (item.StatusId == $scope.TokenStatus.Available && parseInt(item.TokenId.replace(/[A-Z]/g, '')) > parseInt($scope.CurrentToken.replace(/[A-Z]/g, '')) && item.TokenType == 1) {
                    $scope.bookingTokenId = item.id;
                    $scope.openBookAppoitmentModal();
                } else if (item.StatusId == $scope.TokenStatus.Available && parseInt(item.TokenId.replace(/[A-Z]/g, '')) < parseInt($scope.CurrentToken.replace(/[A-Z]/g, '')) && item.TokenType == 1) {
                    $cordovaToast.show('Cannot book previous token', 'short', 'center');
                }


                if ((item.TokenId.replace(/[0-9]/g, '') === 'AZ' && item.TokenType == 2) || (item.TokenId.replace(/[0-9]/g, '') === 'BZ' && item.TokenType == 2) || (item.TokenId.replace(/[0-9]/g, '') === 'CZ' && item.TokenType == 2)) {
                    var alertPopup = $ionicPopup.confirm({
                        title: 'CureBooth',
                        template: 'Service Now ?',
                        /*buttons: [
                            {
                                text: 'Cancel'
                                    }, {
                                text: 'Skip'
                                    }, {
                                text: 'Next'
                                    }]*/
                    });
                    alertPopup.then(function (res) {
                        console.log(res)
                        if (res)
                            $scope.ScheduleTokenUsingId(item.id)
                    });
                } else if (item.StatusId == $scope.TokenStatus.Booked && parseInt(item.TokenId.replace(/[A-Z]/g, '')) > parseInt($scope.CurrentToken.replace(/[A-Z]/g, '')) && item.TokenType == 1) {
                    var alertPopup = $ionicPopup.confirm({
                        title: 'CureBooth',
                        template: 'Do you like to cancel the appointment ?'
                    });
                    alertPopup.then(function (res) {
                        if (res) {
                            $ionicLoading.show();
                            Parse.Cloud.run('CancelAppointment', {
                                TokenId: item.id
                            }, {
                                success: function (results) {
                                    $ionicLoading.hide();
                                    $scope.getTokenList();
                                    // te Profile table updated successfully
                                },
                                error: function (error) {
                                    $rootScope.showAlert(error.message);
                                    $ionicLoading.hide();
                                    // error
                                }
                            });
                        } else {
                            console.log('You are not sure');
                        }
                    });
                }
                //$scope.ScheduleTokenUsingId(item.id)
            }
        }
        $scope.addNewToken = function () {
                $scope.addTokenflag = true;
                $scope.openBookAppoitmentModal();
            }
            // search patient to book for appoitment
        $scope.PatientSearchResult = false;
        $scope.PatientSearchList = [];
        $scope.PatientSearch = function (search) {
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {
                if (search.toString().length != 10) {
                    $rootScope.showAlert('Please enter 10 digit mobile number');
                } else {
                    //$ionicLoading.show();
                    Parse.Cloud.run('PatientSearch', {
                        Phone: search
                    }, {
                        success: function (data) {
                            console.log(data.length)
                            $ionicLoading.hide();
                            if (data != undefined) {
                                $scope.PatientSearchList = data;
                                $scope.addnewPatient = false;
                                $scope.PatientSearchResult = true;
                            } else {
                                $scope.PatientSearchList = [];
                                $scope.addnewPatient = true;
                                $scope.PatientSearchResult = false;
                                $scope.Patient.phone = search;
                            }
                            $scope.$apply;
                        },
                        error: function (error) {
                            console.log(error)
                            $scope.PatientList = null
                            $scope.PatientSearchResult = false;
                            $scope.addnewPatient = true;
                            $scope.Patient.phone = search;
                            $ionicLoading.hide();
                        }
                    });
                }
            }
        };
        // validate new patient request
        $scope.Validate = function () {
            var ErrorArr = new Array();
            if (typeof $scope.user === 'undefined' || $scope.user === null)
                throw ' entered';
            else {
                if (typeof $scope.Patient.Name === 'undefined' || $scope.Patient.Name === null) {
                    $rootScope.showAlert('Please enter some valid value into - Name.');
                    ErrorArr.push('name.');
                }
                /* else if (typeof $scope.Patient.email === 'undefined' || $scope.Patient.email === null) {
                                    $rootScope.showAlert('Please enter some valid value into - Email');
                                    ErrorArr.push('Client \'Surname\' is required.');
                                }*/
                else if (typeof $scope.Patient.phone === 'undefined' || $scope.Patient.phone === null) {
                    $rootScope.showAlert("Please enter Phone number");
                    ErrorArr.push('number.');
                }

            }
            if (ErrorArr.length > 0)
                return false;

            return true; //_isValidVM
        }

        $scope.AddNewPatient = function () {
                if (!$rootScope.NetworkStatus) {
                    $cordovaToast.show('no connection available', 'short', 'center')
                } else {
                    if ($scope.Validate()) {
                        $ionicLoading.show();
                        Parse.Cloud.run('AddNewPatient', {
                            DoctorUserId: $rootScope.user.id,
                            DoctorProfileId: $rootScope.UserProfile.objectId,
                            Phone: $scope.Patient.phone,
                            Name: $scope.Patient.Name,
                            Email: $scope.Patient.email,
                        }, {
                            success: function (results) {
                                $ionicLoading.hide();
                                if (results != undefined) {
                                    $scope.Patient = []
                                    var item = {}
                                    item.objectId = results.id;
                                    $scope.addnewPatient = false;
                                    $scope.BookAppointment(item);
                                    PatientSearchResult
                                    /*var alertPopup = $ionicPopup.alert({
                                        title: 'CureBooth',
                                        template: 'Patient added successfully'
                                    });
                                    alertPopup.then(function (res) {
                                        $state.go('tab.home');
                                    });*/

                                    //$scope.closeBookAppoitmentModal();
                                    //$scope.FriendRequest = results;
                                } else {
                                    $scope.FriendRequest = null;
                                }

                                // te Profile table updated successfully
                            },
                            error: function (error) {
                                $rootScope.showAlert(error.message);
                                $ionicLoading.hide();
                                // error
                            }
                        });
                    }
                }
            }
            // BookAppointment

        $scope.BookAppointment = function (item) {
            if (!$rootScope.NetworkStatus) {} else {
                if ($scope.addTokenflag) {
                    Parse.Cloud.run('AddTokenInSchedule', {
                        ScheduleId: $scope.CurrentSchedule,
                        BookedProfile: item.objectId,
                        afterFinish: $scope.afterFinish
                    }, {
                        success: function (status) {
                            if (status != undefined) {
                                $scope.addnewPatient = false;
                                $scope.addTokenflag = false;
                                $scope.getTokenList();
                                $scope.closeBookAppoitmentModal();
                                $scope.$apply;
                            }
                            $ionicLoading.hide();
                        },
                        error: function (error) {
                            $ionicLoading.hide();
                            $rootScope.showAlert(error.message);
                            $scope.closeBookAppoitmentModal();
                        }
                    });
                } else {
                    Parse.Cloud.run('BookAppointment', {
                        TokenId: $scope.bookingTokenId,
                        BookedProfile: item.objectId
                    }, {
                        success: function (status) {
                            if (status != undefined) {
                                $scope.getTokenList();
                                $scope.closeBookAppoitmentModal();
                                $scope.$apply;
                            }
                            $ionicLoading.hide();
                        },
                        error: function (error) {
                            $ionicLoading.hide();
                        }
                    });
                }
            }
        };
        $ionicModal.fromTemplateUrl('bookAppoitment.html', {
            scope: $scope,
            animation: 'fade-in-up'
        }).then(function (modal) {
            $scope.bookAppoitmentModal = modal;
        });
        $scope.openBookAppoitmentModal = function () {
            if ($rootScope.NetworkStatus) {
                $scope.PatientSearchResult = false;
                $scope.addnewPatient = false;
                $scope.PatientSearchList = [];
                $scope.search = [];
                $scope.bookAppoitmentModal.show();
            } else
                $cordovaToast.show('no connection available', 'short', 'center')

        };
        $scope.closeBookAppoitmentModal = function () {
            $scope.PatientSearchList = [];
            $scope.bookAppoitmentModal.hide();
        };
        //Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function () {
            $scope.bookAppoitmentModal.remove();
        });
        // Intialize the controller 
        if ($rootScope.NetworkStatus) {
            $scope.ClinicList();
            if (($localstorage.getObject('CurrentQueue') != null || $localstorage.getObject('CurrentQueue').length > 0) && $localstorage.getObject('CurrentQueue').Day == $scope.currentDay) {
                $scope.CurrentToken = $localstorage.getObject('CurrentQueue').CurrentToken;
                $scope.CurrentTokenPatientName = $localstorage.getObject('CurrentQueue').CurrentTokenPatientName;
                $scope.CurrentSchedule = $localstorage.getObject('CurrentQueue').CurrentSchedule;
                $scope.CurrentClinic = $localstorage.getObject('CurrentQueue').CurrentClinic;
                $scope.clinicid = $scope.CurrentClinic;
                $scope.ScheduleList($scope.CurrentClinic)
                $scope.sceduleId = $scope.CurrentSchedule;
                $scope.getTokenList($scope.sceduleId);
            } else {
                //$scope.CurrentToken = null;
                // $scope.CurrentSchedule = null;
                //$scope.CurrentClinic = null;
            }
        } else {

        }
    })
    .controller('ThreadDetailCtrl', function ($rootScope, $scope, $stateParams, ParseService, $location, $ionicLoading, PusherTrigger, Pusher, $ionicScrollDelegate, $cordovaCamera, $ionicPopover, $ionicSlideBoxDelegate, $cordovaDevice, $timeout, $ionicPlatform, $ionicModal, $cordovaFileTransfer, $localstorage, $cordovaToast, UtilFunctions, ionicMaterialInk) {

        var tabs = document.querySelectorAll('div.tabs')[0];
        tabs = angular.element(tabs);
        tabs.css('display', 'none');

        $scope.$on('$destroy', function () {
            console.log('HideCtrl destroy');
            tabs.css('display', '');
        });

        $scope.messages = [];
        var threadId = $stateParams.threadId;
        $scope.userId = $stateParams.targetId;
        $scope.user.id = $rootScope.UserProfile.UserObjectId

        var _isCurrentlyTyping = false;
        var _hasSentTypingMessage = false;
        var _hasSentStopMessage = false;
        var searchTimeout;

        //$scope.messages = new Array();
        $scope.isMute = $rootScope.chatUser.isMute
        $scope.isFriendFn = function () {
            if ($rootScope.isDoctor == 'true') {
                $scope.DocProfileObjectId = $rootScope.user.ProfileId
                $scope.PatientProfileObjectId = $rootScope.chatUser.id
            } else {
                $scope.DocProfileObjectId = $rootScope.chatUser.id
                $scope.PatientProfileObjectId = $rootScope.user.ProfileId
            }
            Parse.Cloud.run('IsFriend', {
                DocProfileObjectId: $scope.DocProfileObjectId,
                PatientProfileObjectId: $scope.PatientProfileObjectId
            }, {
                success: function (result) {
                    if (result.get('DoctorAction').get('actionName') == "Approved") {
                        if ($rootScope.isDoctor == 'true') {
                            $scope.isMute = result.get('DoctorMuted');
                        } else
                            $scope.isMute = result.get('PatientMuted');
                    }
                    $scope.$apply();
                },
                error: function (error) {}
            });
        }
        $scope.isFriendFn();
        // Mute Chat
        $scope.SetChatMute = function (amt) {
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {
                // $ionicLoading.show();
                Parse.Cloud.run('SetChatMute', {
                    //DocProfileId: $rootScope.user.ProfileId,
                    IsMute: amt,
                    ProfileLinkId: $rootScope.chatUser.ProfileLinkId
                }, {
                    success: function (status) {
                        $ionicLoading.hide();
                        var msg = '';
                        /* if (status.get('IsArchive')) {
                             msg = 'Patient Blocked Successfully '
                         } else {
                             msg = 'Patient Unblocked Successfully '
                         }*/
                        $cordovaToast.show(msg, 'short', 'center')
                            .then(function (success) {
                                // success
                            }, function (error) {
                                // error
                            });
                        // $rootScope.showAlert('patient priority updated');
                        // te Profile table updated successfully
                    },
                    error: function (error) {
                        console.log(error)
                        $ionicLoading.hide();
                        //$rootScope.showAlert(error.message);
                        // debugger;
                        // error
                    }
                });
            }
        }
        $scope.gotScrolled = function () {
            if (cordova.plugins.Keyboard.isVisible) {
                cordova.plugins.Keyboard.close();
            }
        }
        $scope.$on('$ionicView.beforeLeave', function () {
            console.log('$ionicView.beforeLeave')
            Pusher.unsubscribe(threadId);
            //pusher.unsubscribe(threadId);
        });
        console.log('Pusher.subscribe fn');
        $scope.NewMsg = false;
        $scope.subscribe = function () {
            Pusher.subscribe(threadId, 'new_message', function (item) {
                console.log('Pusher.subscribe')
                    // an item was updated. find it in our list and update it.
                ParseService.currentUser(
                    function win(currentUser) {
                        console.log('Pusher.currentUser');
                        if (angular.element(document.querySelector("#message_" + item.message_id)).length == 0) {
                            console.log('Pusher.currentUser sucess function')
                            console.log(item);
                            var newObj = {
                                "message": item.message,
                                "eventPush": item.eventPush,
                                "user": {
                                    //"attributes": {
                                    "objectId": item.user.objectId
                                        // }
                                }
                            }

                            $scope.NewMsg = true;
                            //console.log(newObj);
                            //console.log($scope.messages);
                            $localstorage.setObject('NewChatMessages', newObj);
                            $scope.messages.pop();
                            //console.log($localstorage.getObject('NewChatMessages'))
                            $scope.messages.push($localstorage.getObject('NewChatMessages'));
                            $localstorage.setObject('ChatMessages', $scope.messages);
                            $scope.messages = $localstorage.getObject('ChatMessages');
                            $scope.$apply();
                            $ionicScrollDelegate.scrollBottom();
                        }
                    }
                );
                console.log("NEW MESSAGE");
            });
            Pusher.subscribe(threadId, 'new_media', function (item) {
                console.log('Pusher.subscribe')
                    // an item was updated. find it in our list and update it.
                ParseService.currentUser(
                    function win(currentUser) {
                        console.log('Pusher.currentUser');
                        if (angular.element(document.querySelector("#message_" + item.message_id)).length == 0) {
                            console.log('Pusher.currentUser sucess function')
                            console.log(item);
                            var newObj = {
                                //"createdAt": item.message_payload.createdAt,
                                //"attributes": {
                                "message": '*media#',
                                "ChatMedia": {
                                    //"attributes": {
                                    "url": item.message
                                        // }
                                },
                                "eventPush": item.eventPush,
                                "user": {
                                    //"attributes": {
                                    "objectId": item.user.objectId
                                        // }
                                }
                                // }
                            }

                            $scope.NewMsg = true;
                            //console.log(newObj);
                            $localstorage.setObject('NewChatMessages', newObj);
                            // console.log($localstorage.getObject('NewChatMessages'))
                            //$scope.messages.pop();
                            $scope.messages.push($localstorage.getObject('NewChatMessages'));
                            $localstorage.setObject('ChatMessages', $scope.messages);
                            $scope.messages = $localstorage.getObject('ChatMessages');
                            $scope.$apply();
                            $ionicScrollDelegate.scrollBottom();
                        }
                    }
                );
                //console.log("NEW MESSAGE");
            });
        }
        $scope.friend = [];
        $scope.friend.ProfileImage = $rootScope.chatUser.ProfileImage;
        /* if ($rootScope.chatUser.get('ProfileImage') != undefined) {
             $scope.friend.ProfileImage = $rootScope.chatUser.get('ProfileImage').url();
         } else {
             if ($rootScope.isDoctor == 'true')
                 $scope.friend.ProfileImage = "img/doctor_icon_default.png";
             else
                 $scope.friend.ProfileImage = "img/patient_icon_default.png";
         }*/
        $scope.friend.name = $rootScope.chatUser.FullName;
        //$scope.friend.name = $rootScope.chatUser.get('FullName');
        //$scope.profile =
        $scope.createdAt = null;
        $scope.chatHistory = function () {
            $ionicLoading.show({
                /*template: 'Loading Thread...'*/
            });

            if ($scope.messages.length > 0) {
                var l = $scope.messages.length
                $scope.createdAt = $scope.messages[l - 1].createdAt;
            }
            ParseService.getThread({
                    "thread_id": threadId,
                    "createdAt": $scope.createdAt
                },
                function results(res) {
                    $ionicLoading.hide();
                    if (res.length == 0) {
                        //$scope.messages = [];
                    } else {
                        $scope.NewMsg = false;
                        for (i = 0; i < res.length; i++) {
                            //console.log(res[i].attributes.user.id)
                            res[i].attributes.user.set("USERID", res[i].attributes.user.id); //.attributes.USERID = res[i].attributes.user.id;
                            //res[i].attributes.eventPush = 'undefined';
                            //console.log('USERID: '+res[i].attributes.user.attributes.USERID)
                        }
                        //console.log(res)
                        if ($scope.messages.length == 0)
                            $scope.messages = res;
                        else
                            for (i = 0; i < res.length; i++)
                                $scope.messages.push(res[i]);

                        $localstorage.setObject(threadId, $scope.messages);
                        $scope.messages = $localstorage.getObject(threadId);
                    }
                    $ionicScrollDelegate.scrollBottom();
                },
                function fail(error) {
                    $ionicLoading.hide();
                    console.log(error);
                }
            )
        };

        $scope.doRefresh = function () {
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {
                $ionicLoading.show();
                var skip = $scope.messages.length;
                console.log(skip)
                ParseService.getThread({
                        "thread_id": threadId,
                        "offset": skip
                    },
                    function results(res) {
                        $ionicLoading.hide();
                        if (res.length == 0) {

                        } else {
                            $scope.NewMsg = false;
                            for (i = 0; i < res.length; i++) {
                                res[i].attributes.user.set("USERID", res[i].attributes.user.id);
                            }
                            if ($scope.messages.length == 0)
                                $scope.messages = res;
                            else
                                for (i = 0; i < res.length; i++)
                                    $scope.messages.unshift(res[i]);

                            $localstorage.setObject(threadId, $scope.messages);
                            $scope.messages = $localstorage.getObject(threadId);
                            /*console.log($scope.messages);
                            for (i = 0; i < res.length; i++) {
                                $scope.messages.unshift(res[i]);
                            }

                            console.log($scope.messages);*/
                        }

                        $scope.$broadcast('scroll.refreshComplete');
                    },
                    function fail(error) {
                        $ionicLoading.hide();
                        $scope.$broadcast('scroll.refreshComplete');
                    }
                );
            }
        }

        // Upload Image
        $scope.saveImg = function (imageData) {
            // $ionicLoading.show();
            ParseService.currentUser(
                function win(currentUser) {
                    var Messages = Parse.Object.extend("Messages");
                    var message = new Messages();
                    message.set("message", "*media#");
                    message.set("user", currentUser);
                    message.set("thread_id", threadId)
                    message.set("ToUser", $scope.userId)
                    message.set("FromUserName", $rootScope.UserProfile.FullName)
                    if ($scope.imageData != "") {
                        var parseFile = new Parse.File("chatImg.jpg", {
                            base64: imageData
                        });
                        message.set("ChatMedia", parseFile);
                        console.log('create profile link');
                        message.save(null, {
                            success: function (data) {
                                console.log(data)
                                var img = (data.get('ChatMedia') != undefined) ? data.get('ChatMedia').url() : '*media#';
                                var newObj = {
                                    "message": '*media#',
                                    "ChatMedia": {
                                        "url": data.get('ChatMedia').url()
                                    },
                                    "eventPush": "new_media",
                                    "user": {
                                        "objectId": $rootScope.user.id
                                    }
                                    // }
                                }
                                $localstorage.setObject('NewChatMessages', newObj);
                                console.log($localstorage.getObject('NewChatMessages'))
                                $scope.messages.push($localstorage.getObject('NewChatMessages'));
                                $localstorage.setObject('ChatMessages', $scope.messages);
                                $scope.messages = $localstorage.getObject('ChatMessages');
                                //$scope.messages.push(results);
                                var obj = {
                                    url: "http://default-environment.2dmee9yyxr.ap-southeast-1.elasticbeanstalk.com/gage/PushChat",
                                    data: {
                                        "message": img,
                                        "messagea_id": data.id,
                                        "eventPush": "new_media",
                                        "channel": threadId,
                                        "userId": $rootScope.user.id
                                    },
                                    method: "POST"
                                };
                                console.log(obj);

                                PusherTrigger.triggerEvent(obj,
                                    function results(res, status) {
                                        //content.text = null;
                                        console.log("-- Good ---");
                                        console.log(res)
                                    },
                                    function fail(res, status) {
                                        console.log('Fail');
                                        console.log(res);
                                    }
                                )

                                setTimeout(function () {
                                    $ionicScrollDelegate.scrollBottom();
                                    //content.text = null;
                                    document.querySelector("#commentBox").value = "";
                                    $scope.$apply();
                                }, 100)
                                $ionicLoading.hide();
                            },
                            error: function (employee, error) {
                                $ionicLoading.hide();
                                //alert('error:' + error.message.toString());
                            }
                        });
                    }
                },
                function fail(error) {
                    console.log('fail on currentuser');
                }
            )
        }

        document.addEventListener("deviceready", function () {
            $scope.attachMedia = function (data) {
                console.log(data)
                if (data == 1)
                    $scope.cemera();
                else
                    $scope.gallery();
            }
        }, false);
        $scope.cemera = function () {
            var options = {
                quality: 65,
                destinationType: Camera.DestinationType.DATA_URL,
                sourceType: Camera.PictureSourceType.CAMERA,
                //allowEdit: true,
                encodingType: Camera.EncodingType.JPEG,
                //targetWidth: 100,
                //targetHeight: 100,
                popoverOptions: CameraPopoverOptions,
                saveToPhotoAlbum: false,
                correctOrientation: true
            };

            $cordovaCamera.getPicture(options).then(function (imageData) {
                //$scope.imageData = imageData;
                $scope.saveImg(imageData);
                //$scope.ProfileImage = "data:image/jpeg;base64," + imageData;
            }, function (err) {
                // error
            });

        }
        $scope.gallery = function () {
                var options = {
                    quality: 65,
                    destinationType: Camera.DestinationType.DATA_URL,
                    sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
                    //allowEdit: true,
                    encodingType: Camera.EncodingType.JPEG,
                    //targetWidth: 100,
                    //targetHeight: 100,
                    popoverOptions: CameraPopoverOptions,
                    saveToPhotoAlbum: false,
                    correctOrientation: true
                };

                $cordovaCamera.getPicture(options).then(function (imageData) {
                    $scope.saveImg(imageData);
                }, function (err) {
                    // error
                });

            }
            //}

        // Download media

        $scope.mediaDownloadIcon = true;
        $scope.mediaDownload = function (id, imgid) {
            $ionicPlatform.ready(function () {
                if ($cordovaDevice.getPlatform() == 'iOS') {
                    fileDeviceDir = cordova.file.dataDirectory;
                } else {
                    fileDeviceDir = cordova.file.externalRootDirectory;
                }
            });
            console.log(id)
            document.getElementById('DchatMedia' + imgid).style.display = 'none';
            document.getElementById('PDchatMedia' + imgid).style.display = 'block';
            console.log(id.ChatMedia.url)
                //$ionicLoading.show();
            console.log('getSetting')
                // download(id.ChatMedia.url, "HBChat", id.ChatMedia.name

            var fileTransfer = new FileTransfer();
            var uri = encodeURI(id.ChatMedia.url);
            var fileURL = fileDeviceDir + id.ChatMedia.name;
            var targetPath = fileDeviceDir + id.ChatMedia.name;
            window.resolveLocalFileSystemURL(fileURL, console.log('yes'), console.log('not'));
            $cordovaFileTransfer.download(uri, targetPath, {}, true)
                .then(
                    function (entry) {
                        $scope.mediaDownloadIcon = false;
                        document.getElementById('PDchatMedia' + imgid).style.display = 'none';
                        //document.getElementById('chatMedia' + imgid).style.display = 'block';
                        //document.getElementById('chatMedia' + imgid).src = entry.toURL();
                        $scope.messages[imgid].ChatMedia.localurl = entry.toURL()
                        $localstorage.setObject(threadId, $scope.messages);
                        $scope.messages = $localstorage.getObject(threadId);
                        console.log(JSON.stringify($scope.messages[imgid]))
                        $scope.$apply();
                    },
                    function (err) {
                        console.log('File Download error: ', err);
                    },
                    function (progress) {
                        $timeout(function () {
                            var percentComplete = (progress.loaded / progress.total) * 100;
                            $scope.percentComplete = Math.round(percentComplete);
                            /*$ionicLoading.show({
                                template:  $scope.percentComplete
                            });*/
                            if (Math.round(percentComplete) === 100)
                                $scope.percentComplete = 0;
                            $ionicLoading.hide();
                            console.log("[File Download -progress- percentComplete =" + percentComplete);
                        })
                    });
            /*       fileTransfer.download(
                       uri,
                       fileURL,
                       function (entry) {
                           $scope.mediaDownloadIcon = false;
                           document.getElementById('DchatMedia' + imgid).style.display = 'none';
                           //document.getElementById('chatMedia' + imgid).style.display = 'block';
                           //document.getElementById('chatMedia' + imgid).src = entry.toURL();
                           $scope.messages[imgid].ChatMedia.localurl = entry.toURL()
                           $localstorage.setObject(threadId, $scope.messages);
                           $scope.messages = $localstorage.getObject(threadId);
                           console.log(JSON.stringify($scope.messages[imgid]))
                           $scope.$apply();
                       },
                       function (error) {
                           console.log("download error source " + error.source);
                           console.log("download error target " + error.target);
                           console.log("upload error code" + error.code);
                       },
                       false, {
                           headers: {
                               "Authorization": "Basic dGVzdHVzZXJuYW1lOnRlc3RwYXNzd29yZA=="
                           }
                       }
                   );*/
            /*       var query = new Parse.Query('Messages');
                   query.equalTo("thread_id", threadId);
                   query.equalTo("objectId", id);
                   query.find({
                       success: function (results) {
                           $ionicLoading.hide();
                           if (results.length > 0) {
                               $scope.mediaDownloadIcon = false;
                               document.getElementById('DchatMedia' + imgid).style.display = 'none';
                               document.getElementById('chatMedia' + imgid).style.display = 'block';
                               document.getElementById('chatMedia' + imgid).src = results[0].get('ChatMedia').url();
                       
                           } else {
                               //$scope.setting.result = null;
                           }
                       },
                       error: function (error) {
                           $ionicLoading.hide();

                           //alert("Error: " + error.code + " " + error.message);
                       }
                   });*/

        }

        function download(URL, Folder_Name, File_Name) {
            //step to request a file system 
            window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, fileSystemSuccess, fileSystemFail);

            function fileSystemSuccess(fileSystem) {
                var download_link = encodeURI(URL);
                ext = download_link.substr(download_link.lastIndexOf('.') + 1); //Get extension of URL

                var directoryEntry = fileSystem.root; // to get root path of directory
                directoryEntry.getDirectory(Folder_Name, {
                    create: true,
                    exclusive: false
                }, onDirectorySuccess, onDirectoryFail); // creating folder in sdcard
                var rootdir = fileSystem.root;
                var fp = rootdir.fullPath; // Returns Fulpath of local directory

                fp = fp + "/" + Folder_Name + "/" + File_Name //+ "." + ext; // fullpath and name of the file which we want to give
                    // download function call
                filetransfer(download_link, fp);
            }

            function onDirectorySuccess(parent) {
                // Directory created successfuly
            }

            function onDirectoryFail(error) {
                //Error while creating directory
                alert("Unable to create new directory: " + error.code);
            }

            function fileSystemFail(evt) {
                //Unable to access file system
                alert(evt.target.error.code);
            }
        }

        function filetransfer(download_link, fp) {
            var fileTransfer = new FileTransfer();
            // File download function with URL and local path
            fileTransfer.download(download_link, cordova.file.dataDirectory + id.ChatMedia.name,
                function (entry) {
                    alert("download complete: " + entry.fullPath);
                },
                function (error) {
                    //Download abort errors or download failed errors
                    alert("download error source " + error.source);
                    //alert("download error target " + error.target);
                    //alert("upload error code" + error.code);
                }
            );
        }

        var template = '<ion-popover-view class="chatMedia"><ion-content style="padding:12px"> <i ng-click="attachMedia(1)" class="icon ion-ios-camera attachIcons"></i> <i ng-click="attachMedia(0)" class="icon ion-images attachIcons"></i></ion-content></ion-popover-view>';

        $scope.popover = $ionicPopover.fromTemplate(template, {
            scope: $scope
        });
        $scope.openPopover = function ($event) {
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {
                $scope.popover.show($event);
            }
        };
        $scope.closePopover = function () {
            $scope.popover.hide();
        };
        //Cleanup the popover when we're done with it!
        $scope.$on('$destroy', function () {
            $scope.popover.remove();
        });

        $ionicModal.fromTemplateUrl('image-modal.html', {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function (modal) {
            $scope.modal = modal;
        });
        $scope.oImage = []
        $scope.zoomimng = function (id) {
            $scope.oImage.src = document.getElementById('chatMedia' + id).src;
            $ionicSlideBoxDelegate.slide(0);
            $scope.modal.show();
        };

        $scope.closeModal = function () {
            $scope.modal.hide();
        };

        // Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function () {
            $scope.modal.remove();
        });
        $scope.saveMessage = function (content) {
                /*$ionicLoading.show({
                    template: '...'
                });*/

                if (!$rootScope.NetworkStatus) {
                    $cordovaToast.show('no connection available', 'short', 'center')
                } else {

                    if (content.text != null) {
                        $ionicLoading.show();
                        ParseService.currentUser(
                            function win(currentUser) {
                                console.log(currentUser)
                                var newObj = {
                                    "message": content.text,
                                    //"eventPush": item.eventPush,
                                    "user": {
                                        //"attributes": {
                                        "objectId": currentUser.id
                                            // }
                                    }
                                }
                                $localstorage.setObject('NewChatMessages', newObj);
                                console.log($localstorage.getObject('NewChatMessages'))
                                $scope.messages.push($localstorage.getObject('NewChatMessages'));
                                $localstorage.setObject('ChatMessages', $scope.messages);
                                $scope.messages = $localstorage.getObject('ChatMessages');
                                //$scope.$apply();
                                var messageObj = {
                                    "thread_id": threadId,
                                    "user": currentUser,
                                    "message": content.text,
                                    "ToUser": $scope.userId,
                                    "FromUser": $rootScope.UserProfile.FullName
                                }

                                console.log(messageObj);

                                ParseService.postMessage(messageObj,
                                    function successPost(results) {
                                        $ionicLoading.hide();
                                        console.log(results);
                                        //$scope.messages.push(results);
                                        var obj = {
                                            url: "http://default-environment.2dmee9yyxr.ap-southeast-1.elasticbeanstalk.com/gage/PushChat",
                                            data: {
                                                "message": content.text,
                                                "messagea_id": results.id,
                                                "eventPush": "new_message",
                                                "channel": threadId,
                                                "userId": $rootScope.user.id
                                            },
                                            method: "POST"
                                        };
                                        console.log(obj);

                                        PusherTrigger.triggerEvent(obj,
                                            function results(res, status) {
                                                content.text = null;
                                                console.log("-- Good ---");
                                                console.log(res)
                                            },
                                            function fail(res, status) {
                                                console.log('Fail');
                                                console.log(res);
                                            }
                                        )

                                        setTimeout(function () {
                                            $ionicScrollDelegate.scrollBottom();
                                            content.text = null;
                                            document.querySelector("#commentBox").value = "";
                                            $scope.$apply();
                                        }, 100)


                                    },
                                    function errorPost(error) {
                                        content.text = null;
                                        $ionicLoading.hide();
                                        $scope.messages.pop();
                                        console.log('error post');
                                        var obj = {
                                            title: "Oh no!",
                                            template: "We were unable to post your comment. Please try again."
                                        };

                                        UtilFunctions.setAlert(obj);
                                    }
                                )
                            },
                            function fail(error) {
                                $ionicLoading.hide();
                                console.log('fail on currentuser');
                            }
                        )
                    }
                }
            }
            // Intialize the controller 
        if ($rootScope.NetworkStatus) {
            if ($localstorage.get(threadId) == undefined)
                $scope.messages = []
            else
                $scope.messages = $localstorage.getObject(threadId);
            console.log($scope.messages)
            $ionicScrollDelegate.scrollBottom();
            $scope.subscribe();
            $scope.chatHistory();
        } else {
            $scope.messages = $localstorage.getObject(threadId);
            $ionicScrollDelegate.scrollBottom();
        }
        //ionicMaterialInk.displayEffect();
    })
    .controller('PatientHomeCtrl', function ($scope, $rootScope, $state, $ionicPopup, $ionicScrollDelegate, $ionicLoading, $localstorage, $ionicHistory, $cordovaToast, ionicMaterialInk) {
        $scope.Patient = {};
        $scope.selectedDiv = 'Patient';
        $scope.Doctorsearched = false;
        $scope.searchList = [];
        $scope.PatientSearchList = [];
        $scope.Status = {
            statusType: ''
        }
        console.log('PatientHomeCtrl');
        $scope.ViewProfile = function () {
            $state.go('tab.PatientProfile');
        }
        $scope.showTabCantent = function (option) {
            $scope.selectedDiv = option; //'Client';
            $scope.Doctorsearched = false;
            $ionicScrollDelegate.scrollTop();
        }

        $scope.chat = function (item) {

            $rootScope.chatUser = item;
            $rootScope.chatArchived = item.IsArchive;
            //console.log($rootScope.chatUser.get('PatientProfileObjectId').get('ProfileImage').url())

        }
        $scope.phoneCall = function (item) {
            if (item.IsCallAllowed) {
                if (item.ExotelNumber != 0) {
                    var confirmPopup = $ionicPopup.confirm({
                        title: 'CureBooth Admin',
                        template: 'You will be charged ' + item.ChargesPerMin + ' credits/min., minimum charges is ' + item.FirstMin + ' credits',
                        cancelText: 'Cancel',
                        okText: 'Call'
                    });

                    confirmPopup.then(function (res) {
                        if (res) {
                            window.location = "tel:0" + item.ExotelNumber;
                        } else {
                            console.log('You are not sure');
                        }
                    });

                } //window.open('tel:0' + call, '_system');
                else
                    $rootScope.showAlert('No number to call')
            } else if (item.IsOfflineCall && item.IsPriority) {
                if (item.ExotelNumber != 0) {
                    var confirmPopup = $ionicPopup.confirm({
                        title: 'CureBooth Admin',
                        template: 'You will be charged ' + item.ChargesPerMin + ' credits/min., minimum charges is ' + item.FirstMin + ' credits',
                        cancelText: 'Cancel',
                        okText: 'Call'
                    });

                    confirmPopup.then(function (res) {
                        if (res) {
                            window.location = "tel:0" + item.ExotelNumber;
                        } else {
                            console.log('You are not sure');
                        }
                    });

                } //window.open('tel:0' + call, '_system');
                else
                    $rootScope.showAlert('No number to call')
            } else
                $rootScope.showAlert('Doctor is offline ')
                //window.open('tel:900300400')
        }

        // list of status
        $scope.getStatusType = function () {
                // $ionicLoading.show();
                var query = new Parse.Query('StatusType');
                query.find({
                    success: function (results) {
                        $ionicLoading.hide();
                        if (results.length > 0) {
                            $scope.StatusType = results
                        }
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        //alert("Error: " + error.code + " " + error.message);
                    }
                });
            }
            // User current status
        $scope.getStatus = function () {
                // $ionicLoading.show();
                var query = new Parse.Query('UserStatus');
                query.equalTo('UserId', $rootScope.user.id);
                query.find({
                    success: function (results) {

                        $ionicLoading.hide();
                        if (results.length > 0) {
                            $scope.Status.statusType = results[0].get('StatusName')
                                //alert(object.id + ' - ' + object.get('playerName'));
                        }
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        //alert("Error: " + error.code + " " + error.message);
                    }
                });
            }
            // User current status
        function calculateAge(dd) { // birthday is a date
            console.log(dd)
            var ageDifMs = Date.now() - dd.getTime();
            var ageDate = new Date(ageDifMs); // miliseconds from epoch
            return Math.abs(ageDate.getUTCFullYear() - 1970);
        }
        $scope.DoctorList = {};
        $scope.DoctorListfn = function (id) {
            console.log(id)
            Parse.Cloud.run('AdminDoctorList', {
                PatientProfileId: id
            }, {
                success: function (status) {
                    $ionicLoading.hide();
                    $scope.DoctorList1 = [];
                    if (status.length > 0) {
                        for (i = 0; i < status.length; i++) {
                            if (status[i].get('user1') == $rootScope.UserProfile.UserObjectId) {
                                var ProfileImage;
                                if (status[i].get('profile2').get('ProfileImage') != undefined) {
                                    ProfileImage = status[i].get('profile2').get('ProfileImage').url();
                                } else {
                                    ProfileImage = "img/patient_icon_default.png";
                                }
                                var IsCallAllowed;
                                if (status[i].get('profile2').get('StatusPointer') != undefined) {
                                    IsCallAllowed = status[i].get('profile2').get('StatusPointer').get('IsCallAllowed');
                                } else {
                                    IsCallAllowed = "";
                                }
                                var StatusName;
                                if (status[i].get('profile2').get('StatusPointer') != undefined) {
                                    StatusName = status[i].get('profile2').get('StatusPointer').get('StatusName');
                                } else {
                                    StatusName = "";
                                }
                                var ExotelNumber;
                                if (status[i].get('profile2').get('UserPointer') != undefined) {
                                    ExotelNumber = status[i].get('profile2').get('UserPointer').get('ExotelNumber');
                                } else {
                                    ExotelNumber = "";
                                }

                                var temp = {
                                    IsApproved: status[i].attributes.IsApproved,
                                    LinkingId: status[i].id,
                                    DoctorUserObjectId: status[i].attributes.profile2.attributes.UserObjectId,
                                    id: status[i].attributes.profile2.id,
                                    BriefOverview: status[i].attributes.profile2.attributes.BriefOverview,
                                    ChargesPerMin: status[i].attributes.profile2.attributes.ChargesPerMin,
                                    Clinic: status[i].attributes.profile2.attributes.Clinic,
                                    FirstMin: status[i].attributes.profile2.attributes.FirstMin,
                                    ForMins: status[i].attributes.profile2.attributes.ForMins,
                                    FullName: status[i].attributes.profile2.attributes.FullName,
                                    IsOfflineCall: status[i].attributes.profile2.attributes.IsOfflineCall,
                                    Phone: status[i].attributes.profile2.attributes.Phone,
                                    Qualification: status[i].attributes.profile2.attributes.Qualification,
                                    Speciality: status[i].attributes.profile2.attributes.Specialist.attributes.Speciality,
                                    ProfileImage: ProfileImage,
                                    IsCallAllowed: IsCallAllowed,
                                    StatusName: StatusName,
                                    ExotelNumber: ExotelNumber,
                                    RecommendCounter: status[i].attributes.profile2.attributes.RecommendCounter,

                                }
                                $scope.DoctorList1.push(temp);

                            } else {
                                var ProfileImage;
                                if (status[i].get('profile1').get('ProfileImage') != undefined) {
                                    ProfileImage = status[i].get('profile1').get('ProfileImage').url();
                                } else {
                                    ProfileImage = "img/patient_icon_default.png";
                                }
                                var IsCallAllowed;
                                if (status[i].get('profile1').get('StatusPointer') != undefined) {
                                    IsCallAllowed = status[i].get('profile1').get('StatusPointer').get('IsCallAllowed');
                                } else {
                                    IsCallAllowed = "";
                                }
                                var StatusName;
                                if (status[i].get('profile1').get('StatusPointer') != undefined) {
                                    StatusName = status[i].get('profile1').get('StatusPointer').get('StatusName');
                                } else {
                                    StatusName = "";
                                }
                                var ExotelNumber;
                                if (status[i].get('profile1').get('UserPointer') != undefined) {
                                    ExotelNumber = status[i].get('profile1').get('UserPointer').get('ExotelNumber');
                                } else {
                                    ExotelNumber = "";
                                }

                                var temp = {
                                    IsApproved: status[i].attributes.IsApproved,
                                    LinkingId: status[i].id,
                                    DoctorUserObjectId: status[i].attributes.profile1.attributes.UserObjectId,
                                    id: status[i].attributes.profile1.id,
                                    BriefOverview: status[i].attributes.profile1.attributes.BriefOverview,
                                    ChargesPerMin: status[i].attributes.profile1.attributes.ChargesPerMin,
                                    Clinic: status[i].attributes.profile1.attributes.Clinic,
                                    FirstMin: status[i].attributes.profile1.attributes.FirstMin,
                                    ForMins: status[i].attributes.profile1.attributes.ForMins,
                                    FullName: status[i].attributes.profile1.attributes.FullName,
                                    IsOfflineCall: status[i].attributes.profile1.attributes.IsOfflineCall,
                                    Phone: status[i].attributes.profile1.attributes.Phone,
                                    Qualification: status[i].attributes.profile1.attributes.Qualification,
                                    Speciality: status[i].attributes.profile1.attributes.Specialist.attributes.Speciality,
                                    ProfileImage: ProfileImage,
                                    IsCallAllowed: IsCallAllowed,
                                    StatusName: StatusName,
                                    ExotelNumber: ExotelNumber,
                                    RecommendCounter: status[i].attributes.profile1.attributes.RecommendCounter,

                                }
                                $scope.DoctorList1.push(temp);

                            }
                            //console.log($scope.DoctorList);
                        }
                        //console.log($scope.DoctorList);
                        //
                        $localstorage.setObject('PatientDoctorList', $scope.DoctorList1);
                        $scope.DoctorList = $localstorage.getObject('PatientDoctorList');
                        $scope.$apply();
                    } else {
                        $localstorage.setObject('PatientDoctorList', null);
                        $scope.DoctorList = $localstorage.getObject('PatientDoctorList');
                        $scope.$apply();
                    }
                    // te Profile table updated successfully
                },
                error: function (error) {
                    // debugger;
                    // error
                }
            });
        }
        $scope.chatListfn = function (id) {
            Parse.Cloud.run('ChatList', {
                ProfileId: id,
                IsDoctor: 0
            }, {
                success: function (status) {
                    if (status.length > 0) {
                        $scope.ChatList1 = [];
                        for (i = 0; i < status.length; i++) {
                            var ProfileImage;
                            if (status[i].get('DoctorProfileObjectId').get('ProfileImage') != undefined) {
                                ProfileImage = status[i].get('DoctorProfileObjectId').get('ProfileImage').url();
                            } else {
                                ProfileImage = "img/patient_icon_default.png";
                            }
                            var RecentMsg;
                            if (status[i].get('RecentMsg') != undefined) {
                                RecentMsg = status[i].get('RecentMsg').get('message');
                            } else {
                                RecentMsg = "";
                            }
                            var IsCallAllowed;
                            if (status[i].get('DoctorProfileObjectId').get('StatusPointer') != undefined) {
                                IsCallAllowed = status[i].get('DoctorProfileObjectId').get('StatusPointer').get('IsCallAllowed');
                            } else {
                                IsCallAllowed = "";
                            }
                            var StatusName;
                            if (status[i].get('DoctorProfileObjectId').get('StatusPointer') != undefined) {
                                StatusName = status[i].get('DoctorProfileObjectId').get('StatusPointer').get('StatusName');
                            } else {
                                StatusName = "";
                            }
                            var ExotelNumber;
                            if (status[i].get('DoctorProfileObjectId').get('UserPointer') != undefined) {
                                ExotelNumber = status[i].get('DoctorProfileObjectId').get('UserPointer').get('ExotelNumber');
                            } else {
                                ExotelNumber = "";
                            }
                            var temp = {
                                chatThreadId: status[i].attributes.chatThreadId,
                                UserObjectId: status[i].attributes.DoctorUserObjectId,
                                PatientUserObjectId: status[i].attributes.PatientUserObjectId,
                                IsFollowed: status[i].attributes.IsFollowed,
                                IsPriority: status[i].attributes.IsPriority,
                                IsVerfied: status[i].attributes.IsVerfied,
                                id: status[i].attributes.DoctorProfileObjectId.id,
                                BriefOverview: status[i].attributes.DoctorProfileObjectId.attributes.BriefOverview,
                                ChargesPerMin: status[i].attributes.DoctorProfileObjectId.attributes.ChargesPerMin,
                                Clinic: status[i].attributes.DoctorProfileObjectId.attributes.FirstMin,
                                FirstMin: status[i].attributes.DoctorProfileObjectId.attributes.BriefOverview,
                                FirstName: status[i].attributes.DoctorProfileObjectId.attributes.FirstName,
                                ForMins: status[i].attributes.DoctorProfileObjectId.attributes.ForMins,
                                FullName: status[i].attributes.DoctorProfileObjectId.attributes.FullName,
                                IsOfflineCall: status[i].attributes.DoctorProfileObjectId.attributes.IsOfflineCall,
                                LastName: status[i].attributes.DoctorProfileObjectId.attributes.LastName,
                                Phone: status[i].attributes.DoctorProfileObjectId.attributes.Phone,
                                Qualification: status[i].attributes.DoctorProfileObjectId.attributes.Qualification,
                                Speciality: status[i].attributes.DoctorProfileObjectId.attributes.Speciality,
                                ProfileImage: ProfileImage,
                                IsCallAllowed: IsCallAllowed,
                                StatusName: StatusName,
                                ExotelNumber: ExotelNumber,
                                RecentMsg: RecentMsg,
                                ProfileLinkId: status[i].id,
                                isMute: status[i].attributes.PatientMuted
                            }
                            $scope.ChatList1.push(temp);
                        }
                        $localstorage.setObject('PatientChatList', $scope.ChatList1);
                        $scope.ChatList = $localstorage.getObject('PatientChatList');
                        $scope.$apply();

                    }
                },
                error: function (error) {
                    // debugger;
                    // error
                }
            });
        }
        $scope.DocSearch = function (search) {
            if (!$rootScope.NetworkStatus) {
                var alertPopup = $ionicPopup.alert({
                    title: 'CureBooth Admin',
                    cssClass: 'balance',
                    template: "Doctor search needs network connectivity !"
                });
                alertPopup.then(function (res) {
                    //navigator.app.exitApp();
                })
            } else {
                // $ionicLoading.show();
                Parse.Cloud.run('DocSearch', {
                    SearchString: search
                }, {
                    success: function (status) {

                        if (status.length > 0) {
                            $scope.searchList = [];
                            $scope.Doctorsearched = true;
                            $localstorage.setObject('searchList', status)
                            $scope.searchList = $localstorage.getObject('searchList')
                            $scope.$apply;
                        } else {
                            $scope.searchList = [];
                        }

                        $ionicLoading.hide();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                    }
                });
            }
        };
        //add new patient
        $scope.Validate = function () {
            var ErrorArr = new Array();
            if (typeof $scope.user === 'undefined' || $scope.user === null)
                throw 'Basic info is not entered';
            else {
                if (typeof $scope.Patient.Name === 'undefined' || $scope.Patient.Name === null) {
                    $rootScope.showAlert('Please enter some valid value into - Name.');
                    ErrorArr.push('name required.');
                }
                /* else if (typeof $scope.Patient.email === 'undefined' || $scope.Patient.email === null) {
                                    $rootScope.showAlert('Please enter some valid value into - Email');
                                    ErrorArr.push('Client \'Surname\' is required.');
                                }*/
                else if (typeof $scope.Patient.phone === 'undefined' || $scope.Patient.phone === null) {
                    $rootScope.showAlert("Please enter Phone number");
                    ErrorArr.push('Phone is required.');
                }

            }
            if (ErrorArr.length > 0)
                return false;

            return true; //_isValidVM
        }
        $scope.AddNewPatient = function () {
                if (!$rootScope.NetworkStatus) {
                    $cordovaToast.show('no connection available', 'short', 'center')
                } else {
                    if ($scope.Validate()) {
                        // $ionicLoading.show();
                        Parse.Cloud.run('AddNewPatient', {
                            //DoctorUserId: $rootScope.user.id,
                            // DoctorProfileId: $rootScope.UserProfile.objectId,
                            Phone: $scope.Patient.phone,
                            Name: $scope.Patient.Name,
                            Email: $scope.Patient.email,
                            AdminProfileId: $rootScope.UserProfile.objectId
                        }, {
                            success: function (results) {
                                $ionicLoading.hide();
                                if (results != undefined) {
                                    $scope.Patient = [];
                                    $scope.PatientSearchList = [];
                                    $scope.addnewPatient = false;
                                    $rootScope.showAlert("Patient added successfully");
                                    //$scope.FriendRequest = results;
                                } else {
                                    $scope.FriendRequest = null;
                                }

                                // te Profile table updated successfully
                            },
                            error: function (error) {
                                $rootScope.showAlert(error.message);
                                $ionicLoading.hide();
                                // error
                            }
                        });
                    }
                }
            }
            //Search Patient by phone number
        $scope.PatientProfileByPhone = function (search) {
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {
                if (search.toString().length != 10) {
                    $rootScope.showAlert('Please enter 10 digit mobile number');
                } else {
                    // $ionicLoading.show();
                    Parse.Cloud.run('PatientSearch', {
                        Phone: search
                    }, {
                        success: function (data) {
                            $ionicLoading.hide();
                            if (data != undefined) {
                                $scope.PatientSearchList = data;
                                $scope.addnewPatient = false;
                                $scope.PatientSearchResult = true;
                            } else {
                                $scope.PatientSearchList = [];
                                $scope.addnewPatient = true;
                                $scope.Patient.phone = search;
                            }
                            $scope.$apply;
                        },
                        error: function (error) {
                            console.log(error)
                            $scope.PatientSearchList = [];
                            $scope.addnewPatient = true;
                            $scope.Patient.phone = search;
                            $ionicLoading.hide();
                        }
                    });
                }
            }
        };
        // Call History Funtion
        $scope.callhistoryfn = function (id) {
            if ($localstorage.getObject('PatientCalllist') === null) {} // $ionicLoading.show();
            Parse.Cloud.run('GetCallHistory', {
                UserProfileId: id
            }, {
                success: function (results) {
                    $ionicLoading.hide();
                    $scope.calllist_tmp = [] // results;
                    for (i = 0; i < results.length; i++) {
                        if ($rootScope.user.id == results[i].get("ToProfileObjectId").get("UserObjectId")) {
                            if (results[i].get("CallStatusType") == 1) {
                                results[i]['Incoming'] = 1;
                            } else if (results[i].get("CallStatusType") == 3) {
                                results[i]['Incoming'] = 3;
                            } else if (results[i].get("CallStatusType") == 4) {
                                results[i]['Incoming'] = 4;
                            } else if (results[i].get("CallStatusType") == 1 && results[i].get("Duration") == '0') {
                                results[i]['Incoming'] = 5;
                            }
                            $scope.calllist.push(results[i]);
                        } else if ($rootScope.user.id == results[i].get("FromProfileObjectId").get("UserObjectId")) {
                            if (results[i].get("CallStatusType") == 1) {
                                results[i]['Incoming'] = 1;
                            } else if (results[i].get("CallStatusType") == 3) {
                                results[i]['Incoming'] = 3;
                            } else if (results[i].get("CallStatusType") == 4) {
                                results[i]['Incoming'] = 4;
                            } else if (results[i].get("CallStatusType") == 1 && results[i].get("Duration") == '0') {
                                results[i]['Incoming'] = 5;
                            }
                            $scope.calllist_tmp.push(results[i]);
                        }
                    }
                    $localstorage.setObject('PatientCalllist', results);
                    $scope.calllist = $localstorage.getObject('PatientCalllist');
                    $scope.$apply();
                },
                error: function (error) {
                    $ionicLoading.hide();
                    // error
                }
            });
        };
        // Change User Status

        $scope.status = function () {
            // $ionicLoading.show();
            Parse.Cloud.run('UserStatus', {
                StatusName: $scope.Status.statusType
            }, {
                success: function (status) {
                    // debugger;
                    $ionicLoading.hide();
                    // te Profile table updated successfully
                },
                error: function (error) {
                    $ionicLoading.hide();
                    // debugger;
                    // error
                }
            });
        }
        $scope.ViewDoctor = function (item) {

                if ($scope.Doctorsearched) {
                    $rootScope.DrData = item;
                    $state.go('tab.DrProfile');
                } else {
                    $rootScope.DrPtData = item;
                    console.log($rootScope.DrPtData.IsApproved)
                    $state.go('tab.AdminAddPatient');
                }

            }
            // Doctor profile
        $scope.showDetails = function (data) {
            console.log(data)
            $rootScope.DrData = data;
            $state.go('tab.DrProfile', {
                //clear: true
            });

        }
        $rootScope.profile = {}
        $scope.getProfile = function () {
                if ($localstorage.getObject('PatientProfile') == null) {} // $ionicLoading.show();
                Parse.Cloud.run('GetProfile', {
                    UserObjectId: $rootScope.user.id,
                }, {
                    success: function (data) {
                        $ionicLoading.hide();
                        var results = [];
                        results = data;
                        if (results != undefined && results != null) {
                            $localstorage.setObject('PatientProfile', results);
                            $scope.DoctorListfn(results.id);
                            //$scope.callhistoryfn(results.id);
                            //$scope.chatListfn(results.id);
                            $rootScope.user.ProfileId = results.id;
                            //$rootScope.UserProfile = results;
                            $rootScope.UserName = results.get('FullName');
                            if (results.get('ProfileImage') != undefined) {
                                $rootScope.ProfileImage = results.get('ProfileImage').url();
                                results.set("ProfileImg", results.get('ProfileImage').url());
                            } else {
                                $rootScope.ProfileImage = "img/patient_icon_default.png";
                                results.set("ProfileImg", "img/patient_icon_default.png");
                                //results.ProfileImage = "img/patient_icon_default.png";
                            }
                            $localstorage.setObject('PatientProfile', results);
                            $rootScope.UserProfile = $localstorage.getObject('PatientProfile')
                            $scope.$apply();
                        }
                        //console.log($localstorage.getObject('PatientProfile'))
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                    }
                });
            }
            // add money to patient wallet
        $scope.AddWallet = function (item, amt) {
            //debugger;
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {
                // $ionicLoading.show();
                Parse.Cloud.run('TransferCredits', {
                    FromUserId: $rootScope.user.id,
                    ToUserId: item.UserObjectId,
                    Amount: amt,
                    FromProfileObjectId: $rootScope.user.ProfileId,
                    ToProfileObjectId: item.objectId
                }, {
                    success: function (status) {
                        // debugger;
                        $ionicLoading.hide();
                        $scope.Recharge = false;
                        $scope.Rechargebtn = false;
                        $scope.PatientSearchList = [];
                        $scope.PatientSearchResult = false;
                        $scope.Patient.Amount = '';
                        $scope.selectedDiv = 'Patient';
                        //$rootScope.showAlert('Amount added successfully in Patient wallet');
                        // te Profile table updated successfully
                        $cordovaToast.show("Health Credits added successfully to Patient's Account", 'short', 'center')
                            .then(function (success) {
                                // success
                            }, function (error) {
                                // error
                            });
                        $scope.$apply;
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        $scope.PatientSearchList = [];
                        $scope.PatientSearchResult = false;
                        $rootScope.showAlert(error.message);
                        // debugger;
                        // error
                    }
                });
            }
        }

        // Intialize the controller 
        if ($rootScope.NetworkStatus) {
            $scope.DoctorList = $localstorage.getObject('PatientDoctorList');
            //$scope.ChatList = $localstorage.getObject('PatientChatList');
            //$scope.calllist = $localstorage.getObject('PatientCalllist');
            $rootScope.UserProfile = $localstorage.getObject('PatientProfile')
            $scope.getProfile();
        } else {
            $scope.DoctorList = $localstorage.getObject('PatientDoctorList');
            //$scope.ChatList = $localstorage.getObject('PatientChatList');
            //$scope.calllist = $localstorage.getObject('PatientCalllist');
            $rootScope.UserProfile = $localstorage.getObject('PatientProfile')

        }
        //ionicMaterialInk.displayEffect();
    })
    .controller('PatientProfileCtrl', function ($scope, $state, $ionicLoading, $rootScope, $http, $ionicModal, $ionicPopup, $localstorage, $cordovaCamera, $ionicScrollDelegate, $cordovaToast, ionicMaterialInk) {
        $scope.profile = {};
        $scope.editable = true;
        $scope.edit = function (id) {
            if ($rootScope.NetworkStatus)
                $scope.editable = id;
            else
                $cordovaToast.show('no connection available', 'short', 'center')

        }

        $scope.selectedDiv = 'Profile';
        $scope.Doctorsearched = false;
        $scope.searchList = [];
        $scope.Status = {
            statusType: ''
        }
        $scope.showTabCantent = function (option) {
                $scope.selectedDiv = option; //'Client';
                $scope.Doctorsearched = false;
                $ionicScrollDelegate.scrollTop();
            }
            // To retirve dat form table
        $scope.getProfile = function () {
            $scope.profile = $localstorage.getObject('PatientProfile')
                //$ionicLoading.show();
            Parse.Cloud.run('GetProfile', {
                UserObjectId: $rootScope.user.id,
            }, {
                success: function (results) {
                    $ionicLoading.hide();
                    if (results != undefined && results != null) {
                        $rootScope.user.ProfileId = results.id;
                        $scope.UserProfile1 = results;
                        $scope.profile = results;
                        $scope.profile.id = results.id;
                        $rootScope.UserName = results.get('FirstName');
                        $scope.profile.FullName = results.get('FullName');
                        $scope.profile.Gender = results.get('Gender');
                        $scope.profile.Health_Summary = results.get('Health_Summary')
                        $scope.profile.Health_Conditions = results.get('Health_Conditions');
                        $scope.profile.Address = results.get('Address');
                        if (results.get('ProfileImage') != undefined) {
                            $scope.ProfileImage = results.get('ProfileImage').url();
                        } else {
                            $scope.ProfileImage = "img/patient_icon_default.png";
                        }
                        if (results.get('DOB') != undefined) {
                            $scope.profile.Age = calculateAge(results.get('DOB'))
                            console.log($scope.profile.Age)
                            if ($scope.profile.Age > 0)
                                $scope.profile.Age = $scope.profile.Age + ' Years'
                        }
                        //$scope.Status.statusType = results.get('StatusPointer').id;
                    }
                },
                error: function (error) {
                    $ionicLoading.hide();
                    //$rootScope.showAlert(error);
                }
            });
        }

        function calculateAge(dd) { // birthday is a date
            console.log(dd)
            var ageDifMs = Date.now() - dd.getTime();
            var ageDate = new Date(ageDifMs); // miliseconds from epoch
            return Math.abs(ageDate.getUTCFullYear() - 1970);
        }
        $scope.updateProfile = function () {
            // $ionicLoading.show();
            var point = $scope.UserProfile1;
            point.set("FullName", $scope.profile.FullName);
            point.set("LastName", $scope.profile.LastName);
            point.set("DOB", $scope.profile.DOB);
            point.set("Gender", $scope.profile.Gender);
            point.set("Health_Summary", $scope.profile.Health_Summary);
            point.set("Health_Conditions", $scope.profile.Health_Conditions);
            point.set("Address", $scope.profile.Address);
            // Save
            point.save(null, {
                success: function (point) {
                    $ionicLoading.hide();
                    $cordovaToast.show('Profile Updated Successfully', 'short', 'center')
                        //$rootScope.showAlert('Profile Saved successfully.');
                    $scope.editable = true;
                },
                error: function (point, error) {
                    $ionicLoading.hide();
                    $rootScope.showAlert(error);
                }
            });
        }
        $scope.imageData = "";


        // Upload Image
        $scope.uploadImg = function () {
            // $ionicLoading.show();
            var ProfileParse = $scope.UserProfile1;
            var objProfileLink = $scope.UserProfile1;
            if ($scope.imageData != "") {
                var parseFile = new Parse.File("ProfileImg.jpg", {
                    base64: $scope.imageData
                });
                objProfileLink.set("ProfileImage", parseFile);
                console.log('create profile link');
                objProfileLink.save(null, {
                    success: function (employee) {
                        var alertPopup = $ionicPopup.alert({
                            title: 'CureBooth Admin',
                            cssClass: 'balance',
                            template: 'Profile image updated successfully.'
                        });
                        alertPopup.then(function (res) {
                            $scope.closeProfileModal();
                        });
                        $ionicLoading.hide();
                    },
                    error: function (employee, error) {
                        $ionicLoading.hide();
                        //alert('error:' + error.message.toString());
                    }
                });
            }
        }

        document.addEventListener("deviceready", function () {
            $scope.takePhotoPatient = function (data) {
                console.log(data)
                if (data == 1)
                    $scope.cemera();
                else
                    $scope.gallery();
            }
        }, false);
        $scope.cemera = function () {
            var options = {
                quality: 65,
                destinationType: Camera.DestinationType.DATA_URL,
                sourceType: Camera.PictureSourceType.CAMERA,
                allowEdit: true,
                encodingType: Camera.EncodingType.JPEG,
                targetWidth: 100,
                targetHeight: 100,
                popoverOptions: CameraPopoverOptions,
                saveToPhotoAlbum: false,
                correctOrientation: true
            };

            $cordovaCamera.getPicture(options).then(function (imageData) {
                $scope.imageData = imageData;
                $scope.ProfileImage = "data:image/jpeg;base64," + imageData;
            }, function (err) {
                // error
            });

        }
        $scope.gallery = function () {
            var options = {
                quality: 65,
                destinationType: Camera.DestinationType.DATA_URL,
                sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
                allowEdit: true,
                encodingType: Camera.EncodingType.JPEG,
                targetWidth: 100,
                targetHeight: 100,
                popoverOptions: CameraPopoverOptions,
                saveToPhotoAlbum: false,
                correctOrientation: true
            };

            $cordovaCamera.getPicture(options).then(function (imageData) {
                $scope.imageData = imageData;
                $scope.ProfileImage = "data:image/jpeg;base64," + imageData;
            }, function (err) {
                // error
            });

        }
        $ionicModal.fromTemplateUrl('profile-img.html', {
            scope: $scope,
            animation: 'fade-in-up'
        }).then(function (modal) {
            $scope.profileImgmodal = modal;
        });
        $scope.openProfileModal = function () {
            if ($rootScope.NetworkStatus)
                $scope.profileImgmodal.show();
            else
                $cordovaToast.show('no connection available', 'short', 'center')
                //$scope.profileImgmodal.show();
        };
        $scope.closeProfileModal = function () {
            $scope.profileImgmodal.hide();
        };
        //Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function () {
            $scope.profileImgmodal.remove();
        });
        // Intialize the controller 
        if ($rootScope.NetworkStatus) {
            $scope.profile = $localstorage.getObject('PatientProfile')
            $scope.getProfile();
        } else {
            $scope.profile = $localstorage.getObject('PatientProfile')
        }

        //ionicMaterialInk.displayEffect();
    })
    .controller('DoctorSearchCtrl', function ($scope, $state, $ionicLoading, $rootScope, $http, $localstorage, $ionicPopover, ionicMaterialInk) {
        $scope.selectedDiv = 'browse'
        $scope.showTabCantent = function (option) {
            $scope.selectedDiv = option; //'Client';
            $ionicScrollDelegate.scrollTop();
        }
        $scope.search = '';
        $scope.SearchList = [];
        $scope.DocSearch = function (search) {
            if (!$rootScope.NetworkStatus) {
                var alertPopup = $ionicPopup.alert({
                    title: 'CureBooth Admin',
                    cssClass: 'balance',
                    template: "Doctor search needs network connectivity !"
                });
                alertPopup.then(function (res) {
                    //navigator.app.exitApp();
                })
            } else {
                if (search == null) {
                    return false
                }
                // $ionicLoading.show();
                Parse.Cloud.run('DocSearch', {
                    SearchString: search
                }, {
                    success: function (status) {

                        if (status.length > 0) {
                            $scope.searchList = [];
                            $localstorage.setObject('searchList', status)
                            $scope.searchList = $localstorage.getObject('searchList')
                                //$scope.searchList = JSON.stringify(status);
                            $scope.$apply;
                        } else {
                            $scope.searchList = [];
                        }

                        $ionicLoading.hide();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                    }
                });
            }
        };
        $scope.pindata = $rootScope.PinCode;;
        $scope.AdvanceDoctorSearch = function (pincode, Speciality) {
            if (!$rootScope.NetworkStatus) {} else {
                // $ionicLoading.show();
                //$scope.pindata = "";
                if (pincode == null || pincode == "")
                    $scope.pindata = $rootScope.PinCode;
                else
                    $scope.pindata = pincode;
                if (Speciality == "None")
                    Speciality = ""
                Parse.Cloud.run('AdvanceDoctorSearch', {
                    Pincode: $scope.pindata,
                    SpecialityId: Speciality
                }, {
                    success: function (status) {

                        if (status.length > 0) {
                            $scope.searchList = [];
                            $localstorage.setObject('searchList', status)
                            $scope.searchList = $localstorage.getObject('searchList')
                                //$scope.searchList = JSON.stringify(status);
                            $scope.$apply;
                        } else {
                            $scope.searchList = [];
                        }

                        $ionicLoading.hide();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                    }
                });
            }
        };
        $scope.GetDoctorSpeciality = function () {
            if (!$rootScope.NetworkStatus) {} else {
                // $ionicLoading.show();
                Parse.Cloud.run('GetDocSpeciality', {
                    //SearchString: search
                }, {
                    success: function (status) {

                        if (status.length > 0) {
                            $scope.searchList = [];
                            $localstorage.setObject('DoctorSpeciality', status)
                            $scope.DoctorSpeciality = $localstorage.getObject('DoctorSpeciality');
                            $scope.DoctorSpeciality.unshift({
                                    "IsActive": true,
                                    "Priority": 0,
                                    "Speciality": "None",
                                    "__type": "Object",
                                    "className": "DoctorSpeciality",
                                    "createdAt": "2016-04-05T17:08:13.967Z",
                                    "objectId": "fZrvQx3gMZ",
                                    "updatedAt": "2016-04-05T17:09:34.584Z"
                                })
                                //$scope.searchList = JSON.stringify(status);
                            $scope.$apply;
                        }

                        $ionicLoading.hide();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                    }
                });
            }
        };
        $scope.searchPopover = function (pin, spelty) {
            $scope.AdvanceDoctorSearch(pin, spelty)
            $scope.closePopover();
        };
        // .fromTemplateUrl() method
        $ionicPopover.fromTemplateUrl('my-popover.html', {
            scope: $scope
        }).then(function (popover) {
            $scope.popover = popover;
        });


        $scope.openPopover = function ($event) {
            $scope.Popoverdata = $scope.DoctorSpeciality;
            $scope.popover.show($event);
        };
        $scope.closePopover = function () {
            $scope.popover.hide();
        };
        //Cleanup the popover when we're done with it!
        $scope.$on('$destroy', function () {
            $scope.popover.remove();
        });
        // Execute action on hide popover
        $scope.$on('popover.hidden', function (data) {
            // Execute action
        });
        // Execute action on remove popover
        $scope.$on('popover.removed', function () {
            // Execute action
        });
        $scope.GetDoctorSpeciality();
        $scope.AdvanceDoctorSearch();
        // Doctor profile
        $scope.showDetails = function (data) {
                console.log(data)
                $rootScope.DrData = data;
                $state.go('tab.DrProfile', {
                    //clear: true
                });
            }
            //ionicMaterialInk.displayEffect();
    })
    .controller('DrProfileCtrl', function ($scope, $state, $ionicLoading, $rootScope, $http, $ionicPopup, $ionicScrollDelegate, ionicMaterialInk) {
        $scope.DrProfile = [];
        results = $rootScope.DrData;
        console.log(results)
        $scope.selectedDiv = 'Profile';
        $scope.showTabCantent = function (option) {
            $scope.selectedDiv = option; //'Client';
            $scope.Doctorsearched = false;
            $ionicScrollDelegate.scrollTop();
        }
        $scope.isFriend = true;
        $scope.isSent = false;
        $scope.DrProfile.FullName = results.FullName;
        $scope.DrProfile.LastName = results.LastName;
        $scope.DrProfile.BriefOverview = results.BriefOverview;
        $scope.DrProfile.Qualification = results.Qualification;

        $scope.DrProfile.Clinic = results.Clinic;
        $scope.DrProfile.id = results.id;
        $scope.DrProfile.RecommendCounter = results.RecommendCounter;
        if (results.Specialist != undefined) {
            $scope.DrProfile.Speciality = results.Specialist.Speciality;
        } else {
            $scope.DrProfile.Speciality = "";
        }
        if (results.ProfileImage != undefined) {
            $scope.DrProfile.ProfileImage = results.ProfileImage.url;
        } else {
            $scope.DrProfile.ProfileImage = "img/doctor_icon_default.png";
        }
        $scope.chat = function (item) {
                $rootScope.chatUser = item //results.get('DoctorProfileObjectId');
                    //console.log($rootScope.chatUser.get('PatientProfileObjectId').get('ProfileImage').url())

            }
            // is followed
        $scope.SetDoctorFollowed = function (id, amt) {
            //$ionicLoading.show();
            Parse.Cloud.run('SetDoctorFollowed', {
                DocProfileId: id,
                IsFollowed: amt,
                PatProfileId: $rootScope.user.ProfileId
            }, {
                success: function (status) {
                    $ionicLoading.hide();
                    //$rootScope.showAlert('Doctor followed Successfully');
                    // te Profile table updated successfully
                },
                error: function (error) {
                    console.log(error)
                    $ionicLoading.hide();
                    $rootScope.showAlert(error.message);
                    // debugger;
                    // error
                }
            });
        }

        $scope.isFriendFn = function () {
            Parse.Cloud.run('IsRelation', {
                SearchProfileId: results.objectId,
                //PatientProfileObjectId: $rootScope.user.ProfileId
            }, {
                success: function (result) {
                    if (result.get('IsApproved')) {
                        $scope.isFriend = false;
                    } else {
                        $scope.isSent = false;
                        $scope.isFriend = true;
                    }
                    $scope.$apply();
                },
                error: function (error) {
                    console.log(error)
                    $scope.isFriend = true;
                    $scope.isSent = false;
                    $scope.$apply();
                    //$rootScope.showAlert(error.message);
                }
            });
        }

        $scope.phoneCall = function (item) {
            if (item.get("DoctorProfileObjectId").get("StatusPointer").get("IsCallAllowed")) {
                if (item.get("DoctorProfileObjectId").get("UserPointer").get("ExotelNumber") != 0) {
                    var confirmPopup = $ionicPopup.confirm({
                        title: 'CureBooth Admin',
                        template: 'You will be charged ' + item.get("DoctorProfileObjectId").get("ChargesPerMin") + ' credits/min., minimum charges is ' + item.get("DoctorProfileObjectId").get("FirstMin") + ' credits',
                        cancelText: 'Cancel',
                        okText: 'Call'
                    });

                    confirmPopup.then(function (res) {
                        if (res) {
                            window.location = "tel:0" + item.get("DoctorProfileObjectId").get("UserPointer").get("ExotelNumber");
                        } else {
                            console.log('You are not sure');
                        }
                    });

                } //window.open('tel:0' + call, '_system');
                else
                    $rootScope.showAlert('No number to call')
            } else if (item.get("DoctorProfileObjectId").get("IsOfflineCall") && item.get("IsPriority")) {
                if (item.get("DoctorProfileObjectId").get("UserPointer").get("ExotelNumber") != 0) {
                    var confirmPopup = $ionicPopup.confirm({
                        title: 'CureBooth Admin',
                        template: 'You will be charged ' + item.get("DoctorProfileObjectId").get("ChargesPerMin") + ' credits/min., minimum charges is ' + item.get("DoctorProfileObjectId").get("FirstMin") + ' credits',
                        cancelText: 'Cancel',
                        okText: 'Call'
                    });

                    confirmPopup.then(function (res) {
                        if (res) {
                            window.location = "tel:0" + item.get("DoctorProfileObjectId").get("UserPointer").get("ExotelNumber");
                        } else {
                            console.log('You are not sure');
                        }
                    });

                } //window.open('tel:0' + call, '_system');
                else
                    $rootScope.showAlert('No number to call')
            } else
                $rootScope.showAlert('Doctor is offline ')
                //window.open('tel:900300400')
        }

        $scope.isFriendFn();
        $scope.conect = function () {
                var confirmPopup = $ionicPopup.confirm({
                    title: 'CureBooth Admin',
                    template: 'Connect to this Doctor?'
                });

                confirmPopup.then(function (res) {
                    if (res) {
                        // $ionicLoading.show();
                        Parse.Cloud.run('AdminRequestDoctor', {
                            DoctorUserId: results.UserObjectId,
                            DoctorProfileId: results.objectId,
                            id: $rootScope.user.id,
                            AdminProfileId: $rootScope.user.ProfileId,
                            PatientName: $rootScope.UserProfile.FullName
                        }, {
                            success: function (result) {
                                $scope.isFriend = result;
                                var alertPopup = $ionicPopup.alert({
                                    title: 'CureBooth Admin',
                                    template: 'Request sent successfully, Please enter Admin code'
                                });
                                alertPopup.then(function (res) {
                                    $scope.showPopup(result);
                                });
                                $ionicLoading.hide();
                            },
                            error: function (error) {
                                $rootScope.showAlert(error.message);
                                $ionicLoading.hide();
                            }
                        });
                    } else {
                        console.log('You are not sure');
                    }
                });

            }
            // Doctor otp verification
        $scope.showPopup = function (data) {
            $scope.data = {};

            // An elaborate, custom popup
            var myPopup = $ionicPopup.show({
                template: '<input type="number" ng-model="data.otp">',
                title: 'Please enter Admin code',
                scope: $scope,
                buttons: [
                    {
                        text: 'Cancel',
                        onTap: function (e) {;
                            $state.go('tab.AdminHome');
                        }
                    },
                    {
                        text: '<b>Verify</b>',
                        type: 'button-positive',
                        onTap: function (e) {
                            if (!$scope.data.otp) {
                                $rootScope.showAlert("Please enter otp");
                                //don't allow the user to close unless he enters wifi password
                                e.preventDefault();
                            } else {
                                Parse.Cloud.run('VerifyDoctorAdmin', {
                                    LinkingId: data.id,
                                    ActivationKey: $scope.data.otp
                                }, {
                                    success: function (results) {
                                        $ionicLoading.hide();
                                        $scope.PatientList = [];
                                        if (results != undefined) {
                                            var alertPopup = $ionicPopup.alert({
                                                title: 'CureBooth Admin',
                                                template: 'Doctor added successfully'
                                            });
                                            alertPopup.then(function (res) {
                                                $state.go('tab.AdminHome');
                                            });
                                            //$rootScope.showAlert("Patient added successfully");
                                            //$scope.FriendRequest = results;
                                        } else {
                                            $scope.FriendRequest = null;
                                        }

                                        // te Profile table updated successfully
                                    },
                                    error: function (error) {
                                        //$rootScope.showAlert(error.message);
                                        var alertPopup = $ionicPopup.alert({
                                            title: 'CureBooth Admin',
                                            template: error.message
                                        });
                                        alertPopup.then(function (res) {
                                            $state.go('tab.AdminHome');
                                        });
                                        $ionicLoading.hide();
                                        // error
                                    }
                                });
                            }
                        }
      }
    ]
            });

            myPopup.then(function (res) {
                console.log('Tapped!', res);
            });
        };
        //ionicMaterialInk.displayEffect();
    })
    .controller('PtDrProfileCtrl', function ($scope, $state, $ionicLoading, $ionicModal, $ionicPopup, $cordovaToast, $rootScope, $http, $ionicScrollDelegate, ionicMaterialInk) {
        $scope.selectedDiv = 'Profile'
        $scope.showTabCantent = function (option) {
            $scope.selectedDiv = option; //'Client';
            $ionicScrollDelegate.scrollTop();
        }
        $scope.Status = {
            statusType: false
        }
        $scope.myEvent = function (evt) {
            console.log('xsdfsdf' + evt)
        }
        $scope.myEvent1 = function (evt) {
            console.log('xsdfsdf')
        }
        $scope.calllist = [];
        $scope.PtDrProfile = [];
        console.log($rootScope.DrPtData)
        results = $rootScope.DrPtData;
        $scope.PtDrProfile.FirstName = results.FirstName;
        $scope.PtDrProfile.LastName = results.LastName;
        $scope.PtDrProfile.FullName = results.FullName
        $scope.PtDrProfile.BriefOverview = results.BriefOverview;
        $scope.PtDrProfile.Qualification = results.Qualification;
        $scope.PtDrProfile.Speciality = results.Speciality;
        $scope.PtDrProfile.Clinic = results.Clinic;
        $scope.PtDrProfile.ObjectId = results.UserObjectId;
        $scope.PtDrProfile.FirstMin = results.FirstMin;
        $scope.PtDrProfile.ChargesPerMin = results.ChargesPerMin;
        $scope.PtDrProfile.DrProfileId = results.id;
        $scope.PtDrProfile.DoctorFollowed = results.IsFollowed;
        // console.log('DoctorFollowed: ' + $scope.PtDrProfile.DoctorFollowed)
        $scope.PtDrProfile.IsCallAllowed = results.IsCallAllowed
        $scope.PtDrProfile.ProfileImage = results.ProfileImage;
        $scope.PtDrProfile.ExotelNumber = results.ExotelNumber;
        $scope.PtDrProfile.RecommendCounter = results.RecommendCounter;
        $scope.PtDrProfile.IsPriority = results.IsPriority;
        $scope.PtDrProfile.IsOfflineCall = results.IsOfflineCall;
        $scope.PtDrProfile.IsFollowed = results.IsFollowed
        $scope.PtDrProfile.IsVerfied = results.IsVerfied
        $scope.PtDrProfile.isMute = results.isMute
        $scope.PtDrProfile.id = results.id
        if (results.ExotelNumber != 0)
            $scope.PtDrProfile.DoctorNumber = '0' + results.ExotelNumber;
        else
            $scope.PtDrProfile.DoctorNumber = " ";



        $scope.PtDrProfile.chatThreadId = results.chatThreadId;
        $scope.PtDrProfile.UserObjectId = results.UserObjectId

        $scope.phoneCall = function (item) {
            if (item.IsCallAllowed) {
                if (item.ExotelNumber != 0) {
                    var confirmPopup = $ionicPopup.confirm({
                        title: 'CureBooth Admin',
                        template: 'You will be charged ' + item.ChargesPerMin + ' credits/min., minimum charges is ' + item.FirstMin + ' credits',
                        cancelText: 'Cancel',
                        okText: 'Call'
                    });

                    confirmPopup.then(function (res) {
                        if (res) {
                            window.location = "tel:0" + item.ExotelNumber;
                        } else {
                            console.log('You are not sure');
                        }
                    });

                } //window.open('tel:0' + call, '_system');
                else
                    $rootScope.showAlert('No number to call')
            } else if (item.IsOfflineCall && item.IsPriority) {
                if (item.ExotelNumber != 0) {
                    var confirmPopup = $ionicPopup.confirm({
                        title: 'CureBooth Admin',
                        template: 'You will be charged ' + item.ChargesPerMin + ' credits/min., minimum charges is ' + item.FirstMin + ' credits',
                        cancelText: 'Cancel',
                        okText: 'Call'
                    });

                    confirmPopup.then(function (res) {
                        if (res) {
                            window.location = "tel:0" + item.ExotelNumber;
                        } else {
                            console.log('You are not sure');
                        }
                    });

                } //window.open('tel:0' + call, '_system');
                else
                    $rootScope.showAlert('No number to call')
            } else
                $rootScope.showAlert('Doctor is offline ')
                //window.open('tel:900300400')
        }

        $scope.chat = function (item) {
                $rootScope.chatUser = item //results.get('DoctorProfileObjectId');
                    //console.log($rootScope.chatUser.get('PatientProfileObjectId').get('ProfileImage').url())

            }
            // Call History Funtion
        $scope.callhistory = function () {
            // $ionicLoading.show();
            Parse.Cloud.run('GetCallHistory', {
                UserProfileId: $rootScope.user.ProfileId
            }, {
                success: function (results) {
                    $ionicLoading.hide();
                    for (i = 0; i < results.length; i++) {
                        if ($rootScope.user.ProfileId == results[i].get("ToProfileObjectId").id && $scope.PtDrProfile.DrProfileId == results[i].get("FromProfileObjectId").id) {
                            results[i]['Incoming'] = true
                            $scope.calllist.push(results[i]);
                        } else if ($rootScope.user.ProfileId == results[i].get("FromProfileObjectId").id && $scope.PtDrProfile.DrProfileId == results[i].get("ToProfileObjectId").id) {
                            results[i]['Incoming'] = false
                            $scope.calllist.push(results[i]);
                        }
                    }
                },
                error: function (error) {
                    $ionicLoading.hide();
                    // error
                }
            });
        };
        // is Set Doctor Recommend
        $scope.SetDoctorRecommend = function () {
                //$ionicLoading.show();
                console.log(results.Recommended)
                if (results.Recommended == undefined)
                    $scope.DoctorRecommend = true;
                else
                    $scope.DoctorRecommend = !results.Recommended;

                Parse.Cloud.run('SetDoctorRecommend', {
                    ProfileLinkId: results.ProfileLinkId,
                    IsRecommend: $scope.DoctorRecommend
                }, {
                    success: function (status) {
                        $ionicLoading.hide();
                        $cordovaToast.show('Doctor recommended successfully', 'short', 'center')
                    },
                    error: function (error) {
                        console.log(error)
                        $ionicLoading.hide();
                        $cordovaToast.show(error.message, 'short', 'center')
                            //$rootScope.showAlert(error.message);
                            // debugger;
                            // error
                    }
                });
            }
            //ShareFriendToDoc
        $scope.ShareFriendToDoc = function (phone) {
            Parse.Cloud.run('ShareFriendToDoc', {
                UserProfile: $rootScope.user.ProfileId,
                DoctorProfile: $scope.PtDrProfile.DrProfileId,
                Phone: phone,
                DoctorUserId: $scope.PtDrProfile.ObjectId
            }, {
                success: function (status) {
                    $ionicLoading.hide();
                    $scope.closeRechargeModal();
                    $cordovaToast.show(status, 'short', 'center')
                },
                error: function (error) {
                    console.log(error)
                    $ionicLoading.hide();
                    $cordovaToast.show(error.message, 'short', 'center')
                        //$rootScope.showAlert(error.message);
                        // debugger;
                        // error
                }
            });
        }
        $scope.rechargeAmount = [];
        $scope.showaddmoney = function () {
                $scope.Recharge = true;
                $scope.Rechargebtn = true;
                $scope.openRechargeModal();
                //
            }
            /* $ionicModal.fromTemplateUrl('my-modal.html', {
                 scope: $scope,
                 animation: 'fade-in-up'
             }).then(function (modal) {
                 $scope.MsgModal = modal;
             });*/
        $scope.MsgModal = $ionicModal.fromTemplate('<ion-modal-view class="signup"><ion-header-bar class="bar bar-stable fix-buttons"><button class="button  bar bar-stable" ng-click="closeRechargeModal()" style="max-width: 100px; padding: 5px 10px; min-width: 80px; box-shadow: none;">Cancel</button><h1 class="title">Refer Doctor</h1></ion-header-bar><ion-content><div class="card" style="padding: 5px 10px 0;"><ion-input class="item item-input item-stacked-label"><ion-label>Enter Friend Contact Number</ion-label> <input type="tel" placeholder="Mobile Number" ng-model="rechargeAmount.mobile"  maxlength="10"></ion-input><button ng-disabled="!rechargeAmount.mobile" class="button button-full button-outline button-positive" ng-click="showaddMoneyfn()" style="color: rgb(255, 255, 255); background: rgb(0, 189, 189) none repeat scroll 0% 0%; box-shadow: none;">  Submit</button></div></ion-content></ion-modal-view>', {
            scope: $scope,
            animation: 'slide-in-up'
        });
        $scope.openRechargeModal = function () {
            if ($rootScope.NetworkStatus)
                $scope.MsgModal.show();
            else
                $cordovaToast.show('no connection available', 'short', 'center')

        };
        $scope.closeRechargeModal = function () {
            $scope.MsgModal.hide();
        };
        //Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function () {
            $scope.MsgModal.remove();
        });
        $scope.showaddMoneyfn = function () {
            if ($scope.rechargeAmount.mobile != undefined && $scope.rechargeAmount.mobile != null && $scope.rechargeAmount.mobile.length == 10) {
                $scope.ShareFriendToDoc($scope.rechargeAmount.mobile);
            } else {
                $rootScope.showAlert('Please enter valid mobile number.');
            }
        };
        // is followed
        $scope.SetDoctorFollowed = function (amt) {
            //$ionicLoading.show();
            Parse.Cloud.run('SetDoctorFollowed', {
                DocProfileId: $scope.PtDrProfile.DrProfileId,
                IsFollowed: amt,
                PatProfileId: $rootScope.user.ProfileId
            }, {
                success: function (status) {
                    $ionicLoading.hide();
                    $cordovaToast.show(status, 'short', 'center')
                        //$rootScope.showAlert('Doctor followed Successfully');
                        // te Profile table updated successfully
                },
                error: function (error) {
                    console.log(error)
                    $ionicLoading.hide();
                    $cordovaToast.show(error.message, 'short', 'center')
                        //$rootScope.showAlert(error.message);
                        // debugger;
                        // error
                }
            });
        }

        // list of status
        $scope.getStatusType = function () {
                // $ionicLoading.show();
                var query = new Parse.Query('StatusType');
                query.find({
                    success: function (results) {
                        $ionicLoading.hide();
                        $scope.StatusType = results
                        $scope.getStatus();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                    }
                });
            }
            // User current status
        $scope.getStatus = function () {
            // $ionicLoading.show();
            var query = new Parse.Query('UserStatus');
            query.equalTo('UserId', results.get('UserObjectId'));
            query.find({
                success: function (data) {
                    if (data.length > 0) {
                        $ionicLoading.hide();
                        $scope.Status.statusType = data[0].get('StatusName');
                    }
                },
                error: function (error) {
                    $ionicLoading.hide();
                    //alert("Error: " + error.code + " " + error.message);
                }
            });
        }
        $scope.ExotelNumber = function () {
                // $ionicLoading.show();
                var query = new Parse.Query('User');
                query.equalTo('objectId', results.get('DoctorProfileObjectId').get('UserObjectId'));
                query.find({
                    success: function (results) {
                        $ionicLoading.hide();
                        if (results.length > 0) {
                            $scope.PtDrProfile.ExotelNumber = results[0].get('ExotelNumber');
                        } else {}
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        //alert("Error: " + error.code + " " + error.message);
                    }
                });
            }
            //$scope.getStatus();
            //$scope.ExotelNumber();
            //$scope.callhistory();
            //ionicMaterialInk.displayEffect();
    })
    .controller('PatientSettingCtrl', function ($scope, $state, $ionicLoading, $rootScope, $http, $ionicPopup, $localstorage, ionicMaterialInk) {
        $scope.setting = {};
        $scope.getSetting = function (amt) {
            //$ionicLoading.show();
            Parse.Cloud.run('PatientRequestSentList', {
                ProfileId: $rootScope.user.ProfileId
            }, {
                success: function (status) {
                    $ionicLoading.hide();
                    //$scope.setting = status;
                    //$localstorage.setObject('PatientRequestSentList', status)
                    $scope.setting = status // $localstorage.getObject('PatientRequestSentList')
                },
                error: function (error) {
                    console.log(error)
                    $ionicLoading.hide();
                    $rootScope.showAlert(error.message);
                    // debugger;
                    // error
                }
            });
        }


        $scope.saveSetting = function () {
            // $ionicLoading.show();
            if ($scope.setting.result != null) {
                var point = $scope.setting.result[0];
                point.set("BankName", $scope.setting.BankName);
                point.set("AccountNumber", $scope.setting.AccountNumber);
                point.set("BankCode", $scope.setting.BankCode);
                point.set("UserId", $rootScope.user.id);
                point.set("TimeFee", $scope.setting.TimeFee);
                point.set("Charges", $scope.setting.Charges);
                point.save(null, {
                    success: function (point) {
                        $ionicLoading.hide();
                    },
                    error: function (point, error) {
                        $ionicLoading.hide();
                    }
                });
            } else {

                var Point = Parse.Object.extend("DocAccountSetting");
                var point = new Point();
                point.set("BankName", $scope.setting.BankName);
                point.set("AccountNumber", $scope.setting.AccountNumber);
                point.set("BankCode", $scope.setting.BankCode);
                point.set("UserId", $rootScope.user.id);
                point.set("TimeFee", $scope.setting.TimeFee);
                point.set("Charges", $scope.setting.Charges);
                point.set("Amount", $scope.setting.Amount);
                point.save(null, {
                    success: function (point) {
                        $ionicLoading.hide();

                        // Saved successfully.
                    },
                    error: function (point, error) {
                        $ionicLoading.hide();
                        // The save failed.
                        // error is a Parse.Error with an error code and description.
                    }
                });
            }
        }
        $scope.changePassword = false;
        $scope.changePass = function (param) {
            $scope.changePassword = param;
        }
        $scope.changePasword = [];
        $scope.UpdatePassword = function () {
            if (typeof $scope.changePasword.Password === 'undefined' || $scope.changePasword.Password === null) {
                $rootScope.showAlert("Please enter current password");
                return false;
            } else if (typeof $scope.changePasword.NewPassword === 'undefined' || $scope.changePasword.NewPassword === null) {
                $rootScope.showAlert("Please enter new password");
                return false;
            } else if (typeof $scope.changePasword.cNewPassword === 'undefined' || $scope.changePasword.cNewPassword === null) {
                $rootScope.showAlert("Please enter confirm new password");
                return false;
            } else if ($scope.changePasword.NewPassword != $scope.changePasword.cNewPassword) {
                $rootScope.showAlert("Please enter same new password and confirm new password");
                return false;
            } else if ($scope.changePasword.Password == $scope.changePasword.cNewPassword) {
                $rootScope.showAlert("Please enter same new password and confirm new password");
                return false;
            } else {
                var confirmPopup = $ionicPopup.confirm({
                    title: 'CureBooth Admin',
                    template: 'Are you sure ! <br/> You want to change your password?'
                });

                confirmPopup.then(function (res) {
                    if (res) {
                        // $ionicLoading.show();
                        Parse.Cloud.run('UpdatePassword', {
                            //username: $scope.Profile.get('Phone'),
                            oldPassword: $scope.changePasword.Password,
                            newPassword: $scope.changePasword.NewPassword
                        }, {
                            success: function (results) {
                                $ionicLoading.hide();
                                $scope.changePassword = false;
                                var alertPopup = $ionicPopup.alert({
                                    title: 'CureBooth Admin',
                                    cssClass: 'balance',
                                    template: 'Password changed successfully !<br> Please login again'
                                });
                                alertPopup.then(function (res) {
                                    $scope.logOut();
                                });
                            },
                            error: function (error) {
                                console.log(error)
                                $ionicLoading.hide();
                                $rootScope.showAlert(error.message);
                            }
                        });
                    }
                });
            }

        };
        $scope.GetShareMsg = function () {
            //$ionicLoading.show();
            Parse.Cloud.run('GetShareMsg', {
                //UserObjectId: $rootScope.user.id,
            }, {
                success: function (results) {
                    $ionicLoading.hide();
                    $scope.GetShareMsgdata = results;
                    console.log($scope.GetShareMsgdata[0])
                    console.log($scope.GetShareMsgdata[1])
                },
                error: function (error) {
                    $ionicLoading.hide();
                }
            });
        }
        $scope.shareApp = function () {
                var options = {
                    message: 'share this', // not supported on some apps (Facebook, Instagram)
                    subject: 'the subject', // fi. for email
                    files: ['', ''], // an array of filenames either locally or remotely
                    url: 'https://www.website.com/foo/#bar?a=b',
                    chooserTitle: 'Pick an app' // Android only, you can override the default share sheet title
                }

                /*var onSuccess = function (result) {
                    console.log("Share completed? " + result.completed); // On Android apps mostly return false even while it's true
                    console.log("Shared to app: " + result.app); // On Android result.app is currently empty. On iOS it's empty when sharing is cancelled (result.completed=false)
                }

                var onError = function (msg) {
                    console.log("Sharing failed with message: " + msg);
                }

                window.plugins.socialsharing.share(options, onSuccess, onError);*/
                //window.plugins.socialsharing.share($scope.GetShareMsgdata[0], 'https://www.google.nl/images/srpr/logo4w.png', $scope.GetShareMsgdata[1]);
                window.plugins.socialsharing.share($scope.GetShareMsgdata[0], 'CureBooth', null, $scope.GetShareMsgdata[1])
            }
            // Intialize the controller 
        if ($rootScope.NetworkStatus) {
            //$scope.setting = $localstorage.getObject('PatientRequestSentList')
            $scope.getSetting();
            $scope.GetShareMsg();
        } else {
            // $scope.setting = $localstorage.getObject('PatientRequestSentList')
        }
        //ionicMaterialInk.displayEffect();
    });