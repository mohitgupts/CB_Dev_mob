// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.services' is found in services.js
// 'starter.controllers' is found in controllers.js
var pusher;
angular.module('nGageRX', ['ionic', 'ionic-material', 'nGageRX.controllers', 'nGageRX.filters', 'doowb.angular-pusher', 'ui.gravatar', 'angular-moment', 'ngCordova', 'ion-floating-menu', 'ng-walkthrough'])

.run(function ($ionicPlatform, $state, $rootScope, $ionicPopup, $cordovaNetwork, $cordovaToast, $cordovaGeolocation) {
        $ionicPlatform.ready(function () {
             //dev keys
            Parse.initialize("bPAZB1rsMluBwArncMWZfpelHxQuPcL9A0m5R4nc", "mpT56Nb9v3hPXlSVo82mIEmfJKlQTpXNLQKw3kz9");

            // Prod App Keys
            //Parse.initialize("HvT1p4ztpJ2xSSjFc6uecMxCPKXHGDvDPD2k9ywJ", "0qEzPcxpPHHz3Lu85xY3IflBHLlpaOpTNy28IE7m");
            $rootScope.NetworkStatus = true;
            var currentUser = Parse.User.current();
            $rootScope.user = null;
            $rootScope.UserProfile = null;
            $rootScope.isLoggedIn = false;
            $rootScope.PinCode = '';
            //console.log(currentUser)
            if (currentUser) {
                console.log(window.localStorage['isDoctor'])
                if (window.localStorage['isDoctor'] != undefined || window.localStorage['isDoctor'] != null || window.localStorage['isPatient'] != undefined || window.localStorage['isPatient'] != null || window.localStorage['isAdmin'] != undefined || window.localStorage['isAdmin'] != null) {
                    $rootScope.user = currentUser;
                    $rootScope.isLoggedIn = true;
                    $rootScope.isDoctor = window.localStorage['isDoctor'];
                    $rootScope.isPatient = window.localStorage['isPatient'];
                    $rootScope.isAdmin = window.localStorage['isAdmin'];
                    if ($rootScope.isDoctor == 'true') {
                        console.log('isDoctor')
                        //$state.go('tab.home');
                    } else if ($rootScope.isPatient == 'true') {
                        console.log('isPatient')
                        //$state.go('tab.AdminHome');
                    } else if ($rootScope.isAdmin == 'true') {
                        console.log('isAdmin')
                        $state.go('tab.AdminHome');
                    }
                } else {
                    Parse.User.logOut();
                    $state.go('login');
                }
            } else {
                console.log('login')
                $state.go('login');
            }
            // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
            // for form inputs)
            if (window.cordova && window.cordova.plugins.Keyboard) {
                cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
                cordova.plugins.Keyboard.disableScroll(true);
            }
            if (window.StatusBar) {
                // org.apache.cordova.statusbar required
                StatusBar.styleDefault();
            }
            if ($cordovaNetwork.isOffline()) {
                $rootScope.NetworkStatus = false;
                $cordovaToast.show('no connection available', 'long', 'center')
                    .then(function (success) {
                        console.log(success)
                    }, function (error) {
                        // error
                    });
                /* var alertPopup = $ionicPopup.alert({
                     title: 'nGageRX',
                     cssClass: 'balance',
                     template: "Network not found on Device !<br/> Please check your device's setting for Network !<br/>"
                 });
                 alertPopup.then(function (res) {
                     //navigator.app.exitApp();
                 });*/
            } else {
                var script = document.createElement('script');
                script.src = 'http://maps.googleapis.com/maps/api/js?sensor=false';
                document.body.appendChild(script);
                var script1 = document.createElement('script');
                /*script1.src = 'http://crypto-js.googlecode.com/svn/tags/3.1.2/build/rollups/sha512.js';
                document.body.appendChild(script1);*/
                $rootScope.NetworkStatus = true;
                console.log("yescon");
            }
            document.addEventListener("offline", onOffline, false);
            document.addEventListener("online", yourCallbackFunction, false);

            function yourCallbackFunction() {
                $rootScope.NetworkStatus = true;
            }

            var posOptions = {
                timeout: 10000,
                enableHighAccuracy: false
            };
            $cordovaGeolocation.getCurrentPosition(posOptions).then(function (position) {
                var lat = position.coords.latitude
                var long = position.coords.longitude
                    //alert(position.coords)
                GetAddress(position)
            }, function (err) {
                // error
            });

            function GetAddress(position) {
                var lat = position.coords.latitude;
                var lng = position.coords.longitude;
                var latlng = new google.maps.LatLng(lat, lng);
                $rootScope.Currentlatlng = latlng;
                var geocoder = geocoder = new google.maps.Geocoder();
                geocoder.geocode({
                    'latLng': latlng
                }, function (results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {
                        if (results[1]) {
                            for (j = 0; j < results[0].address_components.length; j++) {
                                if (results[0].address_components[j].types[0] == 'postal_code')
                                    $rootScope.PinCode = results[0].address_components[j].short_name
                                    //alert("Zip Code: " + results[0].address_components[j].short_name);
                            }
                            $rootScope.CurrentAddress = results[1].formatted_address
                                //alert("Location: " + results[1].formatted_address + "postal_code: " + results[1].address_components.postal_code);
                        }
                    }
                });
            }

            function onOffline() {
                $rootScope.NetworkStatus = false;
                $cordovaToast.show('no connection available', 'long', 'center')
                    .then(function (success) {
                        // success
                    }, function (error) {
                        // error
                    });
                /*  var alertPopup = $ionicPopup.alert({
                      title: 'nGageRX',
                      cssClass: 'balance',
                      template: 'Your Device disconnected to Network!<br/> Please check your device setting for Network '
                  });
                  alertPopup.then(function (res) {
                      //navigator.app.exitApp();
                  });*/

            }
            // Disable BACK button on home
            $ionicPlatform.registerBackButtonAction(function (event) {
                if ($state.current.name == "tab.home" || $state.current.name == 'tab.PatientHome') {
                    navigator.app.exitApp();
                } else {
                    navigator.app.backHistory();
                }
            }, 100);


            ParsePushPlugin.getInstallationId(function (id) {
                //alert(id);
            }, function (e) {
                //alert('error');
            });

            ParsePushPlugin.getSubscriptions(function (subscriptions) {
                //alert(subscriptions);
            }, function (e) {
                //alert('error');
            });

            /* ParsePushPlugin.subscribe('Chat', function (msg) {
                 //alert('OK');
             }, function (e) {
                 //alert('error');
             });*/

            /*ParsePushPlugin.unsubscribe('SampleChannel', function (msg) {
                alert('OK');
            }, function (e) {
                alert('error');
            });*/
            if (window.ParsePushPlugin) {
                ParsePushPlugin.on('receivePN', function (pn) {
                    //alert('yo i got this push notification:' + JSON.stringify(pn));
                });
                ParsePushPlugin.on('openPN', function (pn) {
                    //you can do things like navigating to a different view here
                    console.log(JSON.stringify(pn));
                    console.log('Yo, I get this when the user clicks open a notification from the tray');
                    if (pn.type == 4) {
                        $state.go('tab.wallet');
                    }
                });
                //
                //you can also listen to your own custom subevents
                //
                //ParsePushPlugin.on('receivePN:chat', chatEventHandler);
                //ParsePushPlugin.on('receivePN:serverMaintenance', serverMaintenanceHandler);
            }
        });
        // start code for browser testing

        /*var script = document.createElement('script');
        script.src = 'http://maps.googleapis.com/maps/api/js?sensor=false';
        document.body.appendChild(script);
        var script1 = document.createElement('script');
        script1.src = 'http://crypto-js.googlecode.com/svn/tags/3.1.2/build/rollups/sha512.js';
        document.body.appendChild(script1);
        var posOptions = {
            timeout: 10000,
            enableHighAccuracy: false
        };
        $cordovaGeolocation.getCurrentPosition(posOptions).then(function (position) {
            var lat = position.coords.latitude
            var long = position.coords.longitude
                //alert(position.coords)
            GetAddress(position)
        }, function (err) {
            // error
        });

        function GetAddress(position) {
            var lat = position.coords.latitude;
            var lng = position.coords.longitude;
            var latlng = new google.maps.LatLng(lat, lng);
            $rootScope.Currentlatlng = latlng;
            var geocoder = geocoder = new google.maps.Geocoder();
            geocoder.geocode({
                'latLng': latlng
            }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[1]) {
                        for (j = 0; j < results[0].address_components.length; j++) {
                            if (results[0].address_components[j].types[0] == 'postal_code')
                                $rootScope.PinCode = results[0].address_components[j].short_name
                                //alert("Zip Code: " + results[0].address_components[j].short_name);
                        }
                        $rootScope.CurrentAddress = results[1].formatted_address
                            //alert("Location: " + results[1].formatted_address + "postal_code: " + results[1].address_components.postal_code);
                    }
                }
            });
        }*/
        // end code for browser testing
    })
    .config(['PusherServiceProvider', '$httpProvider',
  function (PusherServiceProvider, $httpProvider) {
            /* pusher = new Pusher('f21946d3687f92b405fe');*/
            var prodKey = '159d611cc21548e9fc1d';
            var DevKey = "f21946d3687f92b405fe";
            PusherServiceProvider
                .setToken(prodKey)
                .setOptions({});
            //Enable cross domain calls
            $httpProvider.defaults.useXDomain = true;
            //Remove the header containing XMLHttpRequest used to identify ajax call 
            //that would prevent CORS from working
            delete $httpProvider.defaults.headers.common['X-Requested-With'];

  }
])
    .config(function ($httpProvider, $ionicConfigProvider) {
        //Enable cross domain calls
        $httpProvider.defaults.useXDomain = true;
        //Remove the header containing XMLHttpRequest used to identify ajax call 
        //that would prevent CORS from working
        delete $httpProvider.defaults.headers.common['X-Requested-With'];
        $ionicConfigProvider.backButton.text('').icon('ion-chevron-left');
        $ionicConfigProvider.backButton.previousTitleText(false);
        $ionicConfigProvider.navBar.alignTitle('center');
        $ionicConfigProvider.views.maxCache(0);
        $ionicConfigProvider.views.forwardCache(false)
        $ionicConfigProvider.tabs.position('bottom');
        $ionicConfigProvider.scrolling.jsScrolling(false);
        $ionicConfigProvider.views.transition('platform')
        $ionicConfigProvider.form.toggle("small")
    })
    .config(function ($stateProvider, $urlRouterProvider) {

        // Ionic uses AngularUI Router which uses the concept of states
        // Learn more here: https://github.com/angular-ui/ui-router
        // Set up the various states which the app can be in.
        // Each state's controller can be found in controllers.js
        $stateProvider

        // setup an abstract state for the tabs directive
            .state('tab', {
                url: '/tab',
                abstract: true,
                templateUrl: 'templates/tabs.html',
                controller: 'AppCtrl'
            })
            .state('login', {
                url: '/login',
                templateUrl: 'templates/login.html',
                controller: 'LoginController'
            })
            .state('forget', {
                url: '/forget',
                templateUrl: 'templates/forget.html',
                controller: 'ForgotPasswordController'
            })
            .state('register', {
                url: '/register',
                templateUrl: 'templates/register.html',
                controller: 'RegisterController'
            })
            .state('otp', {
                url: '/otp',
                templateUrl: 'templates/otp.html',
                controller: 'RegisterController'
            })
            .state('tab.home', {
                url: '/home',
                views: {
                    'tab-dash': {
                        templateUrl: 'templates/home.html',
                        controller: 'HomeCtrl'
                    }
                }
            })
            .state('tab.PatientHome', {
                cache: true,
                url: '/PatientHome',
                views: {
                    'tab-dash': {
                        templateUrl: 'templates/PatientHome.html',
                        controller: 'PatientHomeCtrl'
                    }
                }
            })
            .state('tab.AdminHome', {
                cache: true,
                url: '/AdminHome',
                views: {
                    'tab-dash': {
                        templateUrl: 'templates/AdminHome.html',
                        controller: 'PatientHomeCtrl'
                    }
                }
            })
            .state('tab.wallet', {
                url: '/wallet',
                views: {
                    'tab-wallet': {
                        templateUrl: 'templates/receivable.html',
                        controller: 'ReceivableCtrl'
                    }
                }
            })
            .state('tab.Payment', {
                url: '/Payment',
                views: {
                    'tab-wallet': {
                        templateUrl: 'templates/payment.html',
                        controller: 'PaymentCtrl'
                    }
                }
            })
            .state('tab.walletStatement', {
                url: '/walletStatement',
                views: {
                    'tab-wallet': {
                        templateUrl: 'templates/walletStatement.html',
                        controller: 'WalletStatmntCtrl'
                    }
                }
            })
            .state('tab.AdminAddPatient', {
                url: '/AdminAddPatient',
                views: {
                    'tab-dash': {
                        templateUrl: 'templates/AdminAddPatient.html',
                        controller: 'AddPatientCtrl'
                    }
                }
            })
         //QueueManagement routing
            .state('tab.QueueManagement', {
                url: '/QueueManagement',
                views: {
                    'tab-dash': {
                        templateUrl: 'templates/QueueManagement.html',
                        controller: 'QueueManagement'
                    }
                }
            })
            .state('tab.AddPatient', {
                url: '/AddPatient',
                views: {
                    'tab-dash': {
                        templateUrl: 'templates/AddPatient.html',
                        controller: 'AddPatientCtrl'
                    }
                }
            })
            .state('tab.more', {
                url: '/more',
                views: {
                    'tab-more': {
                        templateUrl: 'templates/more.html',
                        // controller: 'MoreCtrl'
                    }
                }
            })
            .state('tab.profile', {
                url: '/profile',
                views: {
                    'tab-patient': {
                        templateUrl: 'templates/profile.html',
                        controller: 'ProfileCtrl'
                    }
                }
            })
            .state('tab.AdminSetting', {
                url: '/AdminSetting',
                views: {
                    'tab-more': {
                        templateUrl: 'templates/AdminSetting.html',
                        controller: 'SettingCtrl'
                    }
                }
            })
            .state('tab.terms', {
                url: '/terms',
                views: {
                    'tab-more': {
                        templateUrl: 'templates/terms.html',
                        controller: ''
                    }
                }
            })
            .state('tab.privacy', {
                url: '/privacy',
                views: {
                    'tab-more': {
                        templateUrl: 'templates/privacy.html',
                        controller: ''
                    }
                }
            })
            .state('tab.FRPage', {
                url: '/FRPage',
                views: {
                    'tab-more': {
                        templateUrl: 'templates/FRPage.html',
                        controller: 'FRPageCtrl'
                    }
                }
            })
            .state('tab.PatientProfile', {
                url: '/PatientProfile',
                views: {
                    'tab-patient': {
                        templateUrl: 'templates/patient/profile.html',
                        controller: 'PatientProfileCtrl'
                    }
                }
            })
            .state('tab.PatientSetting', {
                url: '/PatientSetting',
                views: {
                    'tab-more': {
                        templateUrl: 'templates/patient/setting.html',
                        controller: 'PatientSettingCtrl'
                    }
                }
            })
            .state('tab.DoctorSearch', {
                url: '/DoctorSearch',
                views: {
                    'tab-dash': {
                        templateUrl: 'templates/patient/search.html',
                        controller: 'DoctorSearchCtrl'
                    }
                }
            }).state('tab.DrProfile', {
                url: '/DrProfile',
                views: {
                    'tab-dash': {
                        templateUrl: 'templates/patient/DrProfile.html',
                        controller: 'DrProfileCtrl'
                    }
                }
            })
            .state('tab.PtDrHome', {
                url: '/PtDrHome',
                views: {
                    'tab-dash': {
                        templateUrl: 'templates/patient/PtDrHome.html',
                        controller: 'PtDrProfileCtrl'
                    }
                }
            }).state('tab.DrPatientHome', {
                url: '/DrPatientHome',
                views: {
                    'tab-dash': {
                        templateUrl: 'templates/DrPatientHome.html',
                        controller: 'DrPatientHomeCtrl'
                    }
                }
            }).state('tab.friend-detail', {
                url: '/thread/:threadId/:targetId',
                views: {
                    'tab-dash': {
                        templateUrl: 'templates/thread-detail.html',
                        controller: 'ThreadDetailCtrl'
                    }
                }
            });

        // if none of the above states are matched, use this as the fallback
        $urlRouterProvider.otherwise('tab.AdminHome');

    });