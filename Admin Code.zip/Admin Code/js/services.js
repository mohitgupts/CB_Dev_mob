angular.module('nGageRX.filters', [])
    .filter('millSecondsToTimeString', function () {
        return function (millseconds) {
            var seconds = Number(millseconds); //Math.floor(millseconds / 1000);
            var h = 3600;
            var m = 60;
            var hours = Math.floor(seconds / h);
            var minutes = Math.floor((seconds % h) / m);
            var scnds = Math.floor((seconds % m));
            var timeString = '';
            if (scnds < 10) scnds = "0" + scnds;
            if (hours < 10) hours = "0" + hours;
            if (minutes < 10) minutes = "0" + minutes;


            if (hours > 0) {
                timeString += hours + ":";
                if (minutes >= 0) timeString += minutes + ":";
                if (scnds >= 0) timeString += scnds + " hrs";
            } else {
                if (minutes >= 0) timeString += minutes + ":";
                if (scnds >= 0) timeString += scnds + " min";
            }

            //timeString = hours + ":" + minutes + ":" + scnds;
            return timeString;
        }
    })
    .filter('toArray', function () {
        return function (obj, addKey) {
            if (!angular.isObject(obj)) return obj;
            if (addKey === false) {
                return Object.keys(obj).map(function (key) {
                    return obj[key];
                });
            } else {
                return Object.keys(obj).map(function (key) {
                    var value = obj[key];
                    return angular.isObject(value) ?
                        Object.defineProperty(value, '$key', {
                            enumerable: false,
                            value: key
                        }) : {
                            $key: key,
                            $value: value
                        };
                });
            }
        };
    })
    .filter('custom', function () {
        return function (input, search) {
            if (!input) return input;
            if (!search) return input;
            var expected = ('' + search).toLowerCase();
            var result = {};
            angular.forEach(input, function (value, key) {
                var actual = ('' + value).toLowerCase();
                if (actual.indexOf(expected) !== -1) {
                    result[key] = value;
                }
            });
            return result;
        }
    })
    .factory('UtilFunctions', function ($ionicPopup) {
        var UtilFunctions = {
            setAlert: function (obj) {
                var alertPopup = $ionicPopup.alert({
                    "title": obj.title,
                    "template": obj.template,
                });
            }
        }

        return UtilFunctions;
    })
    .directive('hideTabs', function ($rootScope) {
        return {
            restrict: 'A',
            link: function ($scope, $el) {
                $rootScope.hideTabs = 'tabs-item-hide';
                $scope.$on('$destroy', function () {
                    $rootScope.hideTabs = '';
                });
            }
        };
    })
    .factory('ParseService', function () {

        var ParseService = {
            signIn: function (obj, win, fail) {
                Parse.User.logIn(obj.username, obj.password, {
                    success: function (user) {
                        win(user);
                    },
                    error: function (user, error) {
                        fail(user, error);
                    }
                });
            },
            register: function (obj, win, fail) {
                var user = new Parse.User();
                user.set("username", obj.username);
                user.set("display_name", obj.display_name)
                user.set("user_state", 1)
                user.set("password", obj.password);
                user.set("email", obj.email_address);

                // other fields can be set just like with Parse.Object
                user.set("phone", "415-392-0202");

                user.signUp(null, {
                    success: function (user) {
                        win(user);
                    },
                    error: function (user, error) {
                        fail(user, error);
                    }
                });
            },
            currentUser: function (win, fail) {
                var currentUser = Parse.User.current();
                if (currentUser) {
                    win(currentUser);
                } else {
                    fail("notlogged");
                }
            },
            changeStatus: function (obj, win, fail) {
                console.log(obj);
                var user = Parse.User.current();

                user.set("user_state", obj.user_state);
                user.save(null, {
                    success: function (user) {
                        win(user);
                    },
                    error: function (user, error) {
                        fail(user, error);
                    }
                });
            },
            getUser: function (obj, win, fail) {
                var query = new Parse.Query(Parse.User);
                query.get(obj.id, {
                    success: function (results) {
                        win(results);
                    },
                    error: function (error) {
                        fail(error)
                    }
                });
            },
            addToContactList: function (obj, win, fail) {
                var ContactList = Parse.Object.extend("ContactList");
                var contactList = new ContactList();

                contactList.set("user_id", obj.id);
                contactList.set("user", obj.user);
                contactList.set("thread_id", obj.id + "-" + obj.user.id + "-" + Parse.makeid(5));

                contactList.save(null, {
                    success: function (cl) {
                        win(cl);
                    },
                    error: function (cl, error) {
                        fail(cl, error);
                    }
                });
            },
            removeFromContactList: function (obj, win, fail) {
                var ContactList = Parse.Object.extend("ContactList");
                var query = new Parse.Query(ContactList);
                query.get(obj.id, {
                    success: function (myObj) {
                        // The object was retrieved successfully.
                        myObj.destroy({});
                        win("success");
                    },
                    error: function (object, error) {
                        // The object was not retrieved successfully.
                        // error is a Parse.Error with an error code and description.
                        fail(object, error);
                    }
                });
            },
            getContactList: function (win, fail) {
                var currentUser = Parse.User.current();
                var ContactList = Parse.Object.extend("ContactList");
                var query = new Parse.Query(ContactList);
                query.include("user");
                query.equalTo("user_id", currentUser.id);
                query.find({
                    success: function (results) {
                        win(results);
                    },
                    error: function (error) {
                        fail(error)
                    }
                });
            },
            createThread: function (obj, win, fail) {
                var ContactList = Parse.Object.extend("ContactList");
                var contactList = new ContactList();

                contactList.set("user_owner", obj.user_owner);
                contactList.set("user", obj.user);
                contactList.set("thread_id", obj.thread_id);

                contactList.save(null, {
                    success: function (cl) {
                        win(cl);
                    },
                    error: function (cl, error) {
                        fail(cl, error);
                    }
                });
            },
            getThread: function (obj, win, fail) {
                var Messages = Parse.Object.extend("Messages");
                var query = new Parse.Query(Messages).include('user');
                query.equalTo("thread_id", obj.thread_id);
                query.limit(25);
                if (obj.createdAt != null)
                    query.greaterThan("createdAt", obj.createdAt);
                if (obj.offset) {
                    console.log(obj.offset);
                    query.skip(obj.offset);
                }

                query.descending("createdAt");
                query.find({
                    success: function (results) {
                        win(results.reverse());
                    },
                    error: function (error) {
                        fail(error)
                    }
                });
            },
            postMessage: function (obj, win, fail) {
                var Messages = Parse.Object.extend("Messages");
                var message = new Messages();

                message.set("message", obj.message);
                message.set("user", obj.user);
                message.set("thread_id", obj.thread_id)
                message.set("ToUser", obj.ToUser)
                message.set("FromUserName", obj.FromUser)
                message.save(null, {
                    success: function (cl) {
                        win(cl);
                    },
                    error: function (cl, error) {
                        fail(cl, error);
                    }
                });
            },
            makeid: function (len) {
                var text = "";
                var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

                for (var i = 0; i < len; i++)
                    text += possible.charAt(Math.floor(Math.random() * possible.length));

                return text;
            }
        }

        return ParseService;
    })
    .factory('PusherTrigger', function ($http) {

        var PusherTrigger = {
            triggerEvent: function (obj, win, fail) {

                $http.defaults.headers.common = {};
                $http.defaults.headers.post = {};
                $http.defaults.headers.put = {};
                $http.defaults.headers.patch = {};

                var headers = {
                    'Content-Type': 'application/json'
                };

                var baseURL = "http://grega.co";

                $http({
                    method: "POST",
                    url: obj.url,
                    headers: {
                        'Content-Type': 'application/json; charset=UTF-8'
                    },
                    datatype: 'json',
                    data: obj.data // pass in data as strings
                }).success(function (data, status) {
                    console.log(data);
                    console.log(status);
                    win(data, status);
                }).error(function (data, status) {
                    console.log(data);
                    console.log(status);
                    fail(data, status);
                });
                /*         var UPath = "http://54.252.109.57:29/gage/PushChat"; // For Testing On local Server 
                             $.ajax({
                                 url: UPath,
                                 type: "post",
                                 //contentType: "application/json; charset=utf-8",
                                 dataType: "json",
                                 data:obj.data, 
                                 /*{

                                     "message": "Hello",
                                     "user": {
                                         "display_name": "idrish",
                                         "email": "idrish@gmail.com",
                                         "phone": "415-392-0202",
                                         "user_state": "1",
                                         "username": "idrish",
                                         "objectId": "kt5MENgIUB",
                                         "createdAt": "2015-12-14",
                                         "updatedAt": "2015-12-16"
                                     },
                                     "messagea_id": "8EMEGJgNKv",
                                     "message_payload": {
                                         "message": "hi",
                                         "user": {
                                             "type": "Pointer",
                                             "className": "User",
                                             "objectId": "kt5MENgIUB"
                                         },
                                         "thread_id": "gRSQhRBg98-kt5MENgIUB-test",
                                         "objectId": "8EMEGJgNKv",
                                         "createdAt": "2015-12-16",
                                         "updatedAt": "2015-12-16"
                                     },

                                     "eventPush": "new_message",
                                     "channel": "threadId"
                                 },*

                                 success: function (result) {
                                     console.log(result);
                                 },
                                 error: function (xhr, status) {
                                     console.log(xhr.responseText);

                                 }
                             });*/
            }
        }

        return PusherTrigger;
    })
    .directive('scrollWatch', function ($rootScope) {
        return function (scope, elem, attr) {
            var start = 0;
            var threshold = 150;

            elem.bind('scroll', function (e) {
                if (e.detail.scrollTop - start > threshold) {
                    $rootScope.slideHeader = true;
                } else {
                    $rootScope.slideHeader = false;
                }
                if ($rootScope.slideHeaderPrevious >= e.detail.scrollTop - start) {
                    $rootScope.slideHeader = false;
                }
                $rootScope.slideHeaderPrevious = e.detail.scrollTop - start;
                $rootScope.$apply();
            });
        };
    }).factory('$localstorage', ['$window', function ($window) {
        return {
            set: function (key, value) {
                $window.localStorage[key] = value;
            },
            get: function (key, defaultValue) {
                return $window.localStorage[key] || defaultValue;
            },
            setObject: function (key, value) {
                $window.localStorage[key] = JSON.stringify(value);
            },
            getObject: function (key) {
                return JSON.parse($window.localStorage[key] || '{}');
            },
            clearAll: function () {
                $window.localStorage.clear();
            },
            removeItem: function (key) {
                $window.localStorage.removeItem(key);
            }
        }
}]);