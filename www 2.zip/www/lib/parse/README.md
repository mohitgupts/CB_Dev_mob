bower-parse
===========

[Bower](http://bower.io) package for [Parse](http://parse.com)

      bower install parse
