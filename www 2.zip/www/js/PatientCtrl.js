 cbApp.controller('PatientHomeCtrl', function ($scope, $rootScope, $state, $ionicPopup, $ionicScrollDelegate, $ionicLoading, $localstorage, $ionicHistory, ionicMaterialInk) {
     $scope.selectedDiv = 'Patient';
     $scope.Doctorsearched = false;
     $scope.searchList = [];
     $scope.Status = {
         statusType: ''
     }

     $scope.ViewProfile = function () {
         $state.go('tab.PatientProfile');
     }
     $scope.showTabCantent = function (option) {
         $scope.selectedDiv = option; //'Client';
         $scope.Doctorsearched = false;
         $ionicScrollDelegate.scrollTop();
     }

     $scope.chat = function (item) {

         $rootScope.chatUser = item;
         $rootScope.chatArchived = item.IsArchive;
         //console.log($rootScope.chatUser.get('PatientProfileObjectId').get('ProfileImage').url())

     }
     $scope.phoneCall = function (item) {
         if (item.IsCallAllowed) {
             if (item.ExotelNumber != 0) {
                 var confirmPopup = $ionicPopup.confirm({
                     title: 'CureBooth',
                     template: 'You will be charged ' + item.ChargesPerMin + ' credits/min., minimum charges is ' + item.FirstMin + ' credits',
                     cancelText: 'Cancel',
                     okText: 'Call'
                 });

                 confirmPopup.then(function (res) {
                     if (res) {
                         window.location = "tel:0" + item.ExotelNumber;
                     } else {
                         console.log('You are not sure');
                     }
                 });

             } //window.open('tel:0' + call, '_system');
             else
                 $rootScope.showAlert('No number to call')
         } else if (item.IsOfflineCall && item.IsPriority) {
             if (item.ExotelNumber != 0) {
                 var confirmPopup = $ionicPopup.confirm({
                     title: 'CureBooth',
                     template: 'You will be charged ' + item.ChargesPerMin + ' credits/min., minimum charges is ' + item.FirstMin + ' credits',
                     cancelText: 'Cancel',
                     okText: 'Call'
                 });

                 confirmPopup.then(function (res) {
                     if (res) {
                         window.location = "tel:0" + item.ExotelNumber;
                     } else {
                         console.log('You are not sure');
                     }
                 });

             } //window.open('tel:0' + call, '_system');
             else
                 $rootScope.showAlert('No number to call')
         } else
             $rootScope.showAlert('Doctor is offline ')
             //window.open('tel:900300400')
     }

     // list of status
     $scope.getStatusType = function () {
             //$ionicLoading.show();
             var query = new Parse.Query('StatusType');
             query.find({
                 success: function (results) {
                     $ionicLoading.hide();
                     if (results.length > 0) {
                         $scope.StatusType = results
                     }
                 },
                 error: function (error) {
                     $ionicLoading.hide();
                     //alert("Error: " + error.code + " " + error.message);
                 }
             });
         }
         // User current status
     $scope.getStatus = function () {
             //$ionicLoading.show();
             var query = new Parse.Query('UserStatus');
             query.equalTo('UserId', $rootScope.user.id);
             query.find({
                 success: function (results) {

                     $ionicLoading.hide();
                     if (results.length > 0) {
                         $scope.Status.statusType = results[0].get('StatusName')
                             //alert(object.id + ' - ' + object.get('playerName'));
                     }
                 },
                 error: function (error) {
                     $ionicLoading.hide();
                     //alert("Error: " + error.code + " " + error.message);
                 }
             });
         }
         // User current status
     function calculateAge(dd) { // birthday is a date
         console.log(dd)
         var ageDifMs = Date.now() - dd.getTime();
         var ageDate = new Date(ageDifMs); // miliseconds from epoch
         return Math.abs(ageDate.getUTCFullYear() - 1970);
     }
     $scope.DoctorList = {};
     $scope.DoctorListfn = function (id) {
         console.log(id)
         Parse.Cloud.run('DoctorList', {
             PatientProfileId: id
         }, {
             success: function (status) {
                 //$ionicLoading.hide();
                 $scope.DoctorList1 = [];
                 if (status.length > 0) {
                     for (i = 0; i < status.length; i++) {
                         var ProfileImage;
                         if (status[i].get('DoctorProfileObjectId').get('ProfileImage') != undefined) {
                             ProfileImage = status[i].get('DoctorProfileObjectId').get('ProfileImage').url();
                         } else {
                             ProfileImage = "img/patient_icon_default.png";
                         }
                         var IsCallAllowed;
                         if (status[i].get('DoctorProfileObjectId').get('StatusPointer') != undefined) {
                             IsCallAllowed = status[i].get('DoctorProfileObjectId').get('StatusPointer').get('IsCallAllowed');
                         } else {
                             IsCallAllowed = "";
                         }
                         var StatusName;
                         if (status[i].get('DoctorProfileObjectId').get('StatusPointer') != undefined) {
                             StatusName = status[i].get('DoctorProfileObjectId').get('StatusPointer').get('StatusName');
                         } else {
                             StatusName = "";
                         }
                         var ExotelNumber;
                         if (status[i].get('DoctorProfileObjectId').get('UserPointer') != undefined) {
                             ExotelNumber = status[i].get('DoctorProfileObjectId').get('UserPointer').get('ExotelNumber');
                         } else {
                             ExotelNumber = "";
                         }

                         var temp = {
                             chatThreadId: status[i].attributes.chatThreadId,
                             UserObjectId: status[i].attributes.DoctorUserObjectId,
                             PatientUserObjectId: status[i].attributes.PatientUserObjectId,
                             IsFollowed: status[i].attributes.IsFollowed,
                             IsPriority: status[i].attributes.IsPriority,
                             IsVerfied: status[i].attributes.IsVerfied,
                             id: status[i].attributes.DoctorProfileObjectId.id,
                             BriefOverview: status[i].attributes.DoctorProfileObjectId.attributes.BriefOverview,
                             ChargesPerMin: status[i].attributes.DoctorProfileObjectId.attributes.ChargesPerMin,
                             Clinic: status[i].attributes.DoctorProfileObjectId.attributes.Clinic,
                             FirstMin: status[i].attributes.DoctorProfileObjectId.attributes.FirstMin,
                             ForMins: status[i].attributes.DoctorProfileObjectId.attributes.ForMins,
                             FullName: status[i].attributes.DoctorProfileObjectId.attributes.FullName,
                             IsOfflineCall: status[i].attributes.DoctorProfileObjectId.attributes.IsOfflineCall,
                             Phone: status[i].attributes.DoctorProfileObjectId.attributes.Phone,
                             Qualification: status[i].attributes.DoctorProfileObjectId.attributes.Qualification,
                             Speciality: status[i].attributes.DoctorProfileObjectId.attributes.Specialist.attributes.Speciality,
                             ProfileImage: ProfileImage,
                             IsCallAllowed: IsCallAllowed,
                             StatusName: StatusName,
                             ExotelNumber: ExotelNumber,
                             ProfileLinkId: status[i].id,
                             isMute: status[i].attributes.PatientMuted,
                             Recommended: status[i].attributes.Recommended,
                             RecommendCounter: status[i].attributes.DoctorProfileObjectId.attributes.RecommendCounter,

                         }
                         $scope.DoctorList1.push(temp);
                         //console.log($scope.DoctorList);
                     }
                     //console.log($scope.DoctorList);
                     //
                     $localstorage.setObject('PatientDoctorList', $scope.DoctorList1);
                     $scope.DoctorList = $localstorage.getObject('PatientDoctorList');
                     $scope.$apply();
                 }
                 // te Profile table updated successfully
             },
             error: function (error) {
                 // debugger;
                 // error
             }
         });
     }
     $scope.chatListfn = function (id) {
         Parse.Cloud.run('ChatList', {
             ProfileId: id,
             IsDoctor: 0
         }, {
             success: function (status) {
                 if (status.length > 0) {
                     $scope.ChatList1 = [];
                     for (i = 0; i < status.length; i++) {
                         var ProfileImage;
                         if (status[i].get('DoctorProfileObjectId').get('ProfileImage') != undefined) {
                             ProfileImage = status[i].get('DoctorProfileObjectId').get('ProfileImage').url();
                         } else {
                             ProfileImage = "img/patient_icon_default.png";
                         }
                         var RecentMsg;
                         if (status[i].get('RecentMsg') != undefined) {
                             RecentMsg = status[i].get('RecentMsg').get('message');
                         } else {
                             RecentMsg = "";
                         }
                         var IsCallAllowed;
                         if (status[i].get('DoctorProfileObjectId').get('StatusPointer') != undefined) {
                             IsCallAllowed = status[i].get('DoctorProfileObjectId').get('StatusPointer').get('IsCallAllowed');
                         } else {
                             IsCallAllowed = "";
                         }
                         var StatusName;
                         if (status[i].get('DoctorProfileObjectId').get('StatusPointer') != undefined) {
                             StatusName = status[i].get('DoctorProfileObjectId').get('StatusPointer').get('StatusName');
                         } else {
                             StatusName = "";
                         }
                         var ExotelNumber;
                         if (status[i].get('DoctorProfileObjectId').get('UserPointer') != undefined) {
                             ExotelNumber = status[i].get('DoctorProfileObjectId').get('UserPointer').get('ExotelNumber');
                         } else {
                             ExotelNumber = "";
                         }
                         var temp = {
                             chatThreadId: status[i].attributes.chatThreadId,
                             UserObjectId: status[i].attributes.DoctorUserObjectId,
                             PatientUserObjectId: status[i].attributes.PatientUserObjectId,
                             IsFollowed: status[i].attributes.IsFollowed,
                             IsPriority: status[i].attributes.IsPriority,
                             IsVerfied: status[i].attributes.IsVerfied,
                             id: status[i].attributes.DoctorProfileObjectId.id,
                             BriefOverview: status[i].attributes.DoctorProfileObjectId.attributes.BriefOverview,
                             ChargesPerMin: status[i].attributes.DoctorProfileObjectId.attributes.ChargesPerMin,
                             Clinic: status[i].attributes.DoctorProfileObjectId.attributes.FirstMin,
                             FirstMin: status[i].attributes.DoctorProfileObjectId.attributes.BriefOverview,
                             FirstName: status[i].attributes.DoctorProfileObjectId.attributes.FirstName,
                             ForMins: status[i].attributes.DoctorProfileObjectId.attributes.ForMins,
                             FullName: status[i].attributes.DoctorProfileObjectId.attributes.FullName,
                             IsOfflineCall: status[i].attributes.DoctorProfileObjectId.attributes.IsOfflineCall,
                             LastName: status[i].attributes.DoctorProfileObjectId.attributes.LastName,
                             Phone: status[i].attributes.DoctorProfileObjectId.attributes.Phone,
                             Qualification: status[i].attributes.DoctorProfileObjectId.attributes.Qualification,
                             Speciality: status[i].attributes.DoctorProfileObjectId.attributes.Speciality,
                             ProfileImage: ProfileImage,
                             IsCallAllowed: IsCallAllowed,
                             StatusName: StatusName,
                             ExotelNumber: ExotelNumber,
                             RecentMsg: RecentMsg,
                             ProfileLinkId: status[i].id,
                             isMute: status[i].attributes.PatientMuted
                         }
                         $scope.ChatList1.push(temp);
                     }
                     $localstorage.setObject('PatientChatList', $scope.ChatList1);
                     $scope.ChatList = $localstorage.getObject('PatientChatList');
                     $scope.$apply();

                 }
             },
             error: function (error) {
                 // debugger;
                 // error
             }
         });
     }
     $scope.DocSearch = function (search) {
         if (!$rootScope.NetworkStatus) {
             var alertPopup = $ionicPopup.alert({
                 title: 'CureBooth',
                 cssClass: 'balance',
                 template: "Doctor search needs network connectivity !"
             });
             alertPopup.then(function (res) {
                 //navigator.app.exitApp();
             })
         } else {
             //$ionicLoading.show();
             Parse.Cloud.run('DocSearch', {
                 SearchString: search
             }, {
                 success: function (status) {

                     if (status.length > 0) {
                         $scope.searchList = [];
                         $scope.Doctorsearched = true;
                         $localstorage.setObject('searchList', status)
                         $scope.searchList = $localstorage.getObject('searchList')
                         $scope.$apply;
                     } else {
                         $scope.searchList = [];
                     }

                     $ionicLoading.hide();
                 },
                 error: function (error) {
                     $ionicLoading.hide();
                 }
             });
         }
     };
     // Call History Funtion
     $scope.callhistoryfn = function (id) {
         if ($localstorage.getObject('PatientCalllist') === null) {} //$ionicLoading.show();
         Parse.Cloud.run('GetCallHistory', {
             UserProfileId: id
         }, {
             success: function (results) {
                 //$ionicLoading.hide();
                 $scope.calllist_tmp = [] // results;
                 for (i = 0; i < results.length; i++) {
                     if ($rootScope.user.id == results[i].get("ToProfileObjectId").get("UserObjectId")) {
                         if (results[i].get("CallStatusType") == 1) {
                             results[i]['Incoming'] = 1;
                         } else if (results[i].get("CallStatusType") == 3) {
                             results[i]['Incoming'] = 3;
                         } else if (results[i].get("CallStatusType") == 4) {
                             results[i]['Incoming'] = 4;
                         } else if (results[i].get("CallStatusType") == 1 && results[i].get("Duration") == '0') {
                             results[i]['Incoming'] = 5;
                         }
                         $scope.calllist.push(results[i]);
                     } else if ($rootScope.user.id == results[i].get("FromProfileObjectId").get("UserObjectId")) {
                         if (results[i].get("CallStatusType") == 1) {
                             results[i]['Incoming'] = 1;
                         } else if (results[i].get("CallStatusType") == 3) {
                             results[i]['Incoming'] = 3;
                         } else if (results[i].get("CallStatusType") == 4) {
                             results[i]['Incoming'] = 4;
                         } else if (results[i].get("CallStatusType") == 1 && results[i].get("Duration") == '0') {
                             results[i]['Incoming'] = 5;
                         }
                         $scope.calllist_tmp.push(results[i]);
                     }
                 }
                 $localstorage.setObject('PatientCalllist', results);
                 $scope.calllist = $localstorage.getObject('PatientCalllist');
                 $scope.$apply();
             },
             error: function (error) {
                 $ionicLoading.hide();
                 // error
             }
         });
     };
     // Change user status

     $scope.status = function () {
         //$ionicLoading.show();
         Parse.Cloud.run('UserStatus', {
             StatusName: $scope.Status.statusType
         }, {
             success: function (status) {
                 // debugger;
                 $ionicLoading.hide();
                 // te Profile table updated successfully
             },
             error: function (error) {
                 $ionicLoading.hide();
                 // debugger;
                 // error
             }
         });
     }
     $scope.ViewDoctor = function (item) {

             if ($scope.Doctorsearched) {
                 $rootScope.DrData = item;
                 $state.go('tab.DrProfile');
             } else {
                 $rootScope.DrPtData = item;
                 $state.go('tab.PtDrHome');
             }

         }
         // Doctor profile
     $scope.showDetails = function (data) {
         console.log(data)
         $rootScope.DrData = data;
         $state.go('tab.DrProfile', {
             //clear: true
         });

     }
     $rootScope.profile = {}
     $scope.getProfile = function () {
         if ($localstorage.getObject('PatientProfile') == null) {} //$ionicLoading.show();
         Parse.Cloud.run('GetProfile', {
             UserObjectId: $rootScope.user.id,
         }, {
             success: function (data) {
                 $ionicLoading.hide();
                 var results = [];
                 results = data;
                 if (results != undefined && results != null) {
                     $localstorage.setObject('PatientProfile', results);
                     $scope.DoctorListfn(results.id);
                     $scope.callhistoryfn(results.id);
                     $scope.chatListfn(results.id);
                     $rootScope.user.ProfileId = results.id;
                     //$rootScope.UserProfile = results;
                     $rootScope.UserName = results.get('FullName');
                     if (results.get('ProfileImage') != undefined) {
                         $rootScope.ProfileImage = results.get('ProfileImage').url();
                         results.set("ProfileImg", results.get('ProfileImage').url());
                     } else {
                         $rootScope.ProfileImage = "img/patient_icon_default.png";
                         results.set("ProfileImg", "img/patient_icon_default.png");
                         //results.ProfileImage = "img/patient_icon_default.png";
                     }
                     $localstorage.setObject('PatientProfile', results);
                     $rootScope.UserProfile = $localstorage.getObject('PatientProfile')
                     $scope.$apply();
                 }
                 //console.log($localstorage.getObject('PatientProfile'))
             },
             error: function (error) {
                 $ionicLoading.hide();
             }
         });
     }


     // Intialize the controller 
     if ($rootScope.NetworkStatus) {
         $scope.DoctorList = $localstorage.getObject('PatientDoctorList');
         $scope.ChatList = $localstorage.getObject('PatientChatList');
         $scope.calllist = $localstorage.getObject('PatientCalllist');
         $rootScope.UserProfile = $localstorage.getObject('PatientProfile')
         $scope.getProfile();
     } else {
         $scope.DoctorList = $localstorage.getObject('PatientDoctorList');
         $scope.ChatList = $localstorage.getObject('PatientChatList');
         $scope.calllist = $localstorage.getObject('PatientCalllist');
         $rootScope.UserProfile = $localstorage.getObject('PatientProfile')

     }
     //ionicMaterialInk.displayEffect();
 })
 cbApp.controller('PatientProfileCtrl', function ($scope, $state, $ionicLoading, $rootScope, $http, $ionicModal, $ionicPopup, $localstorage, $cordovaCamera, $ionicScrollDelegate, $cordovaToast, ionicMaterialInk) {
     $scope.profile = {};
     $scope.editable = true;
     $scope.edit = function (id) {
         if ($rootScope.NetworkStatus)
             $scope.editable = id;
         else
             $cordovaToast.show('no connection available', 'short', 'center')

     }

     $scope.selectedDiv = 'Profile';
     $scope.Doctorsearched = false;
     $scope.searchList = [];
     $scope.UserProfile1;
     $scope.Status = {
         statusType: ''
     }
     $scope.showTabCantent = function (option) {
             $scope.selectedDiv = option; //'Client';
             $scope.Doctorsearched = false;
             $ionicScrollDelegate.scrollTop();
         }
         // To retirve dat form table
     $scope.getProfile = function () {
             $scope.profile = $localstorage.getObject('PatientProfile')
                 //$ionicLoading.show();
             Parse.Cloud.run('GetProfile', {
                 UserObjectId: $rootScope.user.id,
             }, {
                 success: function (results) {
                     $ionicLoading.hide();
                     if (results != undefined && results != null) {
                         $rootScope.user.ProfileId = results.id;
                         $scope.UserProfile1 = results;
                         $scope.profile = results;
                         $scope.profile.id = results.id;
                         $scope.UpcomingAppointment(results.id)
                         $rootScope.UserName = results.get('FirstName');
                         $scope.profile.FullName = results.get('FullName');
                         $scope.profile.Gender = results.get('Gender');
                         $scope.profile.Health_Summary = results.get('Health_Summary')
                         $scope.profile.Health_Conditions = results.get('Health_Conditions');
                         $scope.profile.Address = results.get('Address');
                         if (results.get('ProfileImage') != undefined) {
                             $scope.ProfileImage = results.get('ProfileImage').url();
                         } else {
                             $scope.ProfileImage = "img/patient_icon_default.png";
                         }
                         if (results.get('DOB') != undefined) {
                             $scope.profile.Age = calculateAge(results.get('DOB'))
                             console.log($scope.profile.Age)
                             if ($scope.profile.Age > 0)
                                 $scope.profile.Age = $scope.profile.Age + ' Years'
                         }
                         //$scope.Status.statusType = results.get('StatusPointer').id;
                     }
                 },
                 error: function (error) {
                     $ionicLoading.hide();
                     //$rootScope.showAlert(error);
                 }
             });
         }
         //Upcoming Appointment list
     $scope.UpcomingAppointment = function (id) {
             //$ionicLoading.show();
             Parse.Cloud.run('UpcomingAppointment', {
                 PatientProfile: id,
             }, {
                 success: function (results) {
                     $ionicLoading.hide();
                     $scope.UpcomingAppointmentList = results;
                 },
                 error: function (error) {
                     $ionicLoading.hide();
                     $scope.UpcomingAppointmentList = [];
                 }
             });
         }
         // cancel appointment
     $scope.cancelAppointment = function (id) {
         var alertPopup = $ionicPopup.confirm({
             title: 'CureBooth',
             template: 'Do you like to cancel the appointment ?'
         });
         alertPopup.then(function (res) {
             if (res) {
                 $ionicLoading.show();
                 Parse.Cloud.run('CancelAppointment', {
                     TokenId: id
                 }, {
                     success: function (results) {
                         $ionicLoading.hide();
                         $scope.getTokenList();
                         // te Profile table updated successfully
                     },
                     error: function (error) {
                         $rootScope.showAlert(error.message);
                         $ionicLoading.hide();
                         // error
                     }
                 });
             } else {
                 console.log('You are not sure');
             }
         });
     }

     function calculateAge(dd) { // birthday is a date
         console.log(dd)
         var ageDifMs = Date.now() - dd.getTime();
         var ageDate = new Date(ageDifMs); // miliseconds from epoch
         return Math.abs(ageDate.getUTCFullYear() - 1970);
     }
     $scope.updateProfile = function () {
         $ionicLoading.show();
         var point = $scope.UserProfile1;
         point.set("FullName", $scope.profile.FullName);
         point.set("LastName", $scope.profile.LastName);
         point.set("DOB", $scope.profile.DOB);
         point.set("Gender", $scope.profile.Gender);
         point.set("Health_Summary", $scope.profile.Health_Summary);
         point.set("Health_Conditions", $scope.profile.Health_Conditions);
         point.set("Address", $scope.profile.Address);
         // Save
         point.save(null, {
             success: function (point) {
                 $ionicLoading.hide();
                 $cordovaToast.show('Profile Updated Successfully', 'short', 'center')
                     //$rootScope.showAlert('Profile Saved successfully.');
                 $scope.editable = true;
             },
             error: function (point, error) {
                 $ionicLoading.hide();
                 $rootScope.showAlert(error);
             }
         });
     }
     $scope.imageData = "";


     // Upload Image
     $scope.uploadImg = function () {
         $ionicLoading.show();
         var ProfileParse = $scope.UserProfile1;
         var objProfileLink = $scope.UserProfile1;
         if ($scope.imageData != "") {
             var parseFile = new Parse.File("ProfileImg.jpg", {
                 base64: $scope.imageData
             });
             objProfileLink.set("ProfileImage", parseFile);
             console.log('create profile link');
             objProfileLink.save(null, {
                 success: function (employee) {
                     var alertPopup = $ionicPopup.alert({
                         title: 'CureBooth',
                         cssClass: 'balance',
                         template: 'Profile image updated successfully.'
                     });
                     alertPopup.then(function (res) {
                         $scope.closeProfileModal();
                     });
                     $ionicLoading.hide();
                 },
                 error: function (employee, error) {
                     $ionicLoading.hide();
                     //alert('error:' + error.message.toString());
                 }
             });
         }
     }

     document.addEventListener("deviceready", function () {
         $scope.takePhotoPatient = function (data) {
             console.log(data)
             if (data == 1)
                 $scope.cemera();
             else
                 $scope.gallery();
         }
     }, false);
     $scope.cemera = function () {
         var options = {
             quality: 65,
             destinationType: Camera.DestinationType.DATA_URL,
             sourceType: Camera.PictureSourceType.CAMERA,
             allowEdit: true,
             encodingType: Camera.EncodingType.JPEG,
             targetWidth: 100,
             targetHeight: 100,
             popoverOptions: CameraPopoverOptions,
             saveToPhotoAlbum: false,
             correctOrientation: true
         };

         $cordovaCamera.getPicture(options).then(function (imageData) {
             $scope.imageData = imageData;
             $scope.ProfileImage = "data:image/jpeg;base64," + imageData;
         }, function (err) {
             // error
         });

     }
     $scope.gallery = function () {
         var options = {
             quality: 65,
             destinationType: Camera.DestinationType.DATA_URL,
             sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
             allowEdit: true,
             encodingType: Camera.EncodingType.JPEG,
             targetWidth: 100,
             targetHeight: 100,
             popoverOptions: CameraPopoverOptions,
             saveToPhotoAlbum: false,
             correctOrientation: true
         };

         $cordovaCamera.getPicture(options).then(function (imageData) {
             $scope.imageData = imageData;
             $scope.ProfileImage = "data:image/jpeg;base64," + imageData;
         }, function (err) {
             // error
         });

     }
     $ionicModal.fromTemplateUrl('profile-img.html', {
         scope: $scope,
         animation: 'fade-in-up'
     }).then(function (modal) {
         $scope.profileImgmodal = modal;
     });
     $scope.openProfileModal = function () {
         if ($rootScope.NetworkStatus)
             $scope.profileImgmodal.show();
         else
             $cordovaToast.show('no connection available', 'short', 'center')
             //$scope.profileImgmodal.show();
     };
     $scope.closeProfileModal = function () {
         $scope.profileImgmodal.hide();
     };
     //Cleanup the modal when we're done with it!
     $scope.$on('$destroy', function () {
         $scope.profileImgmodal.remove();
     });
     // Intialize the controller 
     if ($rootScope.NetworkStatus) {
         $scope.profile = $localstorage.getObject('PatientProfile')
         $scope.getProfile();

     } else {
         $scope.profile = $localstorage.getObject('PatientProfile')
     }

     //ionicMaterialInk.displayEffect();
 })
 cbApp.controller('DoctorSearchCtrl', function ($scope, $state, $ionicLoading, $rootScope, $http, $ionicPopup, $localstorage, $ionicPopover, ionicMaterialInk) {
     $scope.selectedDiv = 'browse'
     $scope.searchchoise = 0;
     $scope.showTabCantent = function (option) {
         $scope.selectedDiv = option; //'Client';
         $ionicScrollDelegate.scrollTop();
     }
     console.log('.......:' + localStorage.getItem("isActive"))
         // tip active 
     $scope.isActive = true;
     if (localStorage.getItem("isActive") == "notshow") {
         $scope.isActive = false;
         console.log('notshow tip')
     }
     $scope.search = '';
     $scope.SearchList = [];
     $scope.DocSearch = function (search) {
         if (!$rootScope.NetworkStatus) {
             var alertPopup = $ionicPopup.alert({
                 title: 'CureBooth',
                 cssClass: 'balance',
                 template: "Doctor search needs network connectivity !"
             });
             alertPopup.then(function (res) {
                 //navigator.app.exitApp();
             })
         } else {
             if (search == null) {
                 return false
             }
             //$ionicLoading.show();
             Parse.Cloud.run('DocSearch', {
                 SearchString: search
             }, {
                 success: function (status) {

                     if (status.length > 0) {
                         $scope.searchList = [];
                         $localstorage.setObject('searchList', status)
                         $scope.searchList = $localstorage.getObject('searchList')
                             //$scope.searchList = JSON.stringify(status);
                         $scope.$apply;
                     } else {
                         $scope.searchList = [];
                     }

                     $ionicLoading.hide();
                 },
                 error: function (error) {
                     $ionicLoading.hide();
                 }
             });
         }
     };
     $scope.onCloseClicked = function (data) {
         console.log('Clicked' + data)
     }
     $scope.pindata = $rootScope.PinCode;
     $scope.PinCode = $rootScope.Address;
     $scope.AdvanceDoctorSearch = function (pincode, Speciality) {
         if (!$rootScope.NetworkStatus) {} else {
             //$ionicLoading.show();
             //$scope.pindata = "";
             if (pincode == $rootScope.Address)
                 $scope.pindata = $rootScope.PinCode;
             else
                 $scope.pindata = pincode;
             if (Speciality == "None")
                 Speciality = ""
             Parse.Cloud.run('AdvanceDoctorSearch', {
                 Pincode: $scope.pindata,
                 SpecialityId: Speciality
             }, {
                 success: function (status) {

                     if (status.length > 0) {
                         $scope.searchList = [];
                         $localstorage.setObject('searchList', status)
                         $scope.searchList = $localstorage.getObject('searchList');
                         $scope.$apply;
                     } else {
                         $scope.searchList = [];
                     }

                     $ionicLoading.hide();
                 },
                 error: function (error) {
                     $scope.searchList = [];
                     $ionicLoading.hide();
                 }
             });
         }
     };
     $scope.GetDoctorSpeciality = function () {
         if (!$rootScope.NetworkStatus) {} else {
             //$ionicLoading.show();
             Parse.Cloud.run('GetDocSpeciality', {
                 //SearchString: search
             }, {
                 success: function (status) {

                     if (status.length > 0) {
                         $scope.searchList = [];
                         $localstorage.setObject('DoctorSpeciality', status)
                         $scope.DoctorSpeciality = $localstorage.getObject('DoctorSpeciality');
                         $scope.DoctorSpeciality.unshift({
                                 "IsActive": true,
                                 "Priority": 0,
                                 "Speciality": "None",
                                 "__type": "Object",
                                 "className": "DoctorSpeciality",
                                 "createdAt": "2016-04-05T17:08:13.967Z",
                                 "objectId": "fZrvQx3gMZ",
                                 "updatedAt": "2016-04-05T17:09:34.584Z"
                             })
                             //$scope.searchList = JSON.stringify(status);
                         $scope.$apply;
                     }

                     $ionicLoading.hide();
                 },
                 error: function (error) {
                     $ionicLoading.hide();
                 }
             });
         }
     };
     $scope.searchPopover = function (pin, spelty) {
         $scope.AdvanceDoctorSearch(pin, spelty)
         $scope.closePopover();
     };
     // .fromTemplateUrl() method
     $ionicPopover.fromTemplateUrl('my-popover.html', {
         scope: $scope
     }).then(function (popover) {
         $scope.popover = popover;
     });
     /* var alertPopup = $ionicPopup.alert({
          title: 'CureBooth',
          cssClass: 'balance',
          template: "Search by current location OR enter PinCode manually"
      });
      alertPopup.then(function (res) {
              $scope.AdvanceDoctorSearch($rootScope.PinCode);
          })*/
     // drop down on change
     $scope.searchchoiseopted = function (id) {
         if (id == 1)
             $scope.AdvanceDoctorSearch();
     }
     $scope.openPopover = function ($event) {
         $scope.Popoverdata = $scope.DoctorSpeciality;
         $scope.popover.show($event);
     };
     $scope.closePopover = function () {
         $scope.popover.hide();
     };
     //Cleanup the popover when we're done with it!
     $scope.$on('$destroy', function () {
         $scope.popover.remove();
     });
     // Execute action on hide popover
     $scope.$on('popover.hidden', function (data) {
         // Execute action
     });
     // Execute action on remove popover
     $scope.$on('popover.removed', function () {
         // Execute action
     });
     $scope.GetDoctorSpeciality();
     //$scope.AdvanceDoctorSearch();
     // Doctor profile
     $scope.showDetails = function (data) {
             console.log(data)
             $rootScope.DrData = data;
             $state.go('tab.DrProfile', {
                 //clear: true
             });
         }
         //ionicMaterialInk.displayEffect();
 })
 cbApp.controller('DrProfileCtrl', function ($scope, $state, $ionicLoading, $rootScope, $http, $ionicPopup, $ionicScrollDelegate, ionicMaterialInk) {
     $scope.DrProfile = [];
     results = $rootScope.DrData;
     console.log(results)
     $scope.selectedDiv = 'Profile';
     $scope.showTabCantent = function (option) {
         $scope.selectedDiv = option; //'Client';
         $scope.Doctorsearched = false;
         $ionicScrollDelegate.scrollTop();
     }
     $scope.isFriend = true;
     $scope.isSent = false;
     $scope.DrProfile.FullName = results.FullName;
     $scope.DrProfile.LastName = results.LastName;
     $scope.DrProfile.BriefOverview = results.BriefOverview;
     $scope.DrProfile.Qualification = results.Qualification;

     $scope.DrProfile.Clinic = results.Clinic;
     $scope.DrProfile.id = results.id;
     $scope.DrProfile.RecommendCounter = results.RecommendCounter;
     if (results.Specialist != undefined) {
         $scope.DrProfile.Speciality = results.Specialist.Speciality;
     } else {
         $scope.DrProfile.Speciality = "";
     }
     if (results.ProfileImage != undefined) {
         $scope.DrProfile.ProfileImage = results.ProfileImage.url;
     } else {
         $scope.DrProfile.ProfileImage = "img/doctor_icon_default.png";
     }
     $scope.chat = function (item) {
             $rootScope.chatUser = item //results.get('DoctorProfileObjectId');
                 //console.log($rootScope.chatUser.get('PatientProfileObjectId').get('ProfileImage').url())

         }
         // is followed
     $scope.SetDoctorFollowed = function (id, amt) {
         //$ionicLoading.show();
         Parse.Cloud.run('SetDoctorFollowed', {
             DocProfileId: id,
             IsFollowed: amt,
             PatProfileId: $rootScope.user.ProfileId
         }, {
             success: function (status) {
                 $ionicLoading.hide();
                 //$rootScope.showAlert('Doctor followed Successfully');
                 // te Profile table updated successfully
             },
             error: function (error) {
                 console.log(error)
                 $ionicLoading.hide();
                 $rootScope.showAlert(error.message);
                 // debugger;
                 // error
             }
         });
     }

     $scope.isFriendFn = function () {
         Parse.Cloud.run('IsFriend', {
             DocProfileObjectId: results.objectId,
             PatientProfileObjectId: $rootScope.user.ProfileId
         }, {
             success: function (result) {
                 if (result.get('DoctorAction').get('actionName') == "Approved") {
                     $scope.isFriend = false;
                     $scope.FriendData = result;
                     $scope.DrProfile.isMute = result.get('PatientMuted');
                     $scope.DrProfile.DoctorFollowed = result.get('IsFollowed');
                 } else if (result.get('DoctorAction').get('actionName') == 'Sent') {
                     $scope.isFriend = true;
                     $scope.isSent = true;
                 } else {
                     $scope.isSent = false;
                     $scope.isFriend = true;
                 }
                 $scope.$apply();
             },
             error: function (error) {
                 console.log(error)
                 $scope.isFriend = true;
                 $scope.isSent = false;
                 $scope.$apply();
                 //$rootScope.showAlert(error.message);
             }
         });
     }

     $scope.phoneCall = function (item) {
         if (item.get("DoctorProfileObjectId").get("StatusPointer").get("IsCallAllowed")) {
             if (item.get("DoctorProfileObjectId").get("UserPointer").get("ExotelNumber") != 0) {
                 var confirmPopup = $ionicPopup.confirm({
                     title: 'CureBooth',
                     template: 'You will be charged ' + item.get("DoctorProfileObjectId").get("ChargesPerMin") + ' credits/min., minimum charges is ' + item.get("DoctorProfileObjectId").get("FirstMin") + ' credits',
                     cancelText: 'Cancel',
                     okText: 'Call'
                 });

                 confirmPopup.then(function (res) {
                     if (res) {
                         window.location = "tel:0" + item.get("DoctorProfileObjectId").get("UserPointer").get("ExotelNumber");
                     } else {
                         console.log('You are not sure');
                     }
                 });

             } //window.open('tel:0' + call, '_system');
             else
                 $rootScope.showAlert('No number to call')
         } else if (item.get("DoctorProfileObjectId").get("IsOfflineCall") && item.get("IsPriority")) {
             if (item.get("DoctorProfileObjectId").get("UserPointer").get("ExotelNumber") != 0) {
                 var confirmPopup = $ionicPopup.confirm({
                     title: 'CureBooth',
                     template: 'You will be charged ' + item.get("DoctorProfileObjectId").get("ChargesPerMin") + ' credits/min., minimum charges is ' + item.get("DoctorProfileObjectId").get("FirstMin") + ' credits',
                     cancelText: 'Cancel',
                     okText: 'Call'
                 });

                 confirmPopup.then(function (res) {
                     if (res) {
                         window.location = "tel:0" + item.get("DoctorProfileObjectId").get("UserPointer").get("ExotelNumber");
                     } else {
                         console.log('You are not sure');
                     }
                 });

             } //window.open('tel:0' + call, '_system');
             else
                 $rootScope.showAlert('No number to call')
         } else
             $rootScope.showAlert('Doctor is offline ')
             //window.open('tel:900300400')
     }

     $scope.isFriendFn();
     $scope.conect = function () {
             var confirmPopup = $ionicPopup.confirm({
                 title: 'CureBooth',
                 template: 'Connect to this Doctor?'
             });

             confirmPopup.then(function (res) {
                 if (res) {
                     $ionicLoading.show();
                     Parse.Cloud.run('RequestDoctor', {
                         DoctorUserId: results.UserObjectId,
                         DoctorProfileId: results.objectId,
                         PatientUserId: $rootScope.user.id,
                         PatientProfileId: $rootScope.user.ProfileId,
                         PatientName: $rootScope.UserProfile.FullName
                     }, {
                         success: function (result) {
                             $scope.isFriend = result;
                             var alertPopup = $ionicPopup.alert({
                                 title: 'CureBooth',
                                 template: 'Request sent successfully'
                             });
                             alertPopup.then(function (res) {
                                 $state.go('tab.PatientHome');
                             });
                             $ionicLoading.hide();
                         },
                         error: function (error) {
                             $rootScope.showAlert(error.message);
                             $ionicLoading.hide();
                         }
                     });
                 } else {
                     console.log('You are not sure');
                 }
             });

         }
         //ionicMaterialInk.displayEffect();
 })
 cbApp.controller('PtDrProfileCtrl', function ($scope, $state, $ionicLoading, $ionicModal, $ionicPopup, $cordovaToast, $rootScope, $http, $ionicScrollDelegate, ionicMaterialInk) {
     $scope.selectedDiv = 'Profile'
     $scope.showTabCantent = function (option) {
         $scope.selectedDiv = option; //'Client';
         $ionicScrollDelegate.scrollTop();
     }
     $scope.TokenStatus = TokenStatus;
     $scope.DaysList = [];
     var weekday = [
    'S',
    'M',
    'T',
    'W',
    'T',
    'F',
    'S'
];
     var now = new Date();
     $scope.currentDay = now.getDay();
     for (i = 0; i < 7; i++) {
         //var dayName = weekday[(now.getDay() + i) % 7];
         var temp = {
             name: weekday[(now.getDay() + i) % 7],
             id: (now.getDay() + i) % 7
         }

         $scope.DaysList.push(temp)
     }
     $scope.changeDay = function (id) {
         $scope.currentDay = id;
         $scope.getTokenList();
     }
     $scope.Status = {
         statusType: false
     }
     $scope.myEvent = function (evt) {
         console.log('xsdfsdf' + evt)
     }
     $scope.myEvent1 = function (evt) {
         console.log('xsdfsdf')
     }
     $scope.calllist = [];
     $scope.PtDrProfile = [];
     console.log($rootScope.DrPtData)
     results = $rootScope.DrPtData;
     $scope.PtDrProfile.FirstName = results.FirstName;
     $scope.PtDrProfile.LastName = results.LastName;
     $scope.PtDrProfile.FullName = results.FullName
     $scope.PtDrProfile.BriefOverview = results.BriefOverview;
     $scope.PtDrProfile.Qualification = results.Qualification;
     $scope.PtDrProfile.Speciality = results.Speciality;
     $scope.PtDrProfile.Clinic = results.Clinic;
     $scope.PtDrProfile.ObjectId = results.UserObjectId;
     $scope.PtDrProfile.FirstMin = results.FirstMin;
     $scope.PtDrProfile.ChargesPerMin = results.ChargesPerMin;
     $scope.PtDrProfile.DrProfileId = results.id;
     $scope.PtDrProfile.DoctorFollowed = results.IsFollowed;
     $scope.PtDrProfile.IsCallAllowed = results.IsCallAllowed
     $scope.PtDrProfile.ProfileImage = results.ProfileImage;
     $scope.PtDrProfile.ExotelNumber = results.ExotelNumber;
     $scope.PtDrProfile.RecommendCounter = results.RecommendCounter;
     $scope.PtDrProfile.IsPriority = results.IsPriority;
     $scope.PtDrProfile.IsOfflineCall = results.IsOfflineCall;
     $scope.PtDrProfile.IsFollowed = results.IsFollowed
     $scope.PtDrProfile.IsVerfied = results.IsVerfied
     $scope.PtDrProfile.isMute = results.isMute
     $scope.PtDrProfile.id = results.id
     if (results.ExotelNumber != 0)
         $scope.PtDrProfile.DoctorNumber = '0' + results.ExotelNumber;
     else
         $scope.PtDrProfile.DoctorNumber = " ";

     $scope.PtDrProfile.chatThreadId = results.chatThreadId;
     $scope.PtDrProfile.UserObjectId = results.UserObjectId
     $scope.ClinicListdata = [];
     $scope.ClinicList = function () {
         if (!$rootScope.NetworkStatus) {} else {
             Parse.Cloud.run('ClinicList', {
                 DoctorProfile: $scope.PtDrProfile.id
             }, {
                 success: function (status) {
                     if (status.length > 0) {
                         var ln = status.length;
                         for (i = 0; i < ln; i++) {
                             var tmp = {
                                 Name: status[i].get('Name'),
                                 Admin: status[i].get('AdminProfile').id,
                                 AdminName: status[i].get('AdminProfile').get('FullName'),
                                 AdminNumber: status[i].get('AdminProfile').get('Phone'),
                                 Address: status[i].get('Address'),
                                 Pincode: parseInt(status[i].get('Pincode')),
                                 id: status[i].id,
                                 city: status[i].get('city'),
                                 area: status[i].get('Area'),
                                 DoctorProfileId: status[i].get('DoctorProfileId'),
                                 DoctorUserId: status[i].get('DoctorUserId'),
                                 ConsultationFee: status[i].get('ConsultationFee')

                             }
                             $scope.ClinicListdata.push(tmp)
                         }

                         $scope.$apply;
                     } else {
                         $scope.ClinicListdata = [];
                     }
                     $ionicLoading.hide();
                 },
                 error: function (error) {
                     $ionicLoading.hide();
                 }
             });
         }
     };

     $scope.DummyToken = false;
     $scope.TokenList = [];
     $scope.DummyTokenList = [];
     $scope.Patient = {};
     $scope.getTokenList = function (id) {
             if (id != null)
                 $scope.currentClinicId = id;
             else

                 $ionicLoading.show();
             Parse.Cloud.run('TokenList', {
                 DoctorProfile: $scope.PtDrProfile.id,
                 ClinicId: $scope.currentClinicId,
                 DayId: $scope.currentDay
             }, {
                 success: function (results) {
                     $ionicLoading.hide();
                     if (results.length > 0) {
                         $scope.TokenList = [];
                         var ln = results.length;
                         for (i = 0; i < ln; i++) {
                             var tmp1 = '';
                             var oldseating;
                             if (i == 0)
                                 oldseating = results[i].get('TokenId').replace(/[0-9]/g, '');
                             else
                                 oldseating = results[i - 1].get('TokenId').replace(/[0-9]/g, '');
                             if (results[i].get('TokenType') == "1") {
                                 var tmp = {};
                                 console.log(results[i].get('TokenId').replace(/[0-9]/g, '') + ' == ' + oldseating)
                                 if (results[i].get('TokenId').replace(/[0-9]/g, '') == oldseating) {
                                     changeseating = i;
                                     if (i + 2 < ln) {
                                         tmp1 = results[i].get('Start') + ' - ' + results[i + 2].get('End');
                                     } else {
                                         tmp1 = results[i].get('Start') + ' - ' + results[ln - 1].get('End');
                                     }
                                     tmp = {
                                             timestamp: tmp1,
                                             id: results[i].id,
                                             ClinicId: results[i].get('ClinicId'),
                                             End: results[i].get('End'),
                                             EndTime: results[i].attributes.EndTime.toString(),
                                             ScheduleId: results[i].get('ScheduleId'),
                                             Start: results[i].get('Start'),
                                             StartTime: results[i].attributes.StartTime.toString(),
                                             Status: results[i].get('Status').get('Name'),
                                             StatusId: results[i].get('Status').id,
                                             TokenId: results[i].get('TokenId'),
                                             StartTime: results[i].get('StartTime').iso
                                         }
                                         //$scope.TokenList.push(tmp);
                                 } else {
                                     var last;
                                     var lnt
                                     if (changeseating + 1 % 2 == 0) {
                                         last = changeseating - 2;
                                     } else {
                                         last = changeseating - 1;
                                     }
                                     if ($scope.TokenList.length % 2 == 0) {
                                         lnt = $scope.TokenList.length - 2;
                                     } else {
                                         lnt = $scope.TokenList.length - 1;
                                     }
                                     console.log($scope.TokenList);
                                     console.log($scope.TokenList.length);

                                     console.log($scope.TokenList[lnt].timestamp);
                                     $scope.TokenList[lnt].timestamp = results[last].get('Start') + ' - ' + results[i - 1].get('End');
                                      if (i % 3 != 0) {
                                            if (i % 3 == 1) {
                                                var tmp = {
                                                     id:"1100"+oldseating,
                                                    ScheduleId: "",
                                                    Start: ""
                                                }
                                                var tmp1 = { id:"1111"+oldseating,ScheduleId: "",
                                                    Start: ""}
                                                $scope.TokenList.push(tmp);
                                                $scope.TokenList.push(tmp1);
                                            } else
                                                $scope.TokenList.push(tmp);
                                        }

                                     tmp = {};
                                     tmp1 = ''
                                     if (i + 2 < ln) {
                                         tmp1 = results[i].get('Start') + ' - ' + results[i + 2].get('End');
                                     } else {
                                         tmp1 = results[i].get('Start') + ' - ' + results[ln - 1].get('End');
                                     }
                                     tmp = {
                                         timestamp: tmp1,
                                         id: results[i].id,
                                         ClinicId: results[i].get('ClinicId'),
                                         End: results[i].get('End'),
                                         EndTime: results[i].attributes.EndTime.toString(),
                                         ScheduleId: results[i].get('ScheduleId'),
                                         Start: results[i].get('Start'),
                                         StartTime: results[i].attributes.StartTime.toString(), //.get('StartTime').ios,
                                         Status: results[i].get('Status').get('Name'),
                                         StatusId: results[i].get('Status').id,
                                         TokenId: results[i].get('TokenId'),
                                         StartTime: results[i].get('StartTime').iso
                                     }

                                 }

                                 $scope.TokenList.push(tmp);

                             } else {
                                 $scope.DummyToken = true;
                                 var tmp = {
                                     // timestamp: tmp,
                                     id: results[i].id,
                                     ClinicId: results[i].get('ClinicId'),
                                     End: results[i].get('End'),
                                     EndTime: results[i].attributes.EndTime.toString(),
                                     ScheduleId: results[i].get('ScheduleId'),
                                     Start: results[i].get('Start'),
                                     StartTime: results[i].attributes.StartTime.toString(), //.get('StartTime').ios,
                                     Status: results[i].get('Status').get('Name'),
                                     StatusId: results[i].get('Status').id,
                                     TokenId: results[i].get('TokenId')
                                 }
                                 $scope.DummyTokenList.push(tmp);
                             }
                         }
                         //console.log($scope.TokenList)
                         $scope.$apply();
                     } else {
                         $scope.TokenList = [];
                         $scope.DummyTokenList = [];
                     }
                 },
                 error: function (error) {
                     $ionicLoading.hide();
                     if (error.code == 209)
                         $state.go('login');
                     //$rootScope.showAlert(error);
                 }
             });
         }
         // book function to check wheter token booked for not
     $scope.book = function (item) {
             $scope.bookingTokenId = item.id;
             if (item.StatusId == $scope.TokenStatus.Available) {
                 if ($scope.currentDay == now.getDay() && item.Start.split(":")[0] < now.getHours()) {
                     $rootScope.showAlert("Appointment Token has expired. Please book another Appointment token.")
                 } else {
                     var alertPopup = $ionicPopup.confirm({
                         title: 'CureBooth',
                         template: 'Do you like to book the appointment ?'
                     });
                     alertPopup.then(function (res) {
                         if (res) {
                             $ionicLoading.show();
                             Parse.Cloud.run('BookAppointment', {
                                 TokenId: $scope.bookingTokenId,
                                 BookedProfile: $rootScope.user.ProfileId
                             }, {
                                 success: function (status) {
                                     if (status != undefined) {
                                         $scope.getTokenList();
                                         $rootScope.showAlert("Your appointment booked successfully.")
                                         $scope.$apply;
                                     }
                                     $ionicLoading.hide();
                                 },
                                 error: function (error) {
                                     $ionicLoading.hide();
                                 }
                             });
                         } else {
                             console.log('You are not sure');
                         }
                     });
                 }
             } //else if (item.StatusId == $scope.TokenStatus.Booked)
             //$scope.openBookAppoitmentModal();
         }
         /* $scope.clinicDetails = function (id) {
              $rootScope.ClinicData = id;
              $state.go('tab.ClinicDetails')
          }*/

     /*Get Clinic Schedule*/
     function formatTimeToAMPM(date) {
         var hours = date.split(":")[0];
         var minutes = date.split(":")[1];
         var ampm = hours >= 12 ? 'PM' : 'AM';
         hours = hours % 12;
         hours = hours ? hours : 12;
         var strTime = hours + ':' + minutes + ' ' + ampm;
         return strTime;
     }
     $scope.ClinicListWithSchedule = function (id) {
         if (!$rootScope.NetworkStatus) {} else {
             Parse.Cloud.run('ClinicListWithSchedule', {
                 DoctorProfile: $scope.PtDrProfile.id,
                 ClinicId: id
             }, {
                 success: function (status) {
                     if (status.length > 0) {
                         var ln = status.length;
                         var start = status[0].get('StartSlot');
                         var end = status[0].get('EndSlot');
                         $scope.tmpdata = [];
                         var clinic = {}
                         $scope.ClinicListWithSchedule = [];
                         var sun = []
                         var mon = []
                         var tue = []
                         var wed = []
                         var thu = []
                         var fri = []
                         var sat = []
                         for (i = 0; i < ln; i++) {
                             switch (status[i].get('DayId')) {
                             case 0:
                                 var tmp1 = {
                                     start: formatTimeToAMPM(status[i].get('StartSlot')),
                                     end: formatTimeToAMPM(status[i].get('EndSlot')),
                                     start1: status[i].get('StartSlot'),
                                     end1: status[i].get('EndSlot'),
                                     TokenDuration: status[i].get('TokenDuration'),
                                     SlotId: status[i].get('SlotId')
                                 }
                                 sun.push(tmp1);
                                 break;
                             case 1:
                                 var tmp2 = {
                                     start: formatTimeToAMPM(status[i].get('StartSlot')),
                                     end: formatTimeToAMPM(status[i].get('EndSlot')),
                                     start1: status[i].get('StartSlot'),
                                     end1: status[i].get('EndSlot'),
                                     TokenDuration: status[i].get('TokenDuration'),
                                     SlotId: status[i].get('SlotId')
                                 }
                                 mon.push(tmp2);
                                 break;
                             case 2:
                                 var tmp3 = {
                                     start: formatTimeToAMPM(status[i].get('StartSlot')),
                                     end: formatTimeToAMPM(status[i].get('EndSlot')),
                                     start1: status[i].get('StartSlot'),
                                     end1: status[i].get('EndSlot'),
                                     TokenDuration: status[i].get('TokenDuration'),
                                     SlotId: status[i].get('SlotId')
                                 }
                                 tue.push(tmp3);
                                 break;
                             case 3:
                                 var tmp4 = {
                                     start: formatTimeToAMPM(status[i].get('StartSlot')),
                                     end: formatTimeToAMPM(status[i].get('EndSlot')),
                                     start1: status[i].get('StartSlot'),
                                     end1: status[i].get('EndSlot'),
                                     TokenDuration: status[i].get('TokenDuration'),
                                     SlotId: status[i].get('SlotId')
                                 }
                                 wed.push(tmp4);
                                 break;
                             case 4:
                                 var tmp5 = {
                                     start: formatTimeToAMPM(status[i].get('StartSlot')),
                                     end: formatTimeToAMPM(status[i].get('EndSlot')),
                                     start1: status[i].get('StartSlot'),
                                     end1: status[i].get('EndSlot'),
                                     TokenDuration: status[i].get('TokenDuration'),
                                     SlotId: status[i].get('SlotId')
                                 }
                                 thu.push(tmp5);
                                 break;
                             case 5:
                                 var tmp6 = {
                                     start: formatTimeToAMPM(status[i].get('StartSlot')),
                                     end: formatTimeToAMPM(status[i].get('EndSlot')),
                                     start1: status[i].get('StartSlot'),
                                     end1: status[i].get('EndSlot'),
                                     TokenDuration: status[i].get('TokenDuration'),
                                     SlotId: status[i].get('SlotId')
                                 }
                                 fri.push(tmp6);
                                 break;
                             case 6:
                                 var tmp7 = {
                                     start: formatTimeToAMPM(status[i].get('StartSlot')),
                                     end: formatTimeToAMPM(status[i].get('EndSlot')),
                                     start1: status[i].get('StartSlot'),
                                     end1: status[i].get('EndSlot'),
                                     TokenDuration: status[i].get('TokenDuration'),
                                     SlotId: status[i].get('SlotId')
                                 }
                                 sat.push(tmp7);
                                 break;
                             }


                         }
                         var t1 = {
                             Day: "Sunday",
                             Dayid: "0",
                             schedule: sun
                         }
                         $scope.ClinicListWithSchedule.push(t1)
                         var t2 = {
                             Day: "Monday",
                             Dayid: "1",
                             schedule: mon
                         }
                         $scope.ClinicListWithSchedule.push(t2)
                         var t3 = {
                             Day: "Tuesday",
                             Dayid: "2",
                             schedule: tue
                         }
                         $scope.ClinicListWithSchedule.push(t3)
                         var t4 = {
                             Day: "Wednesday",
                             Dayid: "3",
                             schedule: wed
                         }
                         $scope.ClinicListWithSchedule.push(t4)
                         var t5 = {
                             Day: "Thursday",
                             Dayid: "4",
                             schedule: thu
                         }
                         $scope.ClinicListWithSchedule.push(t5)
                         var t6 = {
                             Day: "Friday",
                             Dayid: "5",
                             schedule: fri
                         }
                         $scope.ClinicListWithSchedule.push(t6)
                         var t7 = {
                             Day: "Saturday",
                             Dayid: "6",
                             schedule: sat
                         }
                         $scope.ClinicListWithSchedule.push(t7)
                         console.log($scope.ClinicListWithSchedule);

                         $scope.$apply;
                     }
                     $ionicLoading.hide();
                 },
                 error: function (error) {
                     $ionicLoading.hide();
                 }
             });
         }
     };
     /*Show Clinic Details*/
     $ionicModal.fromTemplateUrl('ClinicDetails.html', {
         scope: $scope,
         animation: 'fade-in-up'
     }).then(function (modal) {
         $scope.ClinicDetailsModal = modal;
     });
     $scope.openClinicDetailsModal = function (item) {
         if ($rootScope.NetworkStatus) {
             $scope.clinic = item;
             $scope.ClinicListWithSchedule = [];
             $ionicLoading.show();
             Parse.Cloud.run('ClinicListWithSchedule', {
                 DoctorProfile: $scope.PtDrProfile.id,
                 ClinicId: item.id
             }, {
                 success: function (status) {
                     if (status.length > 0) {
                         var ln = status.length;
                         var start = status[0].get('StartSlot');
                         var end = status[0].get('EndSlot');
                         $scope.tmpdata = [];
                         var clinic = {}
                         $scope.ClinicListWithSchedule = [];
                         var sun = []
                         var mon = []
                         var tue = []
                         var wed = []
                         var thu = []
                         var fri = []
                         var sat = []
                         for (i = 0; i < ln; i++) {
                             switch (status[i].get('DayId')) {
                             case 0:
                                 var tmp1 = {
                                     start: formatTimeToAMPM(status[i].get('StartSlot')),
                                     end: formatTimeToAMPM(status[i].get('EndSlot')),
                                     start1: status[i].get('StartSlot'),
                                     end1: status[i].get('EndSlot'),
                                     TokenDuration: status[i].get('TokenDuration'),
                                     SlotId: status[i].get('SlotId')
                                 }
                                 sun.push(tmp1);
                                 break;
                             case 1:
                                 var tmp2 = {
                                     start: formatTimeToAMPM(status[i].get('StartSlot')),
                                     end: formatTimeToAMPM(status[i].get('EndSlot')),
                                     start1: status[i].get('StartSlot'),
                                     end1: status[i].get('EndSlot'),
                                     TokenDuration: status[i].get('TokenDuration'),
                                     SlotId: status[i].get('SlotId')
                                 }
                                 mon.push(tmp2);
                                 break;
                             case 2:
                                 var tmp3 = {
                                     start: formatTimeToAMPM(status[i].get('StartSlot')),
                                     end: formatTimeToAMPM(status[i].get('EndSlot')),
                                     start1: status[i].get('StartSlot'),
                                     end1: status[i].get('EndSlot'),
                                     TokenDuration: status[i].get('TokenDuration'),
                                     SlotId: status[i].get('SlotId')
                                 }
                                 tue.push(tmp3);
                                 break;
                             case 3:
                                 var tmp4 = {
                                     start: formatTimeToAMPM(status[i].get('StartSlot')),
                                     end: formatTimeToAMPM(status[i].get('EndSlot')),
                                     start1: status[i].get('StartSlot'),
                                     end1: status[i].get('EndSlot'),
                                     TokenDuration: status[i].get('TokenDuration'),
                                     SlotId: status[i].get('SlotId')
                                 }
                                 wed.push(tmp4);
                                 break;
                             case 4:
                                 var tmp5 = {
                                     start: formatTimeToAMPM(status[i].get('StartSlot')),
                                     end: formatTimeToAMPM(status[i].get('EndSlot')),
                                     start1: status[i].get('StartSlot'),
                                     end1: status[i].get('EndSlot'),
                                     TokenDuration: status[i].get('TokenDuration'),
                                     SlotId: status[i].get('SlotId')
                                 }
                                 thu.push(tmp5);
                                 break;
                             case 5:
                                 var tmp6 = {
                                     start: formatTimeToAMPM(status[i].get('StartSlot')),
                                     end: formatTimeToAMPM(status[i].get('EndSlot')),
                                     start1: status[i].get('StartSlot'),
                                     end1: status[i].get('EndSlot'),
                                     TokenDuration: status[i].get('TokenDuration'),
                                     SlotId: status[i].get('SlotId')
                                 }
                                 fri.push(tmp6);
                                 break;
                             case 6:
                                 var tmp7 = {
                                     start: formatTimeToAMPM(status[i].get('StartSlot')),
                                     end: formatTimeToAMPM(status[i].get('EndSlot')),
                                     start1: status[i].get('StartSlot'),
                                     end1: status[i].get('EndSlot'),
                                     TokenDuration: status[i].get('TokenDuration'),
                                     SlotId: status[i].get('SlotId')
                                 }
                                 sat.push(tmp7);
                                 break;
                             }


                         }
                         var t1 = {
                             Day: "Sunday",
                             Dayid: "0",
                             schedule: sun
                         }
                         $scope.ClinicListWithSchedule.push(t1)
                         var t2 = {
                             Day: "Monday",
                             Dayid: "1",
                             schedule: mon
                         }
                         $scope.ClinicListWithSchedule.push(t2)
                         var t3 = {
                             Day: "Tuesday",
                             Dayid: "2",
                             schedule: tue
                         }
                         $scope.ClinicListWithSchedule.push(t3)
                         var t4 = {
                             Day: "Wednesday",
                             Dayid: "3",
                             schedule: wed
                         }
                         $scope.ClinicListWithSchedule.push(t4)
                         var t5 = {
                             Day: "Thursday",
                             Dayid: "4",
                             schedule: thu
                         }
                         $scope.ClinicListWithSchedule.push(t5)
                         var t6 = {
                             Day: "Friday",
                             Dayid: "5",
                             schedule: fri
                         }
                         $scope.ClinicListWithSchedule.push(t6)
                         var t7 = {
                             Day: "Saturday",
                             Dayid: "6",
                             schedule: sat
                         }
                         $scope.ClinicListWithSchedule.push(t7)
                         console.log($scope.ClinicListWithSchedule);

                         $scope.$apply;
                     }
                     $ionicLoading.hide();
                 },
                 error: function (error) {
                     $ionicLoading.hide();
                 }
             });


             $scope.ClinicDetailsModal.show();
         } else
             $cordovaToast.show('no connection available', 'short', 'center')

     };
     $scope.closeClinicDetailsModal = function () {
         $scope.PatientSearchList = [];
         $scope.ClinicDetailsModal.hide();
     };
     /*Show Clinic Details*/
     $ionicModal.fromTemplateUrl('ClinicTiming.html', {
         scope: $scope,
         animation: 'fade-in-up'
     }).then(function (modal) {
         $scope.ClinicTimingModal = modal;
     });
     $scope.showallTimings = function () {
         $scope.ClinicTimingModal.show();
     };
     $scope.closeClinicTimingModal = function () {
         $scope.PatientSearchList = [];
         $scope.ClinicTimingModal.hide();
     };
     //Cleanup the modal when we're done with it!
     $scope.$on('$destroy', function () {
         $scope.ClinicDetailsModal.remove();
         $scope.ClinicTimingModal.remove();
     });
     $scope.phoneCall = function (item) {
         if (item.IsCallAllowed) {
             if (item.ExotelNumber != 0) {
                 var confirmPopup = $ionicPopup.confirm({
                     title: 'CureBooth',
                     template: 'You will be charged ' + item.ChargesPerMin + ' credits/min., minimum charges is ' + item.FirstMin + ' credits',
                     cancelText: 'Cancel',
                     okText: 'Call'
                 });

                 confirmPopup.then(function (res) {
                     if (res) {
                         window.location = "tel:0" + item.ExotelNumber;
                     } else {
                         console.log('You are not sure');
                     }
                 });

             } //window.open('tel:0' + call, '_system');
             else
                 $rootScope.showAlert('No number to call')
         } else if (item.IsOfflineCall && item.IsPriority) {
             if (item.ExotelNumber != 0) {
                 var confirmPopup = $ionicPopup.confirm({
                     title: 'CureBooth',
                     template: 'You will be charged ' + item.ChargesPerMin + ' credits/min., minimum charges is ' + item.FirstMin + ' credits',
                     cancelText: 'Cancel',
                     okText: 'Call'
                 });

                 confirmPopup.then(function (res) {
                     if (res) {
                         window.location = "tel:0" + item.ExotelNumber;
                     } else {
                         console.log('You are not sure');
                     }
                 });

             } //window.open('tel:0' + call, '_system');
             else
                 $rootScope.showAlert('No number to call')
         } else
             $rootScope.showAlert('Doctor is offline ')
             //window.open('tel:900300400')
     }

     $scope.chat = function (item) {
             $rootScope.chatUser = item //results.get('DoctorProfileObjectId');
                 //console.log($rootScope.chatUser.get('PatientProfileObjectId').get('ProfileImage').url())

         }
         // Call History Funtion
     $scope.callhistory = function () {
         //$ionicLoading.show();
         Parse.Cloud.run('GetCallHistory', {
             UserProfileId: $rootScope.user.ProfileId
         }, {
             success: function (results) {
                 $ionicLoading.hide();
                 for (i = 0; i < results.length; i++) {
                     if ($rootScope.user.ProfileId == results[i].get("ToProfileObjectId").id && $scope.PtDrProfile.DrProfileId == results[i].get("FromProfileObjectId").id) {
                         results[i]['Incoming'] = true
                         $scope.calllist.push(results[i]);
                     } else if ($rootScope.user.ProfileId == results[i].get("FromProfileObjectId").id && $scope.PtDrProfile.DrProfileId == results[i].get("ToProfileObjectId").id) {
                         results[i]['Incoming'] = false
                         $scope.calllist.push(results[i]);
                     }
                 }
             },
             error: function (error) {
                 $ionicLoading.hide();
                 // error
             }
         });
     };
     // is Set Doctor Recommend
     $scope.SetDoctorRecommend = function () {
             //$ionicLoading.show();
             console.log(results.Recommended)
             if (results.Recommended == undefined)
                 $scope.DoctorRecommend = true;
             else
                 $scope.DoctorRecommend = !results.Recommended;

             Parse.Cloud.run('SetDoctorRecommend', {
                 ProfileLinkId: results.ProfileLinkId,
                 IsRecommend: $scope.DoctorRecommend
             }, {
                 success: function (status) {
                     $ionicLoading.hide();
                     $cordovaToast.show('Doctor recommended successfully', 'short', 'center')
                 },
                 error: function (error) {
                     console.log(error)
                     $ionicLoading.hide();
                     $cordovaToast.show(error.message, 'short', 'center')
                         //$rootScope.showAlert(error.message);
                         // debugger;
                         // error
                 }
             });
         }
         //ShareFriendToDoc
     $scope.ShareFriendToDoc = function (phone) {
         Parse.Cloud.run('ShareFriendToDoc', {
             UserProfile: $rootScope.user.ProfileId,
             DoctorProfile: $scope.PtDrProfile.DrProfileId,
             Phone: phone,
             DoctorUserId: $scope.PtDrProfile.ObjectId
         }, {
             success: function (status) {
                 $ionicLoading.hide();
                 $scope.closeRechargeModal();
                 $cordovaToast.show(status, 'short', 'center')
             },
             error: function (error) {
                 console.log(error)
                 $ionicLoading.hide();
                 $cordovaToast.show(error.message, 'short', 'center')
                     //$rootScope.showAlert(error.message);
                     // debugger;
                     // error
             }
         });
     }
     $scope.rechargeAmount = [];
     $scope.showaddmoney = function () {
             $scope.Recharge = true;
             $scope.Rechargebtn = true;
             $scope.openRechargeModal();
             //
         }
         /* $ionicModal.fromTemplateUrl('my-modal.html', {
              scope: $scope,
              animation: 'fade-in-up'
          }).then(function (modal) {
              $scope.MsgModal = modal;
          });*/
     $scope.MsgModal = $ionicModal.fromTemplate('<ion-modal-view class="signup"><ion-header-bar class="bar bar-stable fix-buttons"><button class="button  bar bar-stable" ng-click="closeRechargeModal()" style="max-width: 100px; padding: 5px 10px; min-width: 80px; box-shadow: none;">Cancel</button><h1 class="title">Refer Doctor</h1></ion-header-bar><ion-content><div class="card" style="padding: 5px 10px 0;"><ion-input class="item item-input item-stacked-label"><ion-label>Enter Friend Contact Number</ion-label> <input type="tel" placeholder="Mobile Number" ng-model="rechargeAmount.mobile"  maxlength="10"></ion-input><button ng-disabled="!rechargeAmount.mobile" class="button button-full button-outline button-positive" ng-click="showaddMoneyfn()" style="color: rgb(255, 255, 255); background: rgb(0, 189, 189) none repeat scroll 0% 0%; box-shadow: none;">  Submit</button></div></ion-content></ion-modal-view>', {
         scope: $scope,
         animation: 'slide-in-up'
     });
     $scope.openRechargeModal = function () {
         if ($rootScope.NetworkStatus)
             $scope.MsgModal.show();
         else
             $cordovaToast.show('no connection available', 'short', 'center')

     };
     $scope.closeRechargeModal = function () {
         $scope.MsgModal.hide();
     };
     //Cleanup the modal when we're done with it!
     $scope.$on('$destroy', function () {
         $scope.MsgModal.remove();
     });
     $scope.showaddMoneyfn = function () {
         if ($scope.rechargeAmount.mobile != undefined && $scope.rechargeAmount.mobile != null && $scope.rechargeAmount.mobile.length == 10) {
             $scope.ShareFriendToDoc($scope.rechargeAmount.mobile);
         } else {
             $rootScope.showAlert('Please enter valid mobile number.');
         }
     };
     // is followed
     $scope.SetDoctorFollowed = function (amt) {
         //$ionicLoading.show();
         Parse.Cloud.run('SetDoctorFollowed', {
             DocProfileId: $scope.PtDrProfile.DrProfileId,
             IsFollowed: amt,
             PatProfileId: $rootScope.user.ProfileId
         }, {
             success: function (status) {
                 $ionicLoading.hide();
                 $cordovaToast.show(status, 'short', 'center')
                     //$rootScope.showAlert('Doctor followed Successfully');
                     // te Profile table updated successfully
             },
             error: function (error) {
                 console.log(error)
                 $ionicLoading.hide();
                 $cordovaToast.show(error.message, 'short', 'center')
                     //$rootScope.showAlert(error.message);
                     // debugger;
                     // error
             }
         });
     }

     // list of status
     $scope.getStatusType = function () {
             //$ionicLoading.show();
             var query = new Parse.Query('StatusType');
             query.find({
                 success: function (results) {
                     $ionicLoading.hide();
                     $scope.StatusType = results
                     $scope.getStatus();
                 },
                 error: function (error) {
                     $ionicLoading.hide();
                 }
             });
         }
         // User current status
     $scope.getStatus = function () {
         //$ionicLoading.show();
         var query = new Parse.Query('UserStatus');
         query.equalTo('UserId', results.get('UserObjectId'));
         query.find({
             success: function (data) {
                 if (data.length > 0) {
                     $ionicLoading.hide();
                     $scope.Status.statusType = data[0].get('StatusName');
                 }
             },
             error: function (error) {
                 $ionicLoading.hide();
                 //alert("Error: " + error.code + " " + error.message);
             }
         });
     }
     $scope.ExotelNumber = function () {
             //$ionicLoading.show();
             var query = new Parse.Query('User');
             query.equalTo('objectId', results.get('DoctorProfileObjectId').get('UserObjectId'));
             query.find({
                 success: function (results) {
                     $ionicLoading.hide();
                     if (results.length > 0) {
                         $scope.PtDrProfile.ExotelNumber = results[0].get('ExotelNumber');
                     } else {}
                 },
                 error: function (error) {
                     $ionicLoading.hide();
                     //alert("Error: " + error.code + " " + error.message);
                 }
             });
         }
         //$scope.getStatus();
         //$scope.ExotelNumber();
         //$scope.callhistory();
         //ionicMaterialInk.displayEffect();
     if ($rootScope.NetworkStatus) {
         $scope.ClinicList();
     } else {
         // $scope.setting = $localstorage.getObject('PatientRequestSentList')
     }
 })
 cbApp.controller('PatientSettingCtrl', function ($scope, $state, $ionicLoading, $rootScope, $http, $ionicPopup, $localstorage, $ionicHistory, $localstorage, ionicMaterialInk) {
     $scope.setting = {};
     $scope.getSetting = function (amt) {
         //$ionicLoading.show();
         Parse.Cloud.run('PatientRequestSentList', {
             ProfileId: $rootScope.user.ProfileId
         }, {
             success: function (status) {
                 $ionicLoading.hide();
                 //$scope.setting = status;
                 //$localstorage.setObject('PatientRequestSentList', status)
                 $scope.setting = status // $localstorage.getObject('PatientRequestSentList')
             },
             error: function (error) {
                 console.log(error)
                 $rootScope.handleParseError(error);
                 $ionicLoading.hide();
                 $rootScope.showAlert(error.message);
                 // debugger;
                 // error
             }
         });
     }


     $scope.saveSetting = function () {
         $ionicLoading.show();
         if ($scope.setting.result != null) {
             var point = $scope.setting.result[0];
             point.set("BankName", $scope.setting.BankName);
             point.set("AccountNumber", $scope.setting.AccountNumber);
             point.set("BankCode", $scope.setting.BankCode);
             point.set("UserId", $rootScope.user.id);
             point.set("TimeFee", $scope.setting.TimeFee);
             point.set("Charges", $scope.setting.Charges);
             point.save(null, {
                 success: function (point) {
                     $ionicLoading.hide();
                 },
                 error: function (point, error) {
                     $ionicLoading.hide();
                 }
             });
         } else {

             var Point = Parse.Object.extend("DocAccountSetting");
             var point = new Point();
             point.set("BankName", $scope.setting.BankName);
             point.set("AccountNumber", $scope.setting.AccountNumber);
             point.set("BankCode", $scope.setting.BankCode);
             point.set("UserId", $rootScope.user.id);
             point.set("TimeFee", $scope.setting.TimeFee);
             point.set("Charges", $scope.setting.Charges);
             point.set("Amount", $scope.setting.Amount);
             point.save(null, {
                 success: function (point) {
                     $ionicLoading.hide();

                     // Saved successfully.
                 },
                 error: function (point, error) {
                     $ionicLoading.hide();
                     // The save failed.
                     // error is a Parse.Error with an error code and description.
                 }
             });
         }
     }
     $scope.changePassword = false;
     $scope.changePass = function (param) {
         $scope.changePassword = param;
     }
     $scope.changePasword = [];
     $scope.UpdatePassword = function () {
         if (typeof $scope.changePasword.Password === 'undefined' || $scope.changePasword.Password === null) {
             $rootScope.showAlert("Please enter current password");
             return false;
         } else if (typeof $scope.changePasword.NewPassword === 'undefined' || $scope.changePasword.NewPassword === null) {
             $rootScope.showAlert("Please enter new password");
             return false;
         } else if (typeof $scope.changePasword.cNewPassword === 'undefined' || $scope.changePasword.cNewPassword === null) {
             $rootScope.showAlert("Please enter confirm new password");
             return false;
         } else if ($scope.changePasword.NewPassword != $scope.changePasword.cNewPassword) {
             $rootScope.showAlert("Please enter same new password and confirm new password");
             return false;
         } else if ($scope.changePasword.Password == $scope.changePasword.cNewPassword) {
             $rootScope.showAlert("Please enter same new password and confirm new password");
             return false;
         } else {
             var confirmPopup = $ionicPopup.confirm({
                 title: 'CureBooth',
                 template: 'Are you sure ! <br/> You want to change your password?'
             });

             confirmPopup.then(function (res) {
                 if (res) {
                     $ionicLoading.show();
                     Parse.Cloud.run('UpdatePassword', {
                         //username: $scope.Profile.get('Phone'),
                         oldPassword: $scope.changePasword.Password,
                         newPassword: $scope.changePasword.NewPassword
                     }, {
                         success: function (results) {
                             $ionicLoading.hide();
                             $scope.changePassword = false;
                             var alertPopup = $ionicPopup.alert({
                                 title: 'CureBooth',
                                 cssClass: 'balance',
                                 template: 'Password changed successfully !<br> Please login again'
                             });
                             alertPopup.then(function (res) {
                                 $scope.getSetting()
                                     //$state.go('login');
                             });
                         },
                         error: function (error) {
                             console.log(error)
                             $ionicLoading.hide();
                             $rootScope.showAlert(error.message);
                         }
                     });
                 }
             });
         }

     };
     $scope.logOutfn = function () {
         $ionicLoading.show();
         Parse.User.logOut()
         var currentUser = Parse.User.current();
         console.log('CurrentUser : ' + currentUser)
         if (currentUser) {
             $rootScope.user = currentUser;
             $rootScope.isLoggedIn = true;
             $state.go('tab.Home');
         } else {
             $localstorage.clearAll();
             $ionicHistory.clearCache();
             $ionicHistory.clearHistory()
             $ionicLoading.hide();
             $rootScope.isDoctor = '';
             window.localStorage['isDoctor'] = '';
             $rootScope.isPatient = '';
             window.localStorage['isPatient'] = '';
             $state.go("login");
             navigator.app.exitApp();

         }
     };
     $scope.GetShareMsg = function () {
         //$ionicLoading.show();
         Parse.Cloud.run('GetShareMsg', {
             //UserObjectId: $rootScope.user.id,
         }, {
             success: function (results) {
                 $ionicLoading.hide();
                 $scope.GetShareMsgdata = results;
                 console.log($scope.GetShareMsgdata[0])
                 console.log($scope.GetShareMsgdata[1])
             },
             error: function (error) {
                 $ionicLoading.hide();
             }
         });
     }
     $scope.shareApp = function () {
             var options = {
                 message: 'share this', // not supported on some apps (Facebook, Instagram)
                 subject: 'the subject', // fi. for email
                 files: ['', ''], // an array of filenames either locally or remotely
                 url: 'https://www.website.com/foo/#bar?a=b',
                 chooserTitle: 'Pick an app' // Android only, you can override the default share sheet title
             }

             /*var onSuccess = function (result) {
                 console.log("Share completed? " + result.completed); // On Android apps mostly return false even while it's true
                 console.log("Shared to app: " + result.app); // On Android result.app is currently empty. On iOS it's empty when sharing is cancelled (result.completed=false)
             }

             var onError = function (msg) {
                 console.log("Sharing failed with message: " + msg);
             }

             window.plugins.socialsharing.share(options, onSuccess, onError);*/
             //window.plugins.socialsharing.share($scope.GetShareMsgdata[0], 'https://www.google.nl/images/srpr/logo4w.png', $scope.GetShareMsgdata[1]);
             window.plugins.socialsharing.share($scope.GetShareMsgdata[0], 'CureBooth', null, $scope.GetShareMsgdata[1])
         }
         // Intialize the controller 
     if ($rootScope.NetworkStatus) {
         //$scope.setting = $localstorage.getObject('PatientRequestSentList')
         $scope.getSetting();
         $scope.GetShareMsg();
     } else {
         // $scope.setting = $localstorage.getObject('PatientRequestSentList')
     }
     //ionicMaterialInk.displayEffect();
 });