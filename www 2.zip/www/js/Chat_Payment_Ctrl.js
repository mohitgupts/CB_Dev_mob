//Chat Controller
cbApp.controller('ThreadDetailCtrl', function ($rootScope, $scope, $stateParams, ParseService, $location, $ionicLoading, PusherTrigger, Pusher, $ionicScrollDelegate, $cordovaCamera, $ionicPopover, $ionicSlideBoxDelegate, $cordovaDevice, $timeout, $ionicPlatform, $ionicModal, $cordovaFileTransfer, $localstorage, $cordovaToast, UtilFunctions, ionicMaterialInk) {

    var tabs = document.querySelectorAll('div.tabs')[0];
    tabs = angular.element(tabs);
    tabs.css('display', 'none');

    $scope.$on('$destroy', function () {
        console.log('HideCtrl destroy');
        tabs.css('display', '');
    });

    $scope.messages = [];
    var threadId = $stateParams.threadId;
    $scope.userId = $stateParams.targetId;
    $scope.user.id = $rootScope.UserProfile.UserObjectId

    var _isCurrentlyTyping = false;
    var _hasSentTypingMessage = false;
    var _hasSentStopMessage = false;
    var searchTimeout;

    //$scope.messages = new Array();
    $scope.isMute = $rootScope.chatUser.isMute
    $scope.isFriendFn = function () {
        if ($rootScope.isDoctor == 'true') {
            $scope.DocProfileObjectId = $rootScope.user.ProfileId
            $scope.PatientProfileObjectId = $rootScope.chatUser.id
        } else {
            $scope.DocProfileObjectId = $rootScope.chatUser.id
            $scope.PatientProfileObjectId = $rootScope.user.ProfileId
        }
        Parse.Cloud.run('IsFriend', {
            DocProfileObjectId: $scope.DocProfileObjectId,
            PatientProfileObjectId: $scope.PatientProfileObjectId
        }, {
            success: function (result) {
                if (result.get('DoctorAction').get('actionName') == "Approved") {
                    if ($rootScope.isDoctor == 'true') {
                        $scope.isMute = result.get('DoctorMuted');
                    } else
                        $scope.isMute = result.get('PatientMuted');
                }
                $scope.$apply();
            },
            error: function (error) {}
        });
    }
    $scope.isFriendFn();
    // Mute Chat
    $scope.SetChatMute = function (amt) {
        if (!$rootScope.NetworkStatus) {
            $cordovaToast.show('no connection available', 'short', 'center')
        } else {
            //$ionicLoading.show();
            Parse.Cloud.run('SetChatMute', {
                //DocProfileId: $rootScope.user.ProfileId,
                IsMute: amt,
                ProfileLinkId: $rootScope.chatUser.ProfileLinkId
            }, {
                success: function (status) {
                    $ionicLoading.hide();
                    var msg = '';
                    /* if (status.get('IsArchive')) {
                         msg = 'Patient Blocked Successfully '
                     } else {
                         msg = 'Patient Unblocked Successfully '
                     }*/
                    $cordovaToast.show(msg, 'short', 'center')
                        .then(function (success) {
                            // success
                        }, function (error) {
                            // error
                        });
                    // $rootScope.showAlert('patient priority updated');
                    // te Profile table updated successfully
                },
                error: function (error) {
                    console.log(error)
                    $ionicLoading.hide();
                    //$rootScope.showAlert(error.message);
                    // debugger;
                    // error
                }
            });
        }
    }
    $scope.gotScrolled = function () {
        if (cordova.plugins.Keyboard.isVisible) {
            cordova.plugins.Keyboard.close();
        }
    }
    $scope.$on('$ionicView.beforeLeave', function () {
        console.log('$ionicView.beforeLeave')
        Pusher.unsubscribe(threadId);
        //pusher.unsubscribe(threadId);
    });
    console.log('Pusher.subscribe fn');
    $scope.NewMsg = false;
    $scope.subscribe = function () {
        Pusher.subscribe(threadId, 'new_message', function (item) {
            console.log('Pusher.subscribe')
                // an item was updated. find it in our list and update it.
            ParseService.currentUser(
                function win(currentUser) {
                    console.log('Pusher.currentUser');
                    if (angular.element(document.querySelector("#message_" + item.message_id)).length == 0) {
                        console.log('Pusher.currentUser sucess function')
                        console.log(item);
                        var newObj = {
                            "message": item.message,
                            "eventPush": item.eventPush,
                            "user": {
                                //"attributes": {
                                "objectId": item.user.objectId
                                    // }
                            }
                        }

                        $scope.NewMsg = true;
                        //console.log(newObj);
                        //console.log($scope.messages);
                        $localstorage.setObject('NewChatMessages', newObj);
                        $scope.messages.pop();
                        //console.log($localstorage.getObject('NewChatMessages'))
                        $scope.messages.push($localstorage.getObject('NewChatMessages'));
                        $localstorage.setObject('ChatMessages', $scope.messages);
                        $scope.messages = $localstorage.getObject('ChatMessages');
                        $scope.$apply();
                        $ionicScrollDelegate.scrollBottom();
                    }
                }
            );
            console.log("NEW MESSAGE");
        });
        Pusher.subscribe(threadId, 'new_media', function (item) {
            console.log('Pusher.subscribe')
                // an item was updated. find it in our list and update it.
            ParseService.currentUser(
                function win(currentUser) {
                    console.log('Pusher.currentUser');
                    if (angular.element(document.querySelector("#message_" + item.message_id)).length == 0) {
                        console.log('Pusher.currentUser sucess function')
                        console.log(item);
                        var newObj = {
                            //"createdAt": item.message_payload.createdAt,
                            //"attributes": {
                            "message": '*media#',
                            "ChatMedia": {
                                //"attributes": {
                                "url": item.message
                                    // }
                            },
                            "eventPush": item.eventPush,
                            "user": {
                                //"attributes": {
                                "objectId": item.user.objectId
                                    // }
                            }
                            // }
                        }

                        $scope.NewMsg = true;
                        //console.log(newObj);
                        $localstorage.setObject('NewChatMessages', newObj);
                        // console.log($localstorage.getObject('NewChatMessages'))
                        //$scope.messages.pop();
                        $scope.messages.push($localstorage.getObject('NewChatMessages'));
                        $localstorage.setObject('ChatMessages', $scope.messages);
                        $scope.messages = $localstorage.getObject('ChatMessages');
                        $scope.$apply();
                        $ionicScrollDelegate.scrollBottom();
                    }
                }
            );
            //console.log("NEW MESSAGE");
        });
    }
    $scope.friend = [];
    $scope.friend.ProfileImage = $rootScope.chatUser.ProfileImage;
    /* if ($rootScope.chatUser.get('ProfileImage') != undefined) {
         $scope.friend.ProfileImage = $rootScope.chatUser.get('ProfileImage').url();
     } else {
         if ($rootScope.isDoctor == 'true')
             $scope.friend.ProfileImage = "img/doctor_icon_default.png";
         else
             $scope.friend.ProfileImage = "img/patient_icon_default.png";
     }*/
    $scope.friend.name = $rootScope.chatUser.FullName;
    //$scope.friend.name = $rootScope.chatUser.get('FullName');
    //$scope.profile =
    $scope.createdAt = null;
    $scope.chatHistory = function () {
        $ionicLoading.show({
            /*template: 'Loading Thread...'*/
        });

        if ($scope.messages.length > 0) {
            var l = $scope.messages.length
            $scope.createdAt = $scope.messages[l - 1].createdAt;
        }
        ParseService.getThread({
                "thread_id": threadId,
                "createdAt": $scope.createdAt
            },
            function results(res) {
                $ionicLoading.hide();
                if (res.length == 0) {
                    //$scope.messages = [];
                } else {
                    $scope.NewMsg = false;
                    for (i = 0; i < res.length; i++) {
                        //console.log(res[i].attributes.user.id)
                        res[i].attributes.user.set("USERID", res[i].attributes.user.id); //.attributes.USERID = res[i].attributes.user.id;
                        //res[i].attributes.eventPush = 'undefined';
                        //console.log('USERID: '+res[i].attributes.user.attributes.USERID)
                    }
                    //console.log(res)
                    if ($scope.messages.length == 0)
                        $scope.messages = res;
                    else
                        for (i = 0; i < res.length; i++)
                            $scope.messages.push(res[i]);

                    $localstorage.setObject(threadId, $scope.messages);
                    $scope.messages = $localstorage.getObject(threadId);
                }
                $ionicScrollDelegate.scrollBottom();
            },
            function fail(error) {
                $ionicLoading.hide();
                console.log(error);
            }
        )
    };

    $scope.doRefresh = function () {
        if (!$rootScope.NetworkStatus) {
            $cordovaToast.show('no connection available', 'short', 'center')
        } else {
            $ionicLoading.show();
            var skip = $scope.messages.length;
            console.log(skip)
            ParseService.getThread({
                    "thread_id": threadId,
                    "offset": skip
                },
                function results(res) {
                    $ionicLoading.hide();
                    if (res.length == 0) {

                    } else {
                        $scope.NewMsg = false;
                        for (i = 0; i < res.length; i++) {
                            res[i].attributes.user.set("USERID", res[i].attributes.user.id);
                        }
                        if ($scope.messages.length == 0)
                            $scope.messages = res;
                        else
                            for (i = 0; i < res.length; i++)
                                $scope.messages.unshift(res[i]);

                        $localstorage.setObject(threadId, $scope.messages);
                        $scope.messages = $localstorage.getObject(threadId);
                        /*console.log($scope.messages);
                        for (i = 0; i < res.length; i++) {
                            $scope.messages.unshift(res[i]);
                        }

                        console.log($scope.messages);*/
                    }

                    $scope.$broadcast('scroll.refreshComplete');
                },
                function fail(error) {
                    $ionicLoading.hide();
                    $scope.$broadcast('scroll.refreshComplete');
                }
            );
        }
    }

    // Upload Image
    $scope.saveImg = function (imageData) {
        $ionicLoading.show();
        ParseService.currentUser(
            function win(currentUser) {
                var Messages = Parse.Object.extend("Messages");
                var message = new Messages();
                message.set("message", "*media#");
                message.set("user", currentUser);
                message.set("thread_id", threadId)
                message.set("ToUser", $scope.userId)
                message.set("FromUserName", $rootScope.UserProfile.FullName)
                if ($scope.imageData != "") {
                    var parseFile = new Parse.File("chatImg.jpg", {
                        base64: imageData
                    });
                    message.set("ChatMedia", parseFile);
                    console.log('create profile link');
                    message.save(null, {
                        success: function (data) {
                            console.log(data)
                            var img = (data.get('ChatMedia') != undefined) ? data.get('ChatMedia').url() : '*media#';
                            var newObj = {
                                "message": '*media#',
                                "ChatMedia": {
                                    "url": data.get('ChatMedia').url()
                                },
                                "eventPush": "new_media",
                                "user": {
                                    "objectId": $rootScope.user.id
                                }
                                // }
                            }
                            $localstorage.setObject('NewChatMessages', newObj);
                            console.log($localstorage.getObject('NewChatMessages'))
                            $scope.messages.push($localstorage.getObject('NewChatMessages'));
                            $localstorage.setObject('ChatMessages', $scope.messages);
                            $scope.messages = $localstorage.getObject('ChatMessages');
                            //$scope.messages.push(results);
                            var obj = {
                                url: "http://default-environment.2dmee9yyxr.ap-southeast-1.elasticbeanstalk.com/gage/PushChat",
                                data: {
                                    "message": img,
                                    "messagea_id": data.id,
                                    "eventPush": "new_media",
                                    "channel": threadId,
                                    "userId": $rootScope.user.id
                                },
                                method: "POST"
                            };
                            console.log(obj);

                            PusherTrigger.triggerEvent(obj,
                                function results(res, status) {
                                    //content.text = null;
                                    console.log("-- Good ---");
                                    console.log(res)
                                },
                                function fail(res, status) {
                                    console.log('Fail');
                                    console.log(res);
                                }
                            )

                            setTimeout(function () {
                                $ionicScrollDelegate.scrollBottom();
                                //content.text = null;
                                document.querySelector("#commentBox").value = "";
                                $scope.$apply();
                            }, 100)
                            $ionicLoading.hide();
                        },
                        error: function (employee, error) {
                            $ionicLoading.hide();
                            //alert('error:' + error.message.toString());
                        }
                    });
                }
            },
            function fail(error) {
                console.log('fail on currentuser');
            }
        )
    }

    document.addEventListener("deviceready", function () {
        $scope.attachMedia = function (data) {
            console.log(data)
            if (data == 1)
                $scope.cemera();
            else
                $scope.gallery();
        }
    }, false);
    $scope.cemera = function () {
        var options = {
            quality: 65,
            destinationType: Camera.DestinationType.DATA_URL,
            sourceType: Camera.PictureSourceType.CAMERA,
            //allowEdit: true,
            encodingType: Camera.EncodingType.JPEG,
            //targetWidth: 100,
            //targetHeight: 100,
            popoverOptions: CameraPopoverOptions,
            saveToPhotoAlbum: false,
            correctOrientation: true
        };

        $cordovaCamera.getPicture(options).then(function (imageData) {
            //$scope.imageData = imageData;
            $scope.saveImg(imageData);
            //$scope.ProfileImage = "data:image/jpeg;base64," + imageData;
        }, function (err) {
            // error
        });

    }
    $scope.gallery = function () {
            var options = {
                quality: 65,
                destinationType: Camera.DestinationType.DATA_URL,
                sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
                //allowEdit: true,
                encodingType: Camera.EncodingType.JPEG,
                //targetWidth: 100,
                //targetHeight: 100,
                popoverOptions: CameraPopoverOptions,
                saveToPhotoAlbum: false,
                correctOrientation: true
            };

            $cordovaCamera.getPicture(options).then(function (imageData) {
                $scope.saveImg(imageData);
            }, function (err) {
                // error
            });

        }
        //}

    // Download media

    $scope.mediaDownloadIcon = true;
    $scope.mediaDownload = function (id, imgid) {
        $ionicPlatform.ready(function () {
            if ($cordovaDevice.getPlatform() == 'iOS') {
                fileDeviceDir = cordova.file.dataDirectory;
            } else {
                fileDeviceDir = cordova.file.externalRootDirectory;
            }
        });
        console.log(id)
        document.getElementById('DchatMedia' + imgid).style.display = 'none';
        document.getElementById('PDchatMedia' + imgid).style.display = 'block';
        console.log(id.ChatMedia.url)
            //$ionicLoading.show();
        console.log('getSetting')
            // download(id.ChatMedia.url, "HBChat", id.ChatMedia.name

        var fileTransfer = new FileTransfer();
        var uri = encodeURI(id.ChatMedia.url);
        var fileURL = fileDeviceDir + id.ChatMedia.name;
        var targetPath = fileDeviceDir + id.ChatMedia.name;
        window.resolveLocalFileSystemURL(fileURL, console.log('yes'), console.log('not'));
        $cordovaFileTransfer.download(uri, targetPath, {}, true)
            .then(
                function (entry) {
                    $scope.mediaDownloadIcon = false;
                    document.getElementById('PDchatMedia' + imgid).style.display = 'none';
                    //document.getElementById('chatMedia' + imgid).style.display = 'block';
                    //document.getElementById('chatMedia' + imgid).src = entry.toURL();
                    $scope.messages[imgid].ChatMedia.localurl = entry.toURL()
                    $localstorage.setObject(threadId, $scope.messages);
                    $scope.messages = $localstorage.getObject(threadId);
                    console.log(JSON.stringify($scope.messages[imgid]))
                    $scope.$apply();
                },
                function (err) {
                    console.log('File Download error: ', err);
                },
                function (progress) {
                    $timeout(function () {
                        var percentComplete = (progress.loaded / progress.total) * 100;
                        $scope.percentComplete = Math.round(percentComplete);
                        /*$ionicLoading.show({
                            template:  $scope.percentComplete
                        });*/
                        if (Math.round(percentComplete) === 100)
                            $scope.percentComplete = 0;
                        $ionicLoading.hide();
                        console.log("[File Download -progress- percentComplete =" + percentComplete);
                    })
                });
        /*       fileTransfer.download(
                   uri,
                   fileURL,
                   function (entry) {
                       $scope.mediaDownloadIcon = false;
                       document.getElementById('DchatMedia' + imgid).style.display = 'none';
                       //document.getElementById('chatMedia' + imgid).style.display = 'block';
                       //document.getElementById('chatMedia' + imgid).src = entry.toURL();
                       $scope.messages[imgid].ChatMedia.localurl = entry.toURL()
                       $localstorage.setObject(threadId, $scope.messages);
                       $scope.messages = $localstorage.getObject(threadId);
                       console.log(JSON.stringify($scope.messages[imgid]))
                       $scope.$apply();
                   },
                   function (error) {
                       console.log("download error source " + error.source);
                       console.log("download error target " + error.target);
                       console.log("upload error code" + error.code);
                   },
                   false, {
                       headers: {
                           "Authorization": "Basic dGVzdHVzZXJuYW1lOnRlc3RwYXNzd29yZA=="
                       }
                   }
               );*/
        /*       var query = new Parse.Query('Messages');
               query.equalTo("thread_id", threadId);
               query.equalTo("objectId", id);
               query.find({
                   success: function (results) {
                       $ionicLoading.hide();
                       if (results.length > 0) {
                           $scope.mediaDownloadIcon = false;
                           document.getElementById('DchatMedia' + imgid).style.display = 'none';
                           document.getElementById('chatMedia' + imgid).style.display = 'block';
                           document.getElementById('chatMedia' + imgid).src = results[0].get('ChatMedia').url();
                   
                       } else {
                           //$scope.setting.result = null;
                       }
                   },
                   error: function (error) {
                       $ionicLoading.hide();

                       //alert("Error: " + error.code + " " + error.message);
                   }
               });*/

    }

    function download(URL, Folder_Name, File_Name) {
        //step to request a file system 
        window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, fileSystemSuccess, fileSystemFail);

        function fileSystemSuccess(fileSystem) {
            var download_link = encodeURI(URL);
            ext = download_link.substr(download_link.lastIndexOf('.') + 1); //Get extension of URL

            var directoryEntry = fileSystem.root; // to get root path of directory
            directoryEntry.getDirectory(Folder_Name, {
                create: true,
                exclusive: false
            }, onDirectorySuccess, onDirectoryFail); // creating folder in sdcard
            var rootdir = fileSystem.root;
            var fp = rootdir.fullPath; // Returns Fulpath of local directory

            fp = fp + "/" + Folder_Name + "/" + File_Name //+ "." + ext; // fullpath and name of the file which we want to give
                // download function call
            filetransfer(download_link, fp);
        }

        function onDirectorySuccess(parent) {
            // Directory created successfuly
        }

        function onDirectoryFail(error) {
            //Error while creating directory
            alert("Unable to create new directory: " + error.code);
        }

        function fileSystemFail(evt) {
            //Unable to access file system
            alert(evt.target.error.code);
        }
    }

    function filetransfer(download_link, fp) {
        var fileTransfer = new FileTransfer();
        // File download function with URL and local path
        fileTransfer.download(download_link, cordova.file.dataDirectory + id.ChatMedia.name,
            function (entry) {
                alert("download complete: " + entry.fullPath);
            },
            function (error) {
                //Download abort errors or download failed errors
                alert("download error source " + error.source);
                //alert("download error target " + error.target);
                //alert("upload error code" + error.code);
            }
        );
    }

    var template = '<ion-popover-view class="chatMedia"><ion-content style="padding:12px"> <i ng-click="attachMedia(1)" class="icon ion-ios-camera attachIcons"></i> <i ng-click="attachMedia(0)" class="icon ion-images attachIcons"></i></ion-content></ion-popover-view>';

    $scope.popover = $ionicPopover.fromTemplate(template, {
        scope: $scope
    });
    $scope.openPopover = function ($event) {
        if (!$rootScope.NetworkStatus) {
            $cordovaToast.show('no connection available', 'short', 'center')
        } else {
            $scope.popover.show($event);
        }
    };
    $scope.closePopover = function () {
        $scope.popover.hide();
    };
    //Cleanup the popover when we're done with it!
    $scope.$on('$destroy', function () {
        $scope.popover.remove();
    });

    $ionicModal.fromTemplateUrl('image-modal.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.modal = modal;
    });
    $scope.oImage = []
    $scope.zoomimng = function (id) {
        $scope.oImage.src = document.getElementById('chatMedia' + id).src;
        $ionicSlideBoxDelegate.slide(0);
        $scope.modal.show();
    };

    $scope.closeModal = function () {
        $scope.modal.hide();
    };

    // Cleanup the modal when we're done with it!
    $scope.$on('$destroy', function () {
        $scope.modal.remove();
    });
    $scope.saveMessage = function (content) {
            /*$ionicLoading.show({
                template: '...'
            });*/

            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {

                if (content.text != null) {
                    $ionicLoading.show();
                    ParseService.currentUser(
                        function win(currentUser) {
                            console.log(currentUser)
                            var newObj = {
                                "message": content.text,
                                //"eventPush": item.eventPush,
                                "user": {
                                    //"attributes": {
                                    "objectId": currentUser.id
                                        // }
                                }
                            }
                            $localstorage.setObject('NewChatMessages', newObj);
                            console.log($localstorage.getObject('NewChatMessages'))
                            $scope.messages.push($localstorage.getObject('NewChatMessages'));
                            $localstorage.setObject('ChatMessages', $scope.messages);
                            $scope.messages = $localstorage.getObject('ChatMessages');
                            //$scope.$apply();
                            var messageObj = {
                                "thread_id": threadId,
                                "user": currentUser,
                                "message": content.text,
                                "ToUser": $scope.userId,
                                "FromUser": $rootScope.UserProfile.FullName
                            }

                            console.log(messageObj);

                            ParseService.postMessage(messageObj,
                                function successPost(results) {
                                    $ionicLoading.hide();
                                    console.log(results);
                                    //$scope.messages.push(results);
                                    var obj = {
                                        url: "http://default-environment.2dmee9yyxr.ap-southeast-1.elasticbeanstalk.com/gage/PushChat",
                                        data: {
                                            "message": content.text,
                                            "messagea_id": results.id,
                                            "eventPush": "new_message",
                                            "channel": threadId,
                                            "userId": $rootScope.user.id
                                        },
                                        method: "POST"
                                    };
                                    console.log(obj);

                                    PusherTrigger.triggerEvent(obj,
                                        function results(res, status) {
                                            content.text = null;
                                            console.log("-- Good ---");
                                            console.log(res)
                                        },
                                        function fail(res, status) {
                                            console.log('Fail');
                                            console.log(res);
                                        }
                                    )

                                    setTimeout(function () {
                                        $ionicScrollDelegate.scrollBottom();
                                        content.text = null;
                                        document.querySelector("#commentBox").value = "";
                                        $scope.$apply();
                                    }, 100)


                                },
                                function errorPost(error) {
                                    content.text = null;
                                    $ionicLoading.hide();
                                    $scope.messages.pop();
                                    console.log('error post');
                                    var obj = {
                                        title: "Oh no!",
                                        template: "We were unable to post your comment. Please try again."
                                    };

                                    UtilFunctions.setAlert(obj);
                                }
                            )
                        },
                        function fail(error) {
                            $ionicLoading.hide();
                            console.log('fail on currentuser');
                        }
                    )
                }
            }
        }
        // Intialize the controller 
    if ($rootScope.NetworkStatus) {
        if ($localstorage.get(threadId) == undefined)
            $scope.messages = []
        else
            $scope.messages = $localstorage.getObject(threadId);
        console.log($scope.messages)
        $ionicScrollDelegate.scrollBottom();
        $scope.subscribe();
        $scope.chatHistory();
    } else {
        $scope.messages = $localstorage.getObject(threadId);
        $ionicScrollDelegate.scrollBottom();
    }
    //ionicMaterialInk.displayEffect();
});

// Payment controller
cbApp.controller('ReceivableCtrl', function ($scope, $http, $state, $ionicPopup, $ionicLoading, $rootScope, $http, $ionicModal, $timeout, $localstorage, ionicMaterialInk, $cordovaToast) {
    $scope.setting = [];
    //GetShareMsg

    $scope.getReceivable = function () {
        if ($localstorage.getObject('WalletBalance') === null) {} //$ionicLoading.show();
        var query = new Parse.Query('Wallet');
        query.equalTo('UserObjectId', $rootScope.user.id);
        query.find({
            success: function (results) {
                $ionicLoading.hide();
                //$scope.setting.Revenue = results[0].get('Amount');
                $localstorage.setObject('WalletBalance', results[0].get('Amount'));
                $scope.setting.Revenue = $localstorage.getObject('WalletBalance');
                $scope.$apply();
            },
            error: function (error) {
                $ionicLoading.hide();
                //alert("Error: " + error.code + " " + error.message);
            }
        });
    }
    var myVar;
    $scope.payment = function () {
        //$scope.paymetHistory("qw49501894647")
        if (!$rootScope.NetworkStatus) {
            $cordovaToast.show('no connection available', 'long', 'center')
        } else {
            var txnid = "qw" + Math.floor(Math.random() * 100000000000);
            key = "cSozgo" //"0EcShr1i"//
            salt = "8QHHmL7C" //"aDLdm1csq3"
            var payu_params = {};
            var UserProfile = $rootScope.UserProfile;
            payu_params.key = key //checkEmptyValue(key);
            payu_params.txnid = txnid //checkEmptyValue(txnid);
            payu_params.amount = $scope.user.money //checkEmptyValue($scope.user.money);
            payu_params.productinfo = 'Add Maney to Wallet' //checkEmptyValue('Add Manoy to Wallet');
            payu_params.firstname = UserProfile.FullName //checkEmptyValue(UserProfile[0].get("FirstName"));
            payu_params.email = UserProfile.UserPointer.email //checkEmptyValue(UserProfile[0].get("Email"));
            payu_params.user_credentials = "cSozgo:unique_id" //checkEmptyValue("0MQaQP:unique_id");
            payu_params.phone = UserProfile.Phone //checkEmptyValue(" ");
            payu_params.udf1 = $rootScope.user.id //checkEmptyValue(" ");
            payu_params.udf2 = "" //checkEmptyValue(" ");
            payu_params.udf3 = "" //checkEmptyValue(" ");
            payu_params.udf4 = "" //checkEmptyValue(" ");
            payu_params.udf5 = "" //checkEmptyValue(" ");
            payu_params.offer_key = "" //checkEmptyValue(" ");
            payu_params.card_bin = ""
            payu_params.surl = encodeURI("https://www.payumoney.com/mobileapp/payumoney/success.php"); // url needs to be encoded
            payu_params.furl = encodeURI("https://www.payumoney.com/mobileapp/payumoney/failure.php"); // url needs to be encoded
            function checkEmptyValue(str) {
                var value = str //.trim();
                if (value.length == 0 || value == null || value == 'undefined' || value == "") {
                    return "";
                } else {
                    return value;
                }
            }
            var hash_string = payu_params.key + "|" + payu_params.txnid + "|" + payu_params.amount + "|" +
                payu_params.productinfo + "|" + payu_params.firstname + "|" +
                payu_params.email + "|" + payu_params.udf1 + "|" + payu_params.udf2 + "|" +
                payu_params.udf3 + "|" + payu_params.udf4 + "|" + payu_params.udf5 + "||||||8QHHmL7C";
            payu_params.hash = CryptoJS.SHA512(hash_string).toString(CryptoJS.enc.Base64);
            payu_params.service_provider = "payu_paisa";
            console.log("Hash = " + payu_params.hash);
            console.log(payu_params);
            var payu_params_string = '';
            for (var key in payu_params) {
                payu_params_string += key + "=" + payu_params[key] + "&";
            }

            // trim last character (&)
            payu_params_string = payu_params_string.slice(0, -1);


            var browserWindow = window.open('http://default-environment.2dmee9yyxr.ap-southeast-1.elasticbeanstalk.com/cbpayment.html', '_blank', 'location=no,hidden=yes,hardwareback=no');
            var transitionLoaded = false;
            var finalURL = 'https://secure.payu.in/_payment';
            var paramName = 'key';
            var paramValue = 'cSozgo';

            function injectForm() {
                console.log(payu_params.key)
                console.log(payu_params.firstname)
                console.log(payu_params.email)
                console.log(payu_params.hash)
                browserWindow.executeScript({
                    code: "var formdata;formdata = $(document.createElement('form')).css({ display: 'none'}).attr('method', 'POST').attr('action', '" + finalURL + "');$('body').append(formdata);var inputfld = $(document.createElement('input')).attr('name', '" + paramName + "').val('" + paramValue + "');formdata.append(inputfld);var inputfld1 = $(document.createElement('input')).attr('name', 'txnid').val('" + payu_params.txnid + "');formdata.append(inputfld1);var inputfld2 = $(document.createElement('input')).attr('name', 'amount').val('" + payu_params.amount + "');formdata.append(inputfld2);var inputfld3 = $(document.createElement('input')).attr('name', 'productinfo').val('" + payu_params.productinfo + "');formdata.append(inputfld3);var inputfld4 = $(document.createElement('input')).attr('name', 'firstname').val('" + payu_params.firstname + "');formdata.append(inputfld4);var inputfld5 = $(document.createElement('input')).attr('name', 'email').val('" + payu_params.email + "');formdata.append(inputfld5);var inputfld6 = $(document.createElement('input')).attr('name', 'user_credentials').val('" + payu_params.user_credentials + "');formdata.append(inputfld6);var inputfld7 = $(document.createElement('input')).attr('name', 'phone').val('" + payu_params.phone + "');formdata.append(inputfld7);var inputfld8 = $(document.createElement('input')).attr('name', 'udf1').val('" + payu_params.udf1 + "');formdata.append(inputfld8);var inputfld9 = $(document.createElement('input')).attr('name', 'surl').val('" + payu_params.surl + "');formdata.append(inputfld9);var inputfld10 = $(document.createElement('input')).attr('name', 'furl').val('" + payu_params.furl + "');formdata.append(inputfld10);var inputfld11 = $(document.createElement('input')).attr('name', 'hash').val('" + payu_params.hash + "');formdata.append(inputfld11);var inputfld12 = $(document.createElement('input')).attr('name', 'service_provider').val('" + payu_params.service_provider + "');formdata.append(inputfld12);formdata.submit();"

                }, function (e) {
                    console.log(e)
                    console.log('Form injected')
                    transitionLoaded = true;
                });
            }
            browserWindow.addEventListener('loadstop', function (event) {
                if (event.url.indexOf('http://default-environment.2dmee9yyxr.ap-southeast-1.elasticbeanstalk.com/cbpayment.html') !== -1 && !transitionLoaded) {
                    console.log('Form injected hehehehehehe')
                    injectForm();
                }
                var sucess = "payumoney/success.php"
                var fail = "payumoney/failure.php"
                console.log(event.url.indexOf(sucess) + '...' + event.url.indexOf(fail))
                if (event.url.indexOf(sucess) > -1 || event.url.indexOf(fail) > -1) {
                    $scope.paymetHistory(txnid)
                    $scope.user.money = '';
                    $scope.closeProfileModal();
                    $scope.GetTransactionHistory();
                    browserWindow.close();
                }

            });

            browserWindow.show();


            //postForm.CDATA_SECTION_NODE(payu_params_string)
            /*   var bodyTag = document.getElementsByTagName('body')[0];
               bodyTag.appendChild(postForm);
               postForm.submit();
               var myiframe = document.getElementById('myiframe');
               myiframe.onreadystatechange = function () {
                       console.log(this.contentWindow.location.href)
                       if (myiframe.readyState == 'complete') {
                           $ionicLoading.hide();
                       }
                   }
               
               $timeout(function () {
                   $ionicLoading.hide();
                   //console.log('current Url of Iframe')
                   console.log(document.getElementById("myiframe").contentWindow.location.href);
               }, 3000);
               myVar = window.setInterval(function () {
                   console.log('current Url of Iframe')
                   console.log(document.getElementById("myiframe").contentWindow.location.href);
                   var string = document.getElementById("myiframe").contentWindow.location.href;
                   var sucess = "payumoney/success.php"
                   var fail = "payumoney/failure.php"
                   console.log(string.indexOf(sucess) + '...' + string.indexOf(fail))
                   if (string.indexOf(sucess) > -1 || string.indexOf(fail) > -1) {
                       $scope.paymetHistory(txnid)
                       clearInterval(myVar);
                       $timeout(function () {
                           $scope.closeProfileModal();
                           $scope.GetTransactionHistory();
                       }, 5000);

                   }
               }, 2000);*/

        }
    }
    $scope.paymetHistory = function (taxid) {
        var paymetHtory = Parse.Object.extend("MerchantTransaction");
        var point = new paymetHtory();
        point.set("merchantTransactionId", taxid)
        point.set("userObjectId", $rootScope.user.id);
        point.set("Amount", $scope.user.money);
        point.save(null, {
            success: function (point) {
                $ionicLoading.hide();
                //$scope.editable = true;
                //$rootScope.showAlert('Profile Saved successfully.');
                // Saved successfully.
            },
            error: function (point, error) {
                $ionicLoading.hide();
                //$rootScope.showAlert(error);
            }
        });
        $http({
            method: 'GET',
            url: 'http://default-environment.2dmee9yyxr.ap-southeast-1.elasticbeanstalk.com/Payment/GetPaymentObject?merchantTransactionId=' + taxid,
        }).then(function (response) {
            if (response.data == 'ok') {
                $scope.user.money = '';
            } else {
                $scope.user.money = '';
            }
        });
    }

    $scope.TransactionHistory = [];
    $scope.GetTransactionHistory = function () {
        if ($localstorage.getObject('PatientTransactionHistory') === null) {} //$ionicLoading.show();
        Parse.Cloud.run('GetTransactionHistory', {
            UserProfileId: $rootScope.user.ProfileId
        }, {
            success: function (results) {
                $ionicLoading.hide();
                //$scope.TransactionHistory = results;
                $localstorage.setObject('PatientTransactionHistory', results);
                $scope.TransactionHistory = $localstorage.getObject('PatientTransactionHistory');
                $scope.$apply();
            },
            error: function (error) {
                $ionicLoading.hide();
                // error
            }
        });
    };
    $ionicModal.fromTemplateUrl('payumoney.html', {
        scope: $scope,
        animation: 'fade-in-up'
    }).then(function (modal) {
        $scope.profilemodal = modal;
    });
    $scope.openProfileModal = function () {
        $scope.profilemodal.show();
        //$ionicLoading.show();
    };
    $scope.closeProfileModal = function () {
        clearInterval(myVar);
        $scope.profilemodal.hide();
    };
    //Cleanup the modal when we're done with it!
    $scope.$on('$destroy', function () {
        clearInterval(myVar);
        $scope.profilemodal.remove();
    });
    $scope.hideProgress = function () {
        $ionicLoading.hide();
    }



    $scope.rechargeAmount = [];
    $scope.showaddmoney = function () {
        $scope.Recharge = true;
        $scope.Rechargebtn = true;
        $scope.openRechargeModal();
    }
    $ionicModal.fromTemplateUrl('encash.html', {
        scope: $scope,
        animation: 'fade-in-up'
    }).then(function (modal) {
        $scope.rechargeModal = modal;
    });
    $scope.openRechargeModal = function () {
        if ($rootScope.NetworkStatus)
            $scope.rechargeModal.show();
        else
            $cordovaToast.show('no connection available', 'short', 'center')

    };
    $scope.closeRechargeModal = function () {
        $scope.rechargeModal.hide();
    };
    //Cleanup the modal when we're done with it!
    $scope.$on('$destroy', function () {
        $scope.rechargeModal.remove();
    });
    $scope.showaddMoneyfn = function () {
        if ($scope.rechargeAmount.amount != undefined && $scope.rechargeAmount.amount != null) {
            if ($scope.rechargeAmount.amount > $scope.setting.Revenue || $scope.rechargeAmount.amount == 0 || $scope.rechargeAmount.amount == undefined) {
                $rootScope.showAlert('Please enter valid Health Credits.');
            } else {
                var confirmPopup = $ionicPopup.confirm({
                    title: 'CureBooth',
                    template: 'Encash Health Credits ' + $scope.rechargeAmount.amount + ' ?.'
                });
                confirmPopup.then(function (res) {
                    if (res) {
                        $scope.EncashCredits($scope.rechargeAmount.amount);
                    }
                });
            }
        } else {
            $rootScope.showAlert('Please enter encash credits.');
        }
    };
    $scope.EncashCredits = function (amt) {
        $ionicLoading.show();
        Parse.Cloud.run('EncashCredits', {
            Amount: amt,
        }, {
            success: function (results) {
                $ionicLoading.hide();
                if (results != undefined && results != null) {
                    $scope.getReceivable();
                    $scope.GetTransactionHistory();
                    $scope.closeRechargeModal();
                    $cordovaToast.show('Encash request sent successfully', 'short', 'center')
                }
            },
            error: function (error) {
                $cordovaToast.show(error.message, 'short', 'center')
                $ionicLoading.hide();
            }
        });
    }

    // Intialize the controller 
    if ($rootScope.NetworkStatus) {
        $scope.setting.Revenue = $localstorage.getObject('WalletBalance');
        $scope.TransactionHistory = $localstorage.getObject('PatientTransactionHistory');
        $scope.GetTransactionHistory();
        $scope.getReceivable();
    } else {
        $scope.setting.Revenue = $localstorage.getObject('WalletBalance');
        $scope.TransactionHistory = $localstorage.getObject('PatientTransactionHistory');
    }
    $scope.$on('$ionicView.beforeLeave', function () {
        clearInterval(myVar);
    });
    //ionicMaterialInk.displayEffect();
})