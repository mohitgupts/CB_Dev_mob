    //dev userType
    var doctype = 'LZpZ395Bzj';
    var pnttype = 'gxos4EySn2';
    var userTypes = [{
        "id": "LZpZ395Bzj",
        "userType": "Doctor"
    }, {
        "id": "gxos4EySn2",
        "userType": "Patient"
    }]
    var TokenStatus = {
        "Available": "JZYLXzAItW",
        "Booked": "5K1EtKrhir",
        "Serviced": "4be3BHwafe",
        "Servicing": "Klob8Odiqb",
        "Cancelled": "vkWS1kW2Uk"
    }


    //Prod userType
    /*   var userTypes = [{
        "id": "7ukn8rSUhi",
        "userType": "Doctor"
}, {
        "id": "48AOHFLgvg",
        "userType": "Patient"
    }]
    var doctype = '7ukn8rSUhi';
    var pnttype = '48AOHFLgvg';*/

    //angular.module('nGageRX.controllers', [])
    cbApp.controller('AppCtrl', function ($scope, $rootScope, $ionicModal, $timeout, $state, $ionicPopup, $ionicLoading, $localstorage, $ionicHistory, $cordovaToast, ionicMaterialInk) {
        $rootScope.isDoctor = window.localStorage['isDoctor'];
        $rootScope.isPatient = window.localStorage['isPatient'];
        var currentUser = Parse.User.current();
        $rootScope.user = null;
        $rootScope.UserProfile = null;
        $rootScope.isLoggedIn = false;
        $rootScope.handleParseError = function (err) {
                switch (err.code) {
                case Parse.Error.INVALID_SESSION_TOKEN:
                    Parse.User.logOut();
                    $localstorage.clearAll();
                    $ionicHistory.clearCache();
                    $ionicHistory.clearHistory()
                    $ionicLoading.hide();
                    $rootScope.isDoctor = '';
                    window.localStorage['isDoctor'] = '';
                    $rootScope.isPatient = '';
                    window.localStorage['isPatient'] = '';
                    $state.go("login");
                    navigator.app.exitApp();
                    break;

                    // Other Parse API errors that you want to explicitly handle
                }
            }
            //console.log(currentUser)

        if (currentUser) {
            console.log(window.localStorage['isDoctor'])
            if (window.localStorage['isDoctor'] != undefined || window.localStorage['isPatient'] != undefined) {
                $rootScope.user = currentUser;
                $rootScope.isLoggedIn = true;
                $rootScope.isDoctor = window.localStorage['isDoctor'];
                $rootScope.isPatient = window.localStorage['isPatient'];

                if ($rootScope.isDoctor == 'true') {
                    console.log('isDoctor')
                    $state.go('tab.home');
                } else if ($rootScope.isPatient == 'true') {
                    console.log('isPatient')
                    $state.go('tab.PatientHome');
                }
            } else {
                Parse.User.logOut();
                $state.go('login');
            }
        } else {
            console.log('login')
            $state.go('login');
        }
        // Form data for the login modal
        $scope.loginData = {};
        // Create the login modal that we will use later
        $ionicModal.fromTemplateUrl('templates/more.html', {
            scope: $scope
        }).then(function (modal) {
            $scope.modal = modal;
        });
        /*$cordovaGeolocation.getCurrentPosition(posOptions).then(function (position) {
            var lat = position.coords.latitude
            var long = position.coords.longitude
            console.log('geolocation found' + lat);
            console.log(position.coords);
            GetAddress(position)
        }, function (err) {
            console.log('geolocation not found');
            console.log(err);
        });*/

        function GetAddress(position) {
            var lat = position.coords.latitude;
            var lng = position.coords.longitude;
            var latlng = new google.maps.LatLng(lat, lng);
            $rootScope.Currentlatlng = latlng;
            var geocoder = geocoder = new google.maps.Geocoder();
            geocoder.geocode({
                'latLng': latlng
            }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[1]) {
                        for (j = 0; j < results[0].address_components.length; j++) {
                            if (results[0].address_components[j].types[0] == 'postal_code')
                                $rootScope.PinCode = results[0].address_components[j].short_name
                            if (results[0].address_components[j].types[1] == 'sublocality')
                                $rootScope.sublocality = results[0].address_components[j].short_name
                            if (results[0].address_components[j].types[0] == 'locality')
                                $rootScope.locality = results[0].address_components[j].short_name
                            if (results[0].address_components[j].types[0] == 'administrative_area_level_2')
                                $rootScope.city = results[0].address_components[j].short_name
                                //console.log("Zip Code: " + results[0].address_components[j].short_name);
                        }
                        if ($rootScope.sublocality != null)
                            $rootScope.Address = $rootScope.sublocality + ', ';
                        if ($rootScope.locality == $rootScope.city)
                            $rootScope.Address += $rootScope.locality;
                        else
                            $rootScope.Address += $rootScope.locality + ', ' + $rootScope.city;
                        $rootScope.Address += ', ' + $rootScope.PinCode
                        console.log("Address: " + $rootScope.Address);
                        $rootScope.CurrentAddress = results[1].formatted_address
                            //alert("Location: " + results[1].formatted_address + "postal_code: " + results[1].address_components.postal_code);
                    }
                }
            });
        }
        $scope.dashBoard = function () {
                if ($rootScope.isDoctor == 'true') {
                    console.log('isDoctor')
                    $state.go('tab.home');
                } else if ($rootScope.isPatient == 'true') {
                    console.log('isPatient')
                    $state.go('tab.PatientHome');
                }
            }
            // Triggered in the login modal to close it
        $scope.closeLogin = function () {
            $scope.modal.hide();
        };
        // Open the login modal
        $scope.more = function () {
            $scope.modal.show();
        };
        // Show Popup     
        $rootScope.showAlert = function (msg) {
            var alertPopup = $ionicPopup.alert({
                title: 'CureBooth',
                cssClass: 'cbpopup',
                template: msg
            });
            alertPopup.then(function (res) {
                console.log('Thank you');
            });
        };
        $scope.logOut = function () {
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {
                var confirmPopup = $ionicPopup.confirm({
                    title: 'CureBooth',
                    template: 'Are you sure ! <br/> You want to logout?'
                });

                confirmPopup.then(function (res) {
                    if (res) {
                        //$scope.logOutfn();
                        var targetUser = new Parse.User();
                        targetUser.id = $rootScope.user.id;
                        ParsePushPlugin.getInstallationId(function (id) {
                                console.log(id)
                                var query = new Parse.Query(Parse.Installation);
                                query.equalTo('installationId', id);
                                query.equalTo('UserPointer', targetUser);
                                query.find({
                                    success: function (results) {
                                        var point = results[0];
                                        //point.set("UserPointer", targetUser);
                                        point.set("Active", false);
                                        point.save(null, {
                                            success: function (point) {
                                                //$ionicLoading.hide();
                                                $scope.logOutfn();
                                                console.log('User Pointer saved in Installation table');
                                            },
                                            error: function (point, error) {
                                                $ionicLoading.hide();
                                            }
                                        });
                                    },
                                    error: function (error) {
                                        $ionicLoading.hide();

                                        //alert("Error: " + error.code + " " + error.message);
                                    }
                                });
                            },
                            function (e) {
                                //alert('error');
                            });
                    }
                })
            }
        }
        $scope.logOutfn = function () {
            $ionicLoading.show();
            Parse.User.logOut()
            var currentUser = Parse.User.current();
            console.log('CurrentUser : ' + currentUser)
            if (currentUser) {
                $rootScope.user = currentUser;
                $rootScope.isLoggedIn = true;
                $state.go('tab.home');
            } else {
                $localstorage.clearAll();
                $ionicHistory.clearCache();
                $ionicHistory.clearHistory()
                $ionicLoading.hide();
                $rootScope.isDoctor = '';
                window.localStorage['isDoctor'] = '';
                $rootScope.isPatient = '';
                window.localStorage['isPatient'] = '';
                $state.go("login");
                navigator.app.exitApp();

            }
        };
        ////ionicMaterialInk.displayEffect();
    })
    cbApp.controller('LoginController', function ($scope, $state, $rootScope, $ionicLoading, $ionicHistory, $ionicModal, $ionicPopup, ionicMaterialInk) {
        $scope.user = {
            username: null,
            password: null
        };

        $scope.error = {};
        $rootScope.showAlert = function (msg) {
            var alertPopup = $ionicPopup.alert({
                title: 'CureBooth',
                cssClass: 'balance',
                template: msg
            });
            alertPopup.then(function (res) {
                console.log('Thank you');
            });
        };

        $scope.login = function () {
            if ($scope.user.username == null) {
                $rootScope.showAlert('Please enter User Name')

            } else if ($scope.user.password == null) {
                $rootScope.showAlert('Please enter password')
            } else {
                $scope.loading = $ionicLoading.show({
                    content: 'Logging in',
                    animation: 'fade-in',
                    showBackdrop: true,
                    maxWidth: 200,
                    showDelay: 0
                });

                var user = $scope.user;
                Parse.User.logIn(('' + user.username).toLowerCase(), user.password, {
                    success: function (user) {
                        $ionicLoading.hide();
                        $rootScope.user = user;
                        $rootScope.isLoggedIn = true;
                        $scope.user = {};
                        if (user.get('phoneVerified')) {
                            var page = '';
                            document.addEventListener("deviceready", function () {
                                $scope.InstallationObj(user.id);
                            }, false);

                            if (user.get('UserTypeObjectId') == doctype) {
                                $rootScope.isDoctor = 'true';
                                window.localStorage['isDoctor'] = true;
                                window.localStorage['isPatient'] = 'false';
                                var name = window.localStorage['isDoctor'] || 'you';
                                page = 'tab.home';
                            } else if (user.get('UserTypeObjectId') == pnttype) {
                                $rootScope.isPatient = 'true';
                                window.localStorage['isDoctor'] = 'false';
                                window.localStorage['isPatient'] = 'true';
                                var name = window.localStorage['isPatient'] || 'you';
                                page = 'tab.PatientHome';
                            }
                            $state.go(page);

                        } else {
                            $rootScope.OTPUser = user;
                            $rootScope.resend = true;
                            $state.go('otp', {
                                clear: true
                            });
                        }
                    },
                    error: function (user, err) {
                        $ionicLoading.hide();
                        $rootScope.showAlert(err.message);
                        if (err.code === 101) {
                            $scope.error.message = 'Invalid login credentials';
                            //$rootScope.showAlert($scope.error.message);
                        } else {
                            $scope.error.message = 'An unexpected error has ' +
                                'occurred, please try again.';
                            //$rootScope.showAlert($scope.error.message);
                        }
                        $scope.$apply();
                    }

                });
            }
        };
        $scope.InstallationObj = function (userid) {
            var targetUser = new Parse.User();
            targetUser.id = userid;
            ParsePushPlugin.getInstallationId(function (id) {
                    var query = new Parse.Query(Parse.Installation);
                    query.equalTo('installationId', id);
                    query.find({
                        success: function (results) {
                            var point = results[0];
                            point.set("UserPointer", targetUser);
                            point.set("Active", true);
                            point.save(null, {
                                success: function (point) {
                                    $ionicLoading.hide();
                                    console.log('User Pointer saved in Installation table');
                                },
                                error: function (point, error) {
                                    $ionicLoading.hide();
                                }
                            });
                        },
                        error: function (error) {
                            $ionicLoading.hide();

                            //alert("Error: " + error.code + " " + error.message);
                        }
                    });
                },
                function (e) {
                    //alert('error');
                });

        }

        $scope.forgot = function () {
            $state.go('forgot');
        };
        $ionicModal.fromTemplateUrl('my-modal.html', {
            scope: $scope,
            animation: 'fade-in-up'
        }).then(function (modal) {
            $scope.modal = modal;
            console.log($scope.modal)
        });
        $scope.openModal = function () {
            $scope.modal.show();
        };
        $scope.closeModal = function () {
            $scope.modal.hide();
        };
        //Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function () {
            $scope.modal.remove();
        });

        $scope.otpsend = false;
        $scope.errormsg = false;
        $scope.Error = [];
        $scope.phonedata = {
            mobileno: '',
            userotp: ''
        }
        $scope.phoneReg = function (data) {
            console.log(data.mobileno.toString().length)
            if (!$scope.otpsend) {
                if (typeof data.mobileno === 'undefined' || data.mobileno === null) {
                    $rootScope.showAlert("Please enter Phone number");
                } else if (data.mobileno.toString().length != 10) {
                    $rootScope.showAlert("Please enter 10 digit Mobile number only");
                } else {
                    $ionicLoading.show();
                    Parse.Cloud.run('SendOTP', {
                        mobileNo: data.mobileno
                    }, {
                        success: function (results) {
                            $ionicLoading.hide();
                            $scope.errormsg = false;
                            $scope.otpsend = true;
                        },
                        error: function (error) {
                            $ionicLoading.hide();
                            $scope.errormsg = true;
                            $scope.Error = error;
                            console.log($scope.Error)
                            $scope.$apply();
                        }
                    });
                }
            } else {
                $ionicLoading.show();
                Parse.Cloud.run('VerifyOTP', {
                    mobileNo: data.mobileno,
                    code: data.userotp
                }, {
                    success: function (results) {
                        $ionicLoading.hide();
                        $scope.errormsg = false;
                        $rootScope.UserMobile = data.mobileno;
                        $scope.closeModal();
                        $state.go('register', {
                            clear: true
                        });


                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        $scope.errormsg = true;
                        $scope.Error = error;
                        /*$state.go('register', {
                            clear: true
                        });*/
                    }
                });
            }

        }


        //ionicMaterialInk.displayEffect();
    })
    cbApp.controller('ForgotPasswordController', function ($rootScope, $scope, $state, $ionicLoading, $ionicPopup, ionicMaterialInk) {
        $scope.user = {};
        $scope.error = {};
        $scope.state = {
            success: false
        };
        $scope.resetPass = {};


        $scope.showAlert = function (msg) {
            var alertPopup = $ionicPopup.alert({
                title: 'CureBooth',
                cssClass: 'balance',
                template: msg
            });
            alertPopup.then(function (res) {
                console.log('Thank you');
            });
        };
        $scope.reset1 = function () {
            $scope.loading = $ionicLoading.show({
                content: 'Sending',
                animation: 'fade-in',
                showBackdrop: true,
                maxWidth: 200,
                showDelay: 0
            });

            /*      Parse.User.requestPasswordReset($scope.user.email, {
                      success: function () {
                          // TODO: show success
                          $ionicLoading.hide();
                          $scope.state.success = true;
                          $scope.$apply();
                      },
                      error: function (err) {
                          $ionicLoading.hide();
                          if (err.code === 125) {
                              $scope.errorr.message = 'Email address does not exist';
                              $rootScope.showAlert($scope.errorr.message);
                          } else {
                              $scope.error.message = 'An unknown error has occurred, ' +
                                  'please try again';
                              $rootScope.showAlert($scope.errorr.message);
                          }
                          $scope.$apply();
                      }
                  });*/
        };
        $scope.otpsend = false;
        $scope.reset = function (data) {
            if (typeof data.mobileNumber === 'undefined' || data.mobileNumber === null) {
                $scope.showAlert("Please enter Mobile number");
            } else if (data.mobileNumber.toString().length != 10) {
                $scope.showAlert("Please enter 10 digit Mobile number only");
            } else {
                $ionicLoading.show();
                Parse.Cloud.run('SendSMS', {
                    mobileNo: data.mobileNumber
                }, {
                    success: function (results) {
                        $ionicLoading.hide();
                        $scope.otpsend = true;
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        $scope.showAlert(error.message);
                    }
                });
            }
        }
        $scope.resetpassword = function (data) {
            if (typeof data.OTP === 'undefined' || data.OTP === null) {
                $scope.showAlert("Please enter OTP");
            } else if (typeof data.Password === 'undefined' || data.Password === null) {
                $scope.showAlert("Please Enter Password");
            } else if (typeof data.cPassword === 'undefined' || data.cPassword === null) {
                $scope.showAlert("Please Enter Confirm Password");
            } else if (data.Password != data.cPassword) {
                $scope.showAlert("Please Enter Same Password and Confirm Password ");
            } else {
                $ionicLoading.show();
                Parse.Cloud.run('SetForgotPassword', {
                    username: data.mobileNumber,
                    code: data.OTP,
                    password: data.Password
                }, {
                    success: function (results) {
                        $ionicLoading.hide();
                        var alertPopup = $ionicPopup.alert({
                            title: 'CureBooth',
                            cssClass: 'balance',
                            template: 'Password changed Successfully !<br> Please login again'
                        });
                        alertPopup.then(function (res) {
                            $scope.login();
                        });
                    },
                    error: function (error) {
                        $scope.showAlert(error.message);
                        $ionicLoading.hide();
                    }
                });
            }
        };

        $scope.login = function () {
            $state.go('login');
        };
        //ionicMaterialInk.displayEffect();
    })
    cbApp.controller('RegisterController', function ($scope, $state, $ionicLoading, $ionicPopup, $rootScope, $http, ionicMaterialInk) {
        $scope.user = {};
        $scope.error = {};
        $scope.userTypes = userTypes;
        $scope.user.phone = parseInt($rootScope.UserMobile);
        $scope.user.CountryCode = '91';
        $scope.userTypeDoctor = false;
        $scope.userType = function (data) {
            console.log(data)
            if (data == doctype)
                $scope.userTypeDoctor = true;
            else
                $scope.userTypeDoctor = false;
        }

        $scope.Validate = function () {
            var ErrorArr = new Array();
            if (typeof $scope.user === 'undefined' || $scope.user === null)
                throw 'Basic info is not entered';
            else {
                if (typeof $scope.user.userType === 'undefined' || $scope.user.userType === null) {
                    $rootScope.showAlert("Please Select UserType");
                    ErrorArr.push('Client \'Date of Birth\' is required.');
                } else if (typeof $scope.user.fullName === 'undefined' || $scope.user.fullName === null) {
                    $rootScope.showAlert('Please enter some valid value into - Full Name.');
                    ErrorArr.push('Client \'FirstName\' is required.');
                } else if (typeof $scope.user.email === 'undefined' || $scope.user.email === null) {
                    $rootScope.showAlert('Please enter some valid value into - Email');
                    ErrorArr.push('Client \'Surname\' is required.');
                } else if (typeof $scope.user.phone === 'undefined' || $scope.user.phone === null) {
                    $rootScope.showAlert("Please enter Phone number");
                    ErrorArr.push('Client \'Date of Birth\' is required.');
                } else if ($scope.user.userType == doctype && $scope.user.MciNo === null) {
                    $rootScope.showAlert("Please enter MCI Registration Number");
                    ErrorArr.push('Client \'Date of Birth\' is required.');
                } else if (typeof $scope.user.password === 'undefined' || $scope.user.password === null) {
                    $rootScope.showAlert("Please enter Password");
                    ErrorArr.push('Client \'Date of Birth\' is required.');
                } else if (typeof $scope.user.Cpassword === 'undefined' || $scope.user.Cpassword === null) {
                    $rootScope.showAlert("Please enter Confirm Password");
                    ErrorArr.push('Client \'Date of Birth\' is required.');
                } else if ($scope.user.password != $scope.user.Cpassword) {
                    $rootScope.showAlert("Please enter same Password and Confirm Password");
                    ErrorArr.push('Client \'Date of Birth\' is required.');
                }


            }
            if (ErrorArr.length > 0)
                return false;

            return true; //_isValidVM
        }
        $scope.register = function () {
            if ($scope.Validate()) {
                $ionicLoading.show();
                var phone = $scope.user.phone;
                phone = phone.toString()
                var user = new Parse.User();
                user.set("fullName", $scope.user.fullName);
                user.set("username", phone);
                user.set("password", $scope.user.password);
                user.set("OriginalPwd", $scope.user.password);
                user.set("email", $scope.user.email);
                user.set("PhoneNumber", phone);
                user.set("phoneVerified", true);
                user.set("ExotelNumber", "0");
                user.set("UserTypeObjectId", $scope.user.userType);
                user.set("MciNo", $scope.user.MciNo);
                user.signUp(null, {
                    success: function (user) {
                        $rootScope.isLoggedIn = true;
                        // Default Profile function
                        myObject = user;
                        $scope.SetDefaultProfile(myObject.get("fullName"), myObject.get("MciNo"), myObject.get("UserTypeObjectId"));
                        // Verify the user
                        var point = myObject;
                        point.set("phoneVerified", true);
                        // Save
                        point.save(null, {
                            success: function (point) {
                                $ionicLoading.hide();
                            },
                            error: function (point, error) {
                                $ionicLoading.hide();
                            }
                        });
                        // Create user Wallet
                        $scope.InstallationObj(myObject.id);
                        var ParseWallet = new Parse.Object.extend("Wallet");
                        var objWallet = new ParseWallet();
                        objWallet.set("UserObjectId", myObject.id);
                        objWallet.set("Amount", parseFloat(0.00));
                        objWallet.save();

                        // Navigation based on usertype
                        if (myObject.get('UserTypeObjectId') == doctype) {
                            $state.go('tab.home', {
                                //clear: true
                            });
                            $rootScope.isDoctor = 'true';
                            window.localStorage['isDoctor'] = true;
                            window.localStorage['isPatient'] = 'false';
                            var name = window.localStorage['isDoctor'] || 'you';
                            console.log('Hello, ' + name);
                        } else if (myObject.get('UserTypeObjectId') == pnttype) {
                            $state.go('tab.PatientHome', {
                                //clear: true
                            });
                            $rootScope.isPatient = 'true';
                            window.localStorage['isDoctor'] = 'false';
                            window.localStorage['isPatient'] = 'true';
                            var name = window.localStorage['isPatient'] || 'you';
                            console.log('Hello, ' + name);
                        }
                    },
                    error: function (user, error) {
                        console.log(error)
                        $ionicLoading.hide();
                        if (error.code === 125) {
                            $scope.error.message = '  Please specify a valid email ' +
                                'address';
                            $rootScope.showAlert($scope.error.message);
                        } else if (error.code === 202) {
                            $scope.error.message = 'Phone Number is already registered, Please login';
                            var alertPopup = $ionicPopup.alert({
                                title: 'CureBooth',
                                cssClass: 'balance',
                                template: $scope.error.message
                            });
                            alertPopup.then(function (res) {
                                $state.go('login');
                            });

                            $rootScope.showAlert($scope.error.message);
                        } else if (error.code === 203) {
                            $scope.error.message = 'Email is already registered';
                            $rootScope.showAlert($scope.error.message);
                        } else {
                            $scope.error.message = error.message;
                            $rootScope.showAlert($scope.error.message);
                        }
                        //$scope.$apply();
                    }
                });
            }
        };
        $scope.InstallationObj = function (userid) {
            var targetUser = new Parse.User();
            targetUser.id = userid;
            ParsePushPlugin.getInstallationId(function (id) {
                    var query = new Parse.Query(Parse.Installation);
                    query.equalTo('installationId', id);
                    query.find({
                        success: function (results) {
                            var point = results[0];
                            point.set("UserPointer", targetUser);
                            point.set("Active", true);
                            point.save(null, {
                                success: function (point) {
                                    $ionicLoading.hide();
                                    console.log('User Pointer saved in Installation table');
                                },
                                error: function (point, error) {
                                    $ionicLoading.hide();
                                }
                            });
                        },
                        error: function (error) {
                            $ionicLoading.hide();

                            //alert("Error: " + error.code + " " + error.message);
                        }
                    });
                },
                function (e) {
                    //alert('error');
                });

        }
        $scope.SendSMS = function (phone) {
            $ionicLoading.show();
            Parse.Cloud.run('SendSMS', {
                mobileNo: phone
            }, {
                success: function (results) {
                    $ionicLoading.hide();
                    $state.go('otp', {
                        clear: true
                    });
                },
                error: function (error) {
                    $ionicLoading.hide();
                    // error
                }
            });
        };


        // Resend OTP SMS
        //$rootScope.resend = false;
        var currentUser = Parse.User.current();

        $scope.ReSendSMS = function () {
            if ($rootScope.OTPUser != null) {
                $rootScope.resend = true;
                $scope.SendSMS($rootScope.OTPUser.get('PhoneNumber'))

            } else {
                $scope.SendSMS(phone);
            }

        }


        $scope.SetDefaultProfile = function (name, mci, id) {
            //$ionicLoading.show();
            Parse.Cloud.run('SetDefaultProfile', {
                FirstName: name,
                MciNo: mci,
                UserTypeObjectId: id
            }, {
                success: function (results) {
                    $ionicLoading.hide();
                },
                error: function (error) {
                    $ionicLoading.hide();
                    // error
                }
            });
        };
        $scope.checkOtp = function () {
                console.log($scope.user.otp)
                if ($scope.user.otp) {
                    myObject = $rootScope.user;
                    myObject.fetch({
                        success: function (myObject) {
                            if (myObject.get("OTP") == $scope.user.otp) {
                                // Default Profile function
                                $scope.SetDefaultProfile(myObject.get("fullName"), myObject.get("UserTypeObjectId"));
                                // Verify the user
                                var point = myObject;
                                point.set("phoneVerified", true);
                                // Save
                                point.save(null, {
                                    success: function (point) {
                                        $ionicLoading.hide();
                                    },
                                    error: function (point, error) {
                                        $ionicLoading.hide();
                                    }
                                });
                                // Create user Wallet
                                var ParseWallet = new Parse.Object.extend("Wallet");
                                var objWallet = new ParseWallet();
                                objWallet.set("UserObjectId", myObject.id);
                                objWallet.set("Amount", parseFloat(0.00));
                                objWallet.save();

                                // Navigation based on usertype
                                if (myObject.get('UserTypeObjectId') == doctype) {
                                    $state.go('tab.home', {
                                        clear: true
                                    });
                                    $rootScope.isDoctor = 'true';
                                    window.localStorage['isDoctor'] = true;
                                    window.localStorage['isPatient'] = 'false';
                                    var name = window.localStorage['isDoctor'] || 'you';
                                    console.log('Hello, ' + name);
                                } else if (myObject.get('UserTypeObjectId') == pnttype) {
                                    $state.go('tab.PatientHome', {
                                        clear: true
                                    });
                                    $rootScope.isPatient = 'true';
                                    window.localStorage['isDoctor'] = 'false';
                                    window.localStorage['isPatient'] = 'true';
                                    var name = window.localStorage['isPatient'] || 'you';
                                    console.log('Hello, ' + name);
                                }
                            } else {
                                $rootScope.resend = true;
                                $rootScope.showAlert("Please enter correct OTP");
                            }
                        },
                        error: function (myObject, error) {
                            // The object was not refreshed successfully.
                            // error is a Parse.Error with an error code and message.
                        }
                    });
                }

            }
            //ionicMaterialInk.displayEffect();
    })
    cbApp.controller('HomeCtrl', function ($scope, $http, $rootScope, $ionicModal, $ionicPopup, $ionicHistory, $ionicScrollDelegate, $state, $ionicLoading, $localstorage, $cordovaToast, ionicMaterialInk) {
        /* var req = {
             method: 'POST',
             url: 'https://www.payumoney.com/payment/op/getPaymentResponse?merchantkey=5357137&merchantTransactionIds=qw96102427141',
             headers: {
                 "Content-Type": "application/json",
                 "Authorization": "F4/XvYSYwl4HOwql15F73gzEbcO1DCTURYwDjtn1w40="
             }
         }
         $http(req).then(function () {}, function () {});
         $http({
             method: 'POST',
             url: 'https://www.payumoney.com/payment/op/getPaymentResponse',
             data: 'merchantkey=5357137&merchantTransactionIds=qw96102427141',
             headers: {
                 "Content-Type": "application/x-www-form-urlencoded",
                 "Authorization": "F4/XvYSYwl4HOwql15F73gzEbcO1DCTURYwDjtn1w40="
             }
         }).then(function (response) {
             if (response.data == 'ok') {
                 // success
             } else {
                 // failed
             }
         });yx7*/
        $scope.selectedDiv = 'Patient';
        $rootScope.profile = '';
        $scope.Status = {
            statusType: ''
        }
        if (window.ParsePushPlugin) {
            ParsePushPlugin.on('receivePN', function (pn) {
                //alert('yo i got this push notification:' + JSON.stringify(pn));
            });
            ParsePushPlugin.on('openPN', function (pn) {
                //you can do things like navigating to a different view here
                console.log(JSON.stringify(pn));
                console.log('Yo, I get this when the user clicks open a notification from the tray');
                if (pn.type == 1) {
                    $scope.selectedDiv = 'Patient';
                }
                if (pn.type == 2) {
                    $scope.selectedDiv = 'Call';
                }
                if (pn.type == 3) {
                    $scope.selectedDiv = 'Message';
                }
                /* if(pn.type==4){
                      $state.go('tab.wallet');
                 }*/
            });
            //
            //you can also listen to your own custom subevents
            //
            //ParsePushPlugin.on('receivePN:chat', chatEventHandler);
            //ParsePushPlugin.on('receivePN:serverMaintenance', serverMaintenanceHandler);
        }
        $ionicHistory.clearHistory()
        $scope.showTabCantent = function (option) {
            $scope.selectedDiv = option; //'Client';
            $ionicScrollDelegate.scrollTop();
        }

        // View Patient
        $scope.ViewPatient = function (item) {
            $rootScope.PtData = item;
            $state.go('tab.DrPatientHome');
        }
        $scope.chat = function (item) {
            $rootScope.chatUser = item;
            $rootScope.chatArchived = item.IsArchive;
            //console.log($rootScope.chatUser.get('PatientProfileObjectId').get('ProfileImage').url())

        }
        $scope.ViewProfile = function () {
                $state.go('tab.profile');
            }
            // list of status
        $scope.getStatusType = function () {
                if ($localstorage.getObject('StatusType') === null) {
                    //$ionicLoading.show();
                }
                var query = new Parse.Query('StatusType');
                query.find({
                    success: function (results) {
                        $ionicLoading.hide();
                        //$scope.StatusType = results
                        $localstorage.setObject('StatusType', results);
                        $scope.StatusType = $localstorage.getObject('StatusType');
                        $scope.$apply();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        if (error.code == 209)
                            $state.go('login');
                        //alert("Error: " + error.code + " " + error.message);
                    }
                });
            }
            // User current status no need of it
        $scope.getStatus = function () {
                if ($localstorage.getObject('StatusName') === null) {}
                //$ionicLoading.show();

                var query = new Parse.Query('UserStatus');
                query.equalTo('UserId', $rootScope.user.id);
                query.find({
                    success: function (results) {
                        if (results.length > 0) {
                            console.log(results[0].get('StatusName'));
                            $ionicLoading.hide();
                            $scope.Status.statusType = results[0].get('StatusName')
                                //alert(object.id + ' - ' + object.get('playerName'));
                        }
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        //alert("Error: " + error.code + " " + error.message);
                    }
                });
            }
            // Dr Patient list
        $scope.PatientListfn = function (id) {
            Parse.Cloud.run('PatientList', {
                DoctorProfileId: id //'PRpuqlmbtC'
            }, {
                success: function (status) {
                    /*  if (status.length > 0) {
                          $localstorage.setObject('DoctorPatientList', status);
                          $scope.PatientList = $localstorage.getObject('DoctorPatientList');
                          $scope.$apply();
                      }*/
                    if (status.length > 0) {
                        $scope.DoctorList1 = [];
                        for (i = 0; i < status.length; i++) {
                            var ProfileImage;
                            if (status[i].get('PatientProfileObjectId').get('ProfileImage') != undefined) {
                                ProfileImage = status[i].get('PatientProfileObjectId').get('ProfileImage').url();
                            } else {
                                ProfileImage = "img/patient_icon_default.png";
                            }
                            var temp = {
                                    chatThreadId: status[i].attributes.chatThreadId,
                                    UserObjectId: status[i].attributes.PatientUserObjectId,
                                    id: status[i].attributes.PatientProfileObjectId.id,
                                    DoctorUserObjectId: status[i].attributes.DoctorUserObjectId,
                                    IsFollowed: status[i].attributes.IsFollowed,
                                    IsPriority: status[i].attributes.IsPriority,
                                    IsVerfied: status[i].attributes.IsVerfied,
                                    FirstName: status[i].attributes.PatientProfileObjectId.attributes.FirstName,
                                    FullName: status[i].attributes.PatientProfileObjectId.attributes.FullName,
                                    LastName: status[i].attributes.PatientProfileObjectId.attributes.LastName,
                                    Phone: status[i].attributes.PatientProfileObjectId.attributes.Phone,
                                    Health_Summary: status[i].attributes.PatientProfileObjectId.attributes.Health_Summary,
                                    Address: status[i].attributes.PatientProfileObjectId.attributes.Address,
                                    ProfileImage: ProfileImage,
                                    ProfileLinkId: status[i].id,
                                    isMute: status[i].attributes.DoctorMuted
                                }
                                // console.log(temp)
                            $scope.DoctorList1.push(temp);
                        }
                        $localstorage.setObject('DoctorPatientList', $scope.DoctorList1);
                        $scope.PatientList = $localstorage.getObject('DoctorPatientList');
                        $scope.$apply();
                    } else
                        $scope.PatientList = '';
                },
                error: function (error) {

                }
            });
        }
        $scope.chatListfn = function (id) {
                Parse.Cloud.run('ChatList', {
                    ProfileId: id,
                    IsDoctor: 1
                }, {
                    success: function (status) {
                        if (status.length > 0) {
                            //$scope.ChatList = status
                            /* $localstorage.setObject('DoctorChatList', status);
                             $scope.ChatList = $localstorage.getObject('DoctorChatList');
                             $scope.$apply();*/
                            $scope.ChatList1 = [];
                            for (i = 0; i < status.length; i++) {
                                var ProfileImage;
                                if (status[i].get('PatientProfileObjectId').get('ProfileImage') != undefined) {
                                    ProfileImage = status[i].get('PatientProfileObjectId').get('ProfileImage').url();
                                } else {
                                    ProfileImage = "img/patient_icon_default.png";
                                }
                                var RecentMsg;
                                if (status[i].get('RecentMsg') != undefined) {
                                    RecentMsg = status[i].get('RecentMsg').get('message');
                                    RecentMsgtime = status[i].get('RecentMsg').get('createdAt');
                                } else {
                                    RecentMsg = "";
                                    RecentMsgtime = ''
                                }
                                var temp = {
                                    chatThreadId: status[i].attributes.chatThreadId,
                                    UserObjectId: status[i].attributes.PatientUserObjectId,
                                    id: status[i].attributes.PatientProfileObjectId.id,
                                    DoctorUserObjectId: status[i].attributes.DoctorUserObjectId,
                                    IsFollowed: status[i].attributes.IsFollowed,
                                    IsPriority: status[i].attributes.IsPriority,
                                    IsVerfied: status[i].attributes.IsVerfied,
                                    FirstName: status[i].attributes.PatientProfileObjectId.attributes.FirstName,
                                    FullName: status[i].attributes.PatientProfileObjectId.attributes.FullName,
                                    LastName: status[i].attributes.PatientProfileObjectId.attributes.LastName,
                                    Phone: status[i].attributes.PatientProfileObjectId.attributes.Phone,
                                    Health_Summary: status[i].attributes.PatientProfileObjectId.attributes.Health_Summary,
                                    Address: status[i].attributes.PatientProfileObjectId.attributes.Address,
                                    ProfileImage: ProfileImage,
                                    RecentMsg: RecentMsg,
                                    RecentMsgtime: RecentMsgtime,
                                    ProfileLinkId: status[i].id,
                                    isMute: status[i].attributes.DoctorMuted
                                }
                                $scope.ChatList1.push(temp);
                            }
                            $localstorage.setObject('DoctorChatList', $scope.ChatList1);
                            $scope.ChatList = $localstorage.getObject('DoctorChatList');
                            $scope.$apply();
                        }
                    },
                    error: function (error) {
                        // debugger;
                        // error
                    }
                });
            }
            //PatientRequestCount
        $scope.PatientRequestCount = function (id) {
                Parse.Cloud.run('PatientRequestCount', {
                    ProfileId: id
                }, {
                    success: function (status) {
                        if (status != 0)
                            $scope.RequestCount = status
                            //console.log($scope.RequestCount)
                    },
                    error: function (error) {
                        // debugger;
                        // error
                    }
                });
            }
            //BroadcastChat
        $scope.BroadcastChat = function (msg) {
            Parse.Cloud.run('BroadcastChat', {
                message: msg
            }, {
                success: function (status) {
                    $scope.rechargeAmount.msg = '';
                    $scope.closeRechargeModal();
                    $cordovaToast.show('Broadcast message sent successfully', 'short', 'center')
                },
                error: function (error) {
                    // debugger;
                    // error
                }
            });
        }
        $scope.rechargeAmount = [];
        $scope.showaddmoney = function () {
                $scope.Recharge = true;
                $scope.Rechargebtn = true;
                $scope.openRechargeModal();
                //
            }
            /* $ionicModal.fromTemplateUrl('my-modal.html', {
                 scope: $scope,
                 animation: 'fade-in-up'
             }).then(function (modal) {
                 $scope.MsgModal = modal;
             });*/
        $scope.MsgModal = $ionicModal.fromTemplate('<ion-modal-view class="signup"><ion-header-bar class="bar bar-stable fix-buttons"><button class="button  bar bar-stable" ng-click="closeRechargeModal()" style="max-width: 100px; padding: 5px 10px; min-width: 80px; box-shadow: none;">Cancel</button><h1 class="title">Broadcast Message</h1></ion-header-bar><ion-content><div class="card" style="padding: 5px 10px 0;"><ion-input class="item item-input  item-floating-label"><ion-label>Enter Broadcast Message</ion-label> <input type="text" placeholder="Enter Broadcast Message" ng-model="rechargeAmount.msg"></ion-input><button ng-disabled="!rechargeAmount.msg" class="button button-full button-outline button-positive" ng-click="showaddMoneyfn()" style="color: rgb(255, 255, 255); background: rgb(0, 189, 189) none repeat scroll 0% 0%; box-shadow: none;">  Submit</button></div></ion-content></ion-modal-view>', {
            scope: $scope,
            animation: 'slide-in-up'
        });
        $scope.openRechargeModal = function () {
            if ($rootScope.NetworkStatus)
                $scope.MsgModal.show();
            else
                $cordovaToast.show('no connection available', 'short', 'center')

        };
        $scope.closeRechargeModal = function () {
            $scope.MsgModal.hide();
        };
        //Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function () {
            $scope.MsgModal.remove();
        });
        $scope.showaddMoneyfn = function () {
            if ($scope.rechargeAmount.msg != undefined && $scope.rechargeAmount.msg != null) {

                var confirmPopup = $ionicPopup.confirm({
                    title: 'CureBooth',
                    template: 'Broadcast Message to your Patients ?'
                });
                confirmPopup.then(function (res) {
                    if (res) {
                        $scope.BroadcastChat($scope.rechargeAmount.msg);
                    }
                });

            } else {
                $rootScope.showAlert('Please enter Broadcast Message.');
            }
        };
        // Call History Funtion 
        $scope.callhistoryfn = function (id) {
            if ($localstorage.getObject('Doctorcalllist') === null) {} //$ionicLoading.show();

            Parse.Cloud.run('GetCallHistory', {
                UserProfileId: id
            }, {
                success: function (results) {
                    $ionicLoading.hide();
                    $scope.calllist1 = [] // results;
                    for (i = 0; i < results.length; i++) {
                        if ($rootScope.user.id == results[i].get("ToProfileObjectId").get("UserObjectId")) {
                            results[i]['Incoming'] = true
                            $scope.calllist1.push(results[i]);
                        } else if ($rootScope.user.id == results[i].get("FromProfileObjectId").get("UserObjectId")) {
                            results[i]['Incoming'] = false
                            $scope.calllist1.push(results[i]);
                        }
                    }
                    //console.log($scope.calllist1)
                    $localstorage.setObject('Doctorcalllist', $scope.calllist1);
                    $scope.calllist = $localstorage.getObject('Doctorcalllist');
                    //console.log($scope.calllist)
                    $scope.$apply();
                },
                error: function (error) {
                    $ionicLoading.hide();
                    // error
                }
            });
        };

        // Change user status

        $scope.status = function () {
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {
                Parse.Cloud.run('ProfileStatus', {
                    StatusObjectId: $scope.Status.id,
                    ProfileId: $rootScope.user.ProfileId
                }, {
                    success: function (status) {
                        $ionicLoading.hide();
                        $cordovaToast.show('Status Updated Successfully', 'short', 'center')
                            .then(function (success) {
                                // success
                            }, function (error) {
                                // error
                            });
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        $rootScope.showAlert(error);
                    }
                });
            }
        }
        $scope.getProfile = function () {
            if ($localstorage.getObject('DoctorProfile') === null) {} //$ionicLoading.show();


            Parse.Cloud.run('GetProfile', {
                UserObjectId: $rootScope.user.id,
            }, {
                success: function (results) {
                    $ionicLoading.hide();
                    if (results != undefined && results != null) {
                        $scope.PatientListfn(results.id);
                        $scope.PatientRequestCount(results.id)
                        $scope.callhistoryfn(results.id);
                        $scope.chatListfn(results.id);
                        $rootScope.user.ProfileId = results.id;
                        //$rootScope.UserProfile = results;
                        $rootScope.UserName = results.get('FullName')
                        $scope.FirstName = results.get('FirstName');
                        $scope.LastName = (results.get('LastName') == undefined) ? '' : results.get('LastName');
                        if (typeof results.attributes.StatusPointer !== 'undefined' && results.attributes.StatusPointer != null)
                            $scope.Status.id = results.get('StatusPointer').id;
                        if (typeof results.attributes.ProfileImage === 'undefined') {
                            //console.log(results.get('ProfileImage'))
                            $rootScope.ProfileImage = "img/doctor_icon_default.png";
                        } else
                            $rootScope.ProfileImage = results.get('ProfileImage').url();

                        $localstorage.setObject('DoctorProfile', results);
                        $rootScope.UserProfile = $localstorage.getObject('DoctorProfile')
                        $scope.$apply();
                    }
                },
                error: function (error) {
                    $ionicLoading.hide();
                    if (error.code == 209)
                        $state.go('login');
                    //$rootScope.showAlert(error);
                }
            });
        }

        var currentUser = Parse.User.current();
        $rootScope.user = null;
        $rootScope.UserProfile = null;
        $rootScope.isLoggedIn = false;
        //console.log(currentUser)
        if (currentUser) {
            console.log(window.localStorage['isDoctor'])
            if (window.localStorage['isDoctor'] != undefined || window.localStorage['isPatient'] != undefined) {
                $rootScope.user = currentUser;
                $rootScope.isLoggedIn = true;
                $rootScope.isDoctor = window.localStorage['isDoctor'];
                $rootScope.isPatient = window.localStorage['isPatient'];
                if ($rootScope.isDoctor == 'true') {
                    console.log('isDoctor' + $rootScope.NetworkStatus)
                    if ($rootScope.NetworkStatus) {
                        $scope.StatusType = $localstorage.getObject('StatusType');
                        $scope.PatientList = $localstorage.getObject('DoctorPatientList');
                        $scope.ChatList = $localstorage.getObject('DoctorChatList');
                        $scope.calllist = $localstorage.getObject('Doctorcalllist');
                        $rootScope.UserProfile = $localstorage.getObject('DoctorProfile')
                        $scope.getProfile();
                        $scope.getStatusType();
                    } else {
                        $scope.StatusType = $localstorage.getObject('StatusType');
                        $scope.PatientList = $localstorage.getObject('DoctorPatientList');
                        $scope.ChatList = $localstorage.getObject('DoctorChatList');
                        $scope.calllist = $localstorage.getObject('Doctorcalllist');
                        $rootScope.UserProfile = $localstorage.getObject('DoctorProfile')
                    }

                } else if ($rootScope.isPatient == 'true') {
                    console.log('isPatient')
                    $state.go('tab.PatientHome');
                }
            } else {
                Parse.User.logOut();
                $state.go('login');
            }
        } else {
            console.log('login')
            $state.go('login');
        }

        //$scope.getStatus();
        //ionicMaterialInk.displayEffect();
    })
    cbApp.controller('DrPatientHomeCtrl', function ($scope, $state, $ionicLoading, $ionicPopup, $ionicModal, $cordovaToast, $rootScope, $http, $ionicScrollDelegate, ionicMaterialInk) {
        $scope.selectedDiv = 'Call'
        $scope.showTabCantent = function (option) {
            $scope.selectedDiv = option; //'Client';
            $ionicScrollDelegate.scrollTop();
        }
        $scope.calllist = []
        $scope.PtDrProfile = [];
        results = $rootScope.PtData;
        $scope.PtDrProfile.id = results.id;
        $scope.PtDrProfile.FullName = results.FullName;
        $scope.PtDrProfile.ObjectId = results.UserObjectId;
        $scope.PtDrProfile.ProfileId = results.id;
        $scope.PtDrProfile.PriorityPatient = $rootScope.PtData.IsPriority; //attributes.IsPriority;
        $scope.PtDrProfile.IsArchive = $rootScope.PtData.IsArchive;
        $scope.PtDrProfile.ProfileImage = results.ProfileImage;
        $scope.PtDrProfile.chatThreadId = $rootScope.PtData.chatThreadId;
        $scope.PtDrProfile.UserObjectId = results.UserObjectId;
        $scope.PtDrProfile.isMute = results.DoctorMuted
            /*  console.log($rootScope.user.ProfileId);
              console.log('PriorityPatient ' + $scope.PtDrProfile.PriorityPatient)
              if (results.ProfileImage != undefined)
                  $scope.PtDrProfile.ProfileImage = results.ProfileImage;
              else
                  $scope.PtDrProfile.ProfileImage = "img/doctor_icon_default.png";*/
            /* $scope.DrProfile.BriefOverview = results.get('BriefOverview');
             $scope.DrProfile.Qualification = results.get('Qualification');
             $scope.DrProfile.Speciality = results.get('Speciality');
             $scope.DrProfile.Clinic = results.get('Clinic');*/
            // 
        $scope.chat = function (item) {
            $rootScope.chatUser = item //results.get('DoctorProfileObjectId');
                //console.log($rootScope.chatUser.get('PatientProfileObjectId').get('ProfileImage').url())

        }
        $scope.AddWallet = function (amt) {
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {
                $ionicLoading.show();
                Parse.Cloud.run('AddWallet', {
                    FromUserId: $rootScope.user.id,
                    ToUserId: results.UserObjectId,
                    Amount: amt,
                    FromProfileObjectId: $rootScope.user.ProfileId,
                    ToProfileObjectId: results.id
                }, {
                    success: function (status) {
                        // debugger;
                        $ionicLoading.hide();
                        $scope.Recharge = false;
                        $scope.Rechargebtn = false;
                        $scope.closeRechargeModal();
                        $scope.rechargeAmount.amount = '';
                        //$rootScope.showAlert('Amount added successfully in Patient wallet');
                        // te Profile table updated successfully
                        $cordovaToast.show("Health Credits added successfully to Patient's Account", 'short', 'center')
                            .then(function (success) {
                                // success
                            }, function (error) {
                                // error
                            });
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        $rootScope.showAlert(error.message);
                        // debugger;
                        // error
                    }
                });
            }
        }
        $scope.SetArchivePatient = function (amt) {
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {
                //$ionicLoading.show();
                Parse.Cloud.run('SetArchivePatient', {
                    //DocProfileId: $rootScope.user.ProfileId,
                    IsArchive: amt,
                    PatientUserId: $scope.PtDrProfile.ObjectId
                }, {
                    success: function (status) {
                        $ionicLoading.hide();
                        var msg = '';
                        if (status.get('IsArchive')) {
                            msg = 'Patient ' + $scope.PtDrProfile.FullName + ' is blocked successfully'
                        } else {
                            msg = 'Patient ' + $scope.PtDrProfile.FullName + ' is unblocked successfully'

                        }
                        $cordovaToast.show(msg, 'short', 'center')
                            .then(function (success) {
                                // success
                            }, function (error) {
                                // error
                            });
                        // $rootScope.showAlert('patient priority updated');
                        // te Profile table updated successfully
                    },
                    error: function (error) {
                        console.log(error)
                        $ionicLoading.hide();
                        $rootScope.showAlert(error.message);
                        // debugger;
                        // error
                    }
                });
            }
        }
        $scope.SetPatientPriority = function (amt) {
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {
                //$ionicLoading.show();
                Parse.Cloud.run('SetPatientPriority', {
                    DocProfileId: $rootScope.user.ProfileId,
                    IsPriority: amt,
                    PatProfileId: results.id
                }, {
                    success: function (status) {
                        $ionicLoading.hide();
                        // $rootScope.showAlert('patient priority updated');
                        // te Profile table updated successfully
                        if (status.get('IsPriority')) {
                            $cordovaToast.show('Patient ' + $scope.PtDrProfile.FullName + ' is a priority patient now', 'short', 'center')
                        } else {
                            $cordovaToast.show('Patient ' + $scope.PtDrProfile.FullName + ' is not a priority patient now', 'short', 'center')
                        }
                    },
                    error: function (error) {
                        console.log(error)
                        $ionicLoading.hide();
                        $rootScope.showAlert(error.message);
                        // debugger;
                        // error
                    }
                });
            }
        }
        $scope.Recharge = false;
        $scope.Rechargebtn = false;
        $scope.rechargeAmount = [];
        $scope.showaddmoney = function () {
            $scope.Recharge = true;
            $scope.Rechargebtn = true;
            $scope.openRechargeModal();
        }
        $ionicModal.fromTemplateUrl('recharge-Patient.html', {
            scope: $scope,
            animation: 'fade-in-up'
        }).then(function (modal) {
            $scope.rechargeModal = modal;
        });
        $scope.openRechargeModal = function () {
            if ($rootScope.NetworkStatus)
                $scope.rechargeModal.show();
            else
                $cordovaToast.show('no connection available', 'short', 'center')

        };
        $scope.closeRechargeModal = function () {
            $scope.rechargeModal.hide();
        };
        //Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function () {
            $scope.rechargeModal.remove();
        });
        $scope.showaddMoneyfn = function () {
            if ($scope.rechargeAmount.amount != undefined || $scope.rechargeAmount.amount != null) {
                var confirmPopup = $ionicPopup.confirm({
                    title: 'CureBooth',
                    template: 'Add Health Credits ' + $scope.rechargeAmount.amount + ' ?'
                });
                confirmPopup.then(function (res) {
                    if (res) {
                        $scope.AddWallet($scope.rechargeAmount.amount);
                    }
                });
            } else {
                $rootScope.showAlert('Please enter Health Credits.');
            }
            // An elaborate, custom popup
            /*           var myPopup = $ionicPopup.show({
                           template: '<input type="number" ng-model="data.wifi">',
                           title: 'Enter amount to add in Patient Wallet',
                           scope: $scope,
                           buttons: [
                               {
                                   text: 'Cancel'
                               },
                               {
                                   text: '<b>Add</b>',
                                   type: 'button-positive',
                                   onTap: function (e) {
                                       if (!$scope.data.wifi) {
                                           //don't allow the user to close unless he enters wifi password
                                           e.preventDefault();
                                       } else {
                                           $scope.AddWallet($scope.data.wifi);
                                           return $scope.data.wifi;
                                       }
                                   }
                 }
               ]
                       });

                       myPopup.then(function (res) {
                           console.log('Tapped!', res);
                       });*/
        };
    })
    cbApp.controller('ProfileCtrl', function ($scope, $state, $ionicPopup, $ionicLoading, $rootScope, $http, $ionicModal, $cordovaCamera, $ionicScrollDelegate, ionicMaterialInk, $cordovaToast, $filter, $localstorage) {
        //console.log(Parse.User.current().getEmail())
        $scope.profile = {};
        $scope.clinic = {};
        $scope.DaysList = [];
        $scope.TokenStatus = TokenStatus;
        var weekday = [
    'S',
    'M',
    'T',
    'W',
    'T',
    'F',
    'S'
];
        var now = new Date();
        $scope.currentDay = now.getDay();
        for (i = 0; i < 7; i++) {
            //var dayName = weekday[(now.getDay() + i) % 7];
            var temp = {
                name: weekday[(now.getDay() + i) % 7],
                id: (now.getDay() + i) % 7
            }

            $scope.DaysList.push(temp)
        }
        $scope.changeDay = function (id) {
            $scope.currentDay = id;
            $scope.getTokenList();
        }
        $scope.selectedDiv = 'Profile';
        $scope.showTabCantent = function (option) {
            $scope.selectedDiv = option; //'Client';
            $ionicScrollDelegate.scrollTop();
        }
        $scope.GetDoctorSpeciality = function () {
            if (!$rootScope.NetworkStatus) {} else {
                if ($localstorage.getObject('DoctorSpeciality') === null) {} //$ionicLoading.show();
                Parse.Cloud.run('GetDocSpeciality', {
                    //SearchString: search
                }, {
                    success: function (status) {

                        if (status.length > 0) {
                            $scope.searchList = [];
                            $localstorage.setObject('DoctorSpeciality', status)
                            $scope.DoctorSpeciality = $localstorage.getObject('DoctorSpeciality')
                                //$scope.searchList = JSON.stringify(status);
                            $scope.$apply;
                        }

                        $ionicLoading.hide();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                    }
                });
            }
        };
        $scope.AdminList = {};
        $scope.AdminListfn = function () {
            Parse.Cloud.run('AdminDoctorList', {
                PatientProfileId: $rootScope.user.id
            }, {
                success: function (status) {
                    $ionicLoading.hide();
                    $scope.DoctorList1 = [];
                    if (status.length > 0) {
                        for (i = 0; i < status.length; i++) {
                            if (status[i].get('user1') == $rootScope.user.id) {


                            } else {
                                var temp = {
                                    Name: status[i].attributes.profile1.attributes.FullName,
                                    id: status[i].attributes.profile1.id
                                }
                                $scope.DoctorList1.push(temp);

                            }
                            console.log($scope.DoctorList1);
                        }
                        //
                        $localstorage.setObject('AdminDoctorList', $scope.DoctorList1);
                        $scope.AdminList = $localstorage.getObject('AdminDoctorList');
                        $scope.$apply();
                    } else {
                        $localstorage.setObject('AdminDoctorList', null);
                        $scope.AdminList = $localstorage.getObject('AdminDoctorList');
                        $scope.$apply();
                    }
                    // te Profile table updated successfully
                },
                error: function (error) {
                    // debugger;
                    // error
                }
            });
        }
        $scope.expandview = false
        $scope.expandIcon = false;
        $scope.expand = function (id) {
            //if ($rootScope.NetworkStatus) {
            $scope.expandview = id;
            $scope.expandIcon = id;
            /*
                $scope.profile.SpecialityId = $filter('filter')($scope.DoctorSpeciality, $scope.profile.Speciality)[0].objectId
                console.log($scope.profile.SpecialityId)*/
            $scope.$apply;
            /*} else
                $cordovaToast.show('no connection available', 'short', 'center')*/
        }
        $scope.editable = false;
        $scope.edit = function (id) {
            if ($rootScope.NetworkStatus) {
                $scope.editable = id;
                $scope.expandview = !id;
                $scope.profile.SpecialityId = $filter('filter')($scope.DoctorSpeciality, $scope.profile.Speciality)[0].objectId
                console.log($scope.profile.SpecialityId)
                $scope.$apply;
            } else
                $cordovaToast.show('no connection available', 'short', 'center')
        }
        $scope.expandClinicview = false
        $scope.expandClinicIcon = false;
        $scope.expandClinic = function (id) {
            //if ($rootScope.NetworkStatus) {
            $scope.expandClinicview = id;
            $scope.expandClinicIcon = id;
            /*
                $scope.profile.SpecialityId = $filter('filter')($scope.DoctorSpeciality, $scope.profile.Speciality)[0].objectId
                console.log($scope.profile.SpecialityId)*/
            $scope.$apply;
            /*} else
                $cordovaToast.show('no connection available', 'short', 'center')*/
        }
        $scope.addNewClinic = false;
        $scope.AddNewClinicFn = function (id) {
            $scope.addNewClinic = id;
        }
        $scope.Cliniceditable = false;
        $scope.clinicDetails = function (id) {
                $rootScope.ClinicData = id;
                $state.go('tab.ClinicDetails')
            }
            // Appointment list
        $scope.DummyToken = false;
        $scope.TokenList = [];
        $scope.DummyTokenList = [];
        $scope.Patient = {};
        $scope.getTokenList = function (id) {
                if (id != null)
                    $scope.currentClinicId = id;
                else
                //$cordovaToast.show('Please choose clinic', 'short', 'center')
                if ($localstorage.getObject('DoctorProfile') === null) {}
                $ionicLoading.show();
                Parse.Cloud.run('TokenList', {
                    DoctorProfile: $scope.UserProfile.id,
                    ClinicId: $scope.currentClinicId,
                    DayId: $scope.currentDay
                }, {
                    success: function (results) {
                        $ionicLoading.hide();
                        if (results.length > 0) {
                            $scope.TokenList = [];
                            $scope.DummyTokenList = [];
                            var ln = results.length;
                            var changeseating = 0;
                            for (i = 0; i < ln; i++) {
                                var tmp1 = '';
                                var oldseating;
                                if (i == 0)
                                    oldseating = results[i].get('TokenId').replace(/[0-9]/g, '');
                                else
                                    oldseating = results[i - 1].get('TokenId').replace(/[0-9]/g, '');
                                if (results[i].get('TokenType') == "1") {
                                    var tmp = {};
                                    console.log(results[i].get('TokenId').replace(/[0-9]/g, '') + ' == ' + oldseating)
                                    if (results[i].get('TokenId').replace(/[0-9]/g, '') == oldseating) {
                                        changeseating = i;
                                        if (i + 2 < ln) {
                                            tmp1 = results[i].get('Start') + ' - ' + results[i + 2].get('End');
                                        } else {
                                            tmp1 = results[i].get('Start') + ' - ' + results[ln - 1].get('End');
                                        }
                                        tmp = {
                                                timestamp: tmp1,
                                                id: results[i].id,
                                                ClinicId: results[i].get('ClinicId'),
                                                End: results[i].get('End'),
                                                EndTime: results[i].attributes.EndTime.toString(),
                                                ScheduleId: results[i].get('ScheduleId'),
                                                Start: results[i].get('Start'),
                                                StartTime: results[i].attributes.StartTime.toString(),
                                                Status: results[i].get('Status').get('Name'),
                                                StatusId: results[i].get('Status').id,
                                                TokenId: results[i].get('TokenId'),
                                                StartTime: results[i].get('StartTime').iso
                                            }
                                            //$scope.TokenList.push(tmp);
                                    } else {
                                        var last;
                                        var lnt
                                        if (changeseating + 1 % 2 == 0) {
                                            last = changeseating - 2;
                                        } else {
                                            last = changeseating - 1;
                                        }
                                        if ($scope.TokenList.length % 2 == 0) {
                                            lnt = $scope.TokenList.length - 2;
                                        } else {
                                            lnt = $scope.TokenList.length - 1;
                                        }
                                        console.log($scope.TokenList);
                                        console.log($scope.TokenList.length);

                                        console.log($scope.TokenList[lnt].timestamp);
                                        $scope.TokenList[lnt].timestamp = results[last].get('Start') + ' - ' + results[i - 1].get('End');
                                        if (i % 3 != 0) {
                                            if (i % 3 == 1) {
                                                var tmp = {
                                                     id:"1100"+oldseating,
                                                    ScheduleId: "",
                                                    Start: ""
                                                }
                                                var tmp1 = { id:"1111"+oldseating,ScheduleId: "",
                                                    Start: ""}
                                                $scope.TokenList.push(tmp);
                                                $scope.TokenList.push(tmp1);
                                            } else
                                                $scope.TokenList.push(tmp);
                                        }


                                        tmp = {};
                                        tmp1 = ''
                                        if (i + 2 < ln) {
                                            tmp1 = results[i].get('Start') + ' - ' + results[i + 2].get('End');
                                        } else {
                                            tmp1 = results[i].get('Start') + ' - ' + results[ln - 1].get('End');
                                        }
                                        tmp = {
                                            timestamp: tmp1,
                                            id: results[i].id,
                                            ClinicId: results[i].get('ClinicId'),
                                            End: results[i].get('End'),
                                            EndTime: results[i].attributes.EndTime.toString(),
                                            ScheduleId: results[i].get('ScheduleId'),
                                            Start: results[i].get('Start'),
                                            StartTime: results[i].attributes.StartTime.toString(), //.get('StartTime').ios,
                                            Status: results[i].get('Status').get('Name'),
                                            StatusId: results[i].get('Status').id,
                                            TokenId: results[i].get('TokenId'),
                                            StartTime: results[i].get('StartTime').iso
                                        }

                                    }

                                    $scope.TokenList.push(tmp);

                                } else {
                                    $scope.DummyToken = true;
                                    var tmp = {
                                        // timestamp: tmp,
                                        id: results[i].id,
                                        ClinicId: results[i].get('ClinicId'),
                                        End: results[i].get('End'),
                                        EndTime: results[i].attributes.EndTime.toString(),
                                        ScheduleId: results[i].get('ScheduleId'),
                                        Start: results[i].get('Start'),
                                        StartTime: results[i].attributes.StartTime.toString(), //.get('StartTime').ios,
                                        Status: results[i].get('Status').get('Name'),
                                        StatusId: results[i].get('Status').id,
                                        TokenId: results[i].get('TokenId')
                                    }
                                    $scope.DummyTokenList.push(tmp);
                                }
                            }
                            //console.log($scope.TokenList)

                        } else {
                            //$scope.profile.result = null;
                            $scope.DummyTokenList = [];
                            $scope.TokenList = [];
                        }
                        $scope.$apply();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        $scope.DummyTokenList = [];
                        $scope.TokenList = [];
                        if (error.code == 209)
                            $state.go('login');
                        //$rootScope.showAlert(error);
                    }
                });
            }
            // book function to check wheter token booked for not
        $scope.book = function (item) {
            $scope.bookingTokenId = item.id;
            if (item.StatusId == $scope.TokenStatus.Booked) {

                var alertPopup = $ionicPopup.confirm({
                    title: 'CureBooth',
                    template: 'Do you like to cancel the appointment ?'
                });
                alertPopup.then(function (res) {
                    if (res) {
                        $ionicLoading.show();
                        Parse.Cloud.run('CancelAppointment', {
                            TokenId: $scope.bookingTokenId
                        }, {
                            success: function (results) {
                                $ionicLoading.hide();
                                $scope.getTokenList();
                                // te Profile table updated successfully
                            },
                            error: function (error) {
                                var alertPopup = $ionicPopup.confirm({
                                    title: 'CureBooth',
                                    template: error.message
                                });
                                alertPopup.then(function (res) {
                                        $scope.closeBookAppoitmentModal();
                                    })
                                    //$rootScope.showAlert(error.message);

                                $ionicLoading.hide();
                                // error
                            }
                        });
                    } else {
                        console.log('You are not sure');
                    }
                });

            } else if (item.StatusId == $scope.TokenStatus.Available)
                if ($scope.currentDay == now.getDay() && item.Start.split(":")[0] < now.getHours()) {
                    $rootScope.showAlert("Appointment Token has expired. Please book another Appointment token.")
                } else {
                    $scope.openBookAppoitmentModal();

                }
        }

        // search patient to book for appoitment
        $scope.PatientSearchResult = false;
        $scope.PatientSearchList = [];
        $scope.search = [];
        $scope.PatientSearch = function (search) {
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {
                if (search.toString().length != 10) {
                    $rootScope.showAlert('Please enter 10 digit mobile number');
                } else {
                    //$ionicLoading.show();
                    Parse.Cloud.run('PatientSearch', {
                        Phone: search
                    }, {
                        success: function (data) {
                            console.log(data.length)
                            $ionicLoading.hide();
                            if (data != undefined) {
                                $scope.PatientSearchList = data;
                                $scope.addnewPatient = false;
                                $scope.PatientSearchResult = true;
                            } else {
                                $scope.PatientSearchList = [];
                                $scope.addnewPatient = true;
                                $scope.PatientSearchResult = false;
                                $scope.Patient.phone = search;
                            }
                            $scope.$apply;
                        },
                        error: function (error) {
                            console.log(error)
                            $scope.PatientList = null
                            $scope.PatientSearchResult = false;
                            $scope.addnewPatient = true;
                            $scope.Patient.phone = search;
                            $ionicLoading.hide();
                        }
                    });
                }
            }
        };
        // validate new patient request
        $scope.Validate = function () {
            var ErrorArr = new Array();
            if (typeof $scope.user === 'undefined' || $scope.user === null)
                throw ' entered';
            else {
                if (typeof $scope.Patient.Name === 'undefined' || $scope.Patient.Name === null) {
                    $rootScope.showAlert('Please enter some valid value into - Name.');
                    ErrorArr.push('Client \'FirstName\' is required.');
                }
                /* else if (typeof $scope.Patient.email === 'undefined' || $scope.Patient.email === null) {
                                    $rootScope.showAlert('Please enter some valid value into - Email');
                                    ErrorArr.push('Client \'Surname\' is required.');
                                }*/
                else if (typeof $scope.Patient.phone === 'undefined' || $scope.Patient.phone === null) {
                    $rootScope.showAlert("Please enter Phone number");
                    ErrorArr.push('Client \'Date of Birth\' is required.');
                }

            }
            if (ErrorArr.length > 0)
                return false;

            return true; //_isValidVM
        }

        $scope.AddNewPatient = function () {
                if (!$rootScope.NetworkStatus) {
                    $cordovaToast.show('no connection available', 'short', 'center')
                } else {
                    if ($scope.Validate()) {
                        $ionicLoading.show();
                        Parse.Cloud.run('AddNewPatient', {
                            DoctorUserId: $rootScope.user.id,
                            DoctorProfileId: $rootScope.UserProfile.objectId,
                            Phone: $scope.Patient.phone,
                            Name: $scope.Patient.Name,
                            Email: $scope.Patient.email,
                        }, {
                            success: function (results) {
                                $ionicLoading.hide();
                                if (results != undefined) {
                                    $scope.Patient = []
                                    var item = {}
                                    item.objectId = results.id;
                                    $scope.addnewPatient = false;
                                    $scope.BookAppointment(item);
                                    /*var alertPopup = $ionicPopup.alert({
                                        title: 'CureBooth',
                                        template: 'Patient added successfully'
                                    });
                                    alertPopup.then(function (res) {
                                        $state.go('tab.home');
                                    });*/

                                    //$scope.closeBookAppoitmentModal();
                                    //$scope.FriendRequest = results;
                                } else {
                                    $scope.FriendRequest = null;
                                }

                                // te Profile table updated successfully
                            },
                            error: function (error) {
                                $rootScope.showAlert(error.message);
                                $ionicLoading.hide();
                                // error
                            }
                        });
                    }
                }
            }
            // BookAppointment
        $scope.BookAppointment = function (item) {
            if (!$rootScope.NetworkStatus) {} else {
                Parse.Cloud.run('BookAppointment', {
                    TokenId: $scope.bookingTokenId,
                    BookedProfile: item.objectId
                }, {
                    success: function (status) {
                        if (status != undefined) {
                            $scope.getTokenList();
                            $scope.closeBookAppoitmentModal();
                            $scope.$apply;
                        }
                        $ionicLoading.hide();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        $scope.closeBookAppoitmentModal();
                        $rootScope.showAlert(error.message);
                    }
                });
            }
        };

        // get user profile
        $scope.getProfile = function () {
                if ($localstorage.getObject('DoctorProfile') === null) {} //$ionicLoading.show();


                Parse.Cloud.run('GetProfile', {
                    UserObjectId: $rootScope.user.id,
                }, {
                    success: function (results) {
                        $ionicLoading.hide();
                        if (results != undefined && results != null) {
                            $scope.ClinicList(results.id);
                            $rootScope.profile.result = results;
                            $scope.UserProfile = results;
                            $scope.profile.FullName = results.get('FullName');
                            $scope.profile.BriefOverview = results.get('BriefOverview');
                            $scope.profile.Qualification = results.get('Qualification');
                            $scope.profile.Speciality = results.get('Specialist').get('Speciality');
                            $scope.profile.Clinic = results.get('Clinic');
                            if (typeof results.attributes.ProfileImage === 'undefined') {
                                //console.log(results.get('ProfileImage'))
                                $rootScope.ProfileImage = "img/doctor_icon_default.png";
                            } else
                                $rootScope.ProfileImage = results.get('ProfileImage').url();
                            if (typeof results.attributes.PinCode === 'undefined') {
                                $scope.profile.PinCode = $rootScope.PinCode
                            } else
                                $scope.profile.PinCode = results.get('PinCode');
                            $scope.profile.CbNo = results.get('UserPointer').get('ExotelNumber');
                            $scope.profile.MciNo = results.get('MciNo');
                            $scope.$apply();
                        } else {
                            $scope.profile.result = null;
                            $scope.profile.PinCode = $rootScope.PinCode

                        }
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        if (error.code == 209)
                            $state.go('login');
                        //$rootScope.showAlert(error);
                    }
                });
            }
            // Addschedule
        $scope.AddSchedule = function (id) {
                $rootScope.ScheduleClinic = id;
                $state.go('tab.AddClinicSchedule');
            }
            //CancelSchedule
        $scope.cancelSchedule = function (id) {
                //$rootScope.ScheduleClinic = id;
                $state.go('tab.CancelSchedule');
            }
            //manage queue
        $scope.manageQueue = function (id) {
                //$rootScope.ScheduleClinic = id;
                $state.go('tab.QueueManagement');
            }
            // update profile
        $scope.updateProfile = function () {
            //$ionicLoading.show();
            if (!$rootScope.NetworkStatus) {} else {
                $ionicLoading.show();
                if ($scope.profile.PinCode.length < 4) {
                    $rootScope.showAlert("Please enter Pincode");
                    //ErrorArr.push('Client \'Date of Birth\' is required.');
                } else {
                    Parse.Cloud.run('UpdateProfile', {
                        ProfileObjectId: $scope.UserProfile.id,
                        FullName: $scope.profile.FullName,
                        /*LastName: $scope.profile.LastName,*/
                        BriefOverview: $scope.profile.BriefOverview,
                        SpecialityId: $scope.profile.SpecialityId,
                        Qualification: $scope.profile.Qualification,
                        Clinic: $scope.profile.Clinic,
                        Pincode: $scope.profile.PinCode,
                        MciNo: $scope.profile.MciNo,
                        LatLong: $rootScope.Currentlatlng
                    }, {
                        success: function (results) {
                            $ionicLoading.hide();
                            if (results) {
                                $scope.searchList = [];
                                $scope.edit(true);
                                $cordovaToast.show('Profile Updated Successfully', 'short', 'center')
                                $rootScope.profile.result = results;
                                $scope.UserProfile = results;
                                $scope.profile.FullName = results.get('FullName');
                                $scope.profile.BriefOverview = results.get('BriefOverview');
                                $scope.profile.Qualification = results.get('Qualification');
                                $scope.profile.Speciality = results.get('Specialist').get('Speciality');
                                $scope.profile.Clinic = results.get('Clinic');
                                if (typeof results.attributes.ProfileImage === 'undefined') {
                                    $rootScope.ProfileImage = "img/doctor_icon_default.png";
                                } else
                                    $rootScope.ProfileImage = results.get('ProfileImage').url();
                                if (typeof results.attributes.PinCode === 'undefined') {
                                    $scope.profile.PinCode = $rootScope.PinCode
                                } else
                                    $scope.profile.PinCode = results.get('PinCode');

                                $scope.profile.MciNo = results.get('MciNo');
                            } else {
                                $scope.profile.result = null;
                                $scope.profile.PinCode = $rootScope.PinCode

                            }
                            $scope.$apply;
                        },
                        error: function (error) {
                            $ionicLoading.hide();
                        }
                    });
                }
            }
            /*var point = $scope.UserProfile;
            point.set("FullName", $scope.profile.FirstName + ' ' + $scope.profile.LastName)
            point.set("FirstName", $scope.profile.FirstName);
            point.set("LastName", $scope.profile.LastName);
            point.set("BriefOverview", $scope.profile.BriefOverview);
            point.set("Qualification", $scope.profile.Qualification);
            point.set("Speciality", $scope.profile.Speciality);
            point.set("Clinic", $scope.profile.Clinic);
            point.set("PinCode", $scope.profile.PinCode);
            point.set("LatLong", $scope.profile.Clinic);
            point.set("UserTypeObjectId", doctype);

            var Specility = new Parse.Object.extend('DoctorSpeciality');
            var docSpec = new Speciality();
            Speciality.id = $scope.profile.Speciality;
            point.set("Specialist", docSpec);
            // Save
            point.save(null, {
                success: function (point) {
                    $ionicLoading.hide();
                    $scope.editable = true;
                    $rootScope.showAlert('Profile Saved successfully.');
                    // Saved successfully.
                },
                error: function (point, error) {
                    $ionicLoading.hide();
                    $rootScope.showAlert(error);
                }
            });*/
        }
        $scope.ClinicListdata = [];
        $scope.ClinicList = function (id) {
            if (!$rootScope.NetworkStatus) {} else {
                Parse.Cloud.run('ClinicList', {
                    DoctorProfile: id
                }, {
                    success: function (status) {
                        if (status.length > 0) {
                            var ln = status.length;
                            for (i = 0; i < ln; i++) {
                                var tmp = {
                                    Name: status[i].get('Name'),
                                    Admin: status[i].get('AdminProfile').id,
                                    AdminName: status[i].get('AdminProfile').get('FullName'),
                                    AdminNumber: status[i].get('AdminProfile').get('Phone'),
                                    Address: status[i].get('Address'),
                                    Pincode: parseInt(status[i].get('Pincode')),
                                    id: status[i].id,
                                    city: status[i].get('city'),
                                    area: status[i].get('Area'),
                                    DoctorProfileId: status[i].get('DoctorProfileId'),
                                    DoctorUserId: status[i].get('DoctorUserId'),
                                    ConsultationFee: status[i].get('ConsultationFee')

                                }
                                $scope.ClinicListdata.push(tmp)
                            }
                            //$scope.ClinicListdata = status;
                            $scope.$apply;
                        }
                        $ionicLoading.hide();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                    }
                });
            }
        };
        $scope.ValidateAddClinic = function () {
            var ErrorArr = new Array();
            if (typeof $scope.user === 'undefined' || $scope.user === null)
                throw ' entered';
            else {
                if (typeof $scope.clinic.Name === 'undefined' || $scope.Patient.Name === null) {
                    $rootScope.showAlert('Please enter some valid value into - Name.');
                    ErrorArr.push('Name is required.');
                } else if ($scope.clinic.Admin === undefined || $scope.clinic.Admin === null) {
                    $rootScope.showAlert("Please choose Admin");
                    ErrorArr.push('area');
                } else if (typeof $scope.clinic.Address === 'undefined' || $scope.clinic.Address === null) {
                    $rootScope.showAlert('Please enter some valid value into - Address');
                    ErrorArr.push('address');
                } else if ($scope.clinic.area === undefined || $scope.clinic.area === null) {
                    $rootScope.showAlert("Please enter area");
                    ErrorArr.push('area');
                } else if (typeof $scope.clinic.city === 'undefined' || $scope.clinic.city === null) {
                    $rootScope.showAlert('Please enter some valid value into - city');
                    ErrorArr.push('address');
                } else if (typeof $scope.clinic.Pincode === 'undefined' || $scope.clinic.Pincode === null || $scope.clinic.Pincode.length < 4) {
                    $rootScope.showAlert("Please enter pincode");
                    ErrorArr.push('pincode');
                } else if (typeof $scope.clinic.ConsultationFee === 'undefined' || $scope.clinic.ConsultationFee === null) {
                    $rootScope.showAlert("Please enter Consultation Fee");
                    ErrorArr.push('ConsultationFee');
                }



            }
            if (ErrorArr.length > 0)
                return false;

            return true; //_isValidVM
        }
        $scope.AddClinic = function () {
            if (!$rootScope.NetworkStatus) {} else {

                if ($scope.ValidateAddClinic()) {


                    $ionicLoading.show();
                    Parse.Cloud.run('AddClinic', {
                        DoctorProfile: $scope.UserProfile.id,
                        Name: $scope.clinic.Name,
                        Address: $scope.clinic.Address,
                        Area: $scope.clinic.area,
                        City: $scope.clinic.city,
                        AdminProfile: $scope.clinic.Admin,
                        Pincode: $scope.clinic.Pincode.toString(),
                        ConsultationFee: $scope.clinic.ConsultationFee
                    }, {
                        success: function (results) {
                            $ionicLoading.hide();
                            if (results) {
                                $scope.ClinicData = [];
                                var tmp = {
                                    Name: results.get('Name'),
                                    Admin: results.get('AdminProfile').id,
                                    Address: results.get('Address'),
                                    Pincode: parseInt(results.get('Pincode')),
                                    id: results.id,
                                    city: results.get('city'),
                                    area: results.get('Area'),
                                    DoctorProfileId: results.get('DoctorProfileId'),
                                    DoctorUserId: results.get('DoctorUserId'),
                                    ConsultationFee: results.get('ConsultationFee')

                                }
                                $scope.ClinicData.push(tmp)
                                console.log($scope.ClinicData)
                                $rootScope.ClinicData = tmp;
                                $rootScope.ClinicScheduleData = "";
                                $scope.AddSchedule(results.id);
                                $cordovaToast.show('Clinic added successfully', 'short', 'center')

                                $scope.$apply;
                            }
                        },
                        error: function (error) {
                            $ionicLoading.hide();
                            $rootScope.showAlert(error.message);
                        }
                    });
                }

            }
        }

        $scope.imageData = "";


        // Upload Image
        $scope.uploadImg = function () {
            $ionicLoading.show();
            var ProfileParse = $scope.UserProfile;
            var objProfileLink = $scope.UserProfile;
            if ($scope.imageData != "") {
                var parseFile = new Parse.File("ProfileImg.jpg", {
                    base64: $scope.imageData
                });
                objProfileLink.set("ProfileImage", parseFile);
                console.log('create profile link');
                objProfileLink.save(null, {
                    success: function (employee) {
                        $ionicLoading.hide();
                        var alertPopup = $ionicPopup.alert({
                            title: 'CureBooth',
                            cssClass: 'balance',
                            template: 'Profile image updated successfully.'
                        });
                        alertPopup.then(function (res) {
                            $scope.closeProfileModal();
                        });
                        //$rootScope.showAlert('Profile image updated successfully.');
                    },
                    error: function (employee, error) {
                        $ionicLoading.hide();
                        //alert('error:' + error.message.toString());
                    }
                });
            }
        }
        document.addEventListener("deviceready", function () {
            $scope.takePhoto = function (data) {
                if (data == 1)
                    $scope.cemera();
                else
                    $scope.gallery();
            }
        }, false);
        $scope.cemera = function () {
            var options = {
                quality: 65,
                destinationType: Camera.DestinationType.DATA_URL,
                sourceType: Camera.PictureSourceType.CAMERA,
                allowEdit: true,
                encodingType: Camera.EncodingType.JPEG,
                targetWidth: 100,
                targetHeight: 100,
                popoverOptions: CameraPopoverOptions,
                saveToPhotoAlbum: false,
                correctOrientation: true
            };

            $cordovaCamera.getPicture(options).then(function (imageData) {
                $scope.imageData = imageData;
                $scope.ProfileImage = "data:image/jpeg;base64," + imageData;
            }, function (err) {
                // error
            });

        }
        $scope.gallery = function () {
            var options = {
                quality: 65,
                destinationType: Camera.DestinationType.DATA_URL,
                sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
                allowEdit: true,
                encodingType: Camera.EncodingType.JPEG,
                targetWidth: 100,
                targetHeight: 100,
                popoverOptions: CameraPopoverOptions,
                saveToPhotoAlbum: false,
                correctOrientation: true
            };

            $cordovaCamera.getPicture(options).then(function (imageData) {
                $scope.imageData = imageData;
                $scope.ProfileImage = "data:image/jpeg;base64," + imageData;
            }, function (err) {
                // error
            });

        }
        $ionicModal.fromTemplateUrl('profile-img.html', {
            scope: $scope,
            animation: 'fade-in-up'
        }).then(function (modal) {
            $scope.profilemodal = modal;
        });
        $scope.openProfileModal = function () {
            if ($rootScope.NetworkStatus)
                $scope.profilemodal.show();
            else
                $cordovaToast.show('no connection available', 'short', 'center')

        };
        $scope.closeProfileModal = function () {
            $scope.profilemodal.hide();
        };
        $ionicModal.fromTemplateUrl('bookAppoitment.html', {
            scope: $scope,
            animation: 'fade-in-up'
        }).then(function (modal) {
            $scope.bookAppoitmentModal = modal;
        });
        $scope.openBookAppoitmentModal = function () {
            if ($rootScope.NetworkStatus) {
                $scope.PatientSearchResult = false;
                $scope.PatientSearchList = [];
                $scope.search = [];
                $scope.bookAppoitmentModal.show();
            } else
                $cordovaToast.show('no connection available', 'short', 'center')

        };
        $scope.closeBookAppoitmentModal = function () {
            $scope.PatientSearchList = [];
            $scope.bookAppoitmentModal.hide();
            //$scope.openBookAppoitmentModal.hide();
        };
        $ionicModal.fromTemplateUrl('AddClinic.html', {
            scope: $scope,
            animation: 'fade-in-up'
        }).then(function (modal) {
            $scope.AddClinicModal = modal;
        });
        $scope.openAddClinicModal = function () {
            if ($rootScope.NetworkStatus) {
                $scope.AddClinicModal.show();
            } else
                $cordovaToast.show('no connection available', 'short', 'center')

        };
        $scope.closeAddClinicModal = function () {
            $scope.clinic = [];
            $scope.PatientSearchList = [];
            $scope.AddClinicModal.hide();
            //$scope.openBookAppoitmentModal.hide();
        };
        //Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function () {
            $scope.profilemodal.remove();
            $scope.AddClinicModal.remove();
            $scope.bookAppoitmentModal.remove();
        });
        console.log('$rootScope.NetworkStatus: ' + $rootScope.NetworkStatus);
        if ($rootScope.NetworkStatus) {
            $scope.profile = $rootScope.UserProfile;
            $scope.profile.CbNo = $scope.profile.UserPointer.ExotelNumber;
            $scope.profile.Speciality = $scope.profile.Specialist.Speciality;
            $scope.getProfile();
            $scope.GetDoctorSpeciality();
            $scope.AdminListfn();
        } else {
            $scope.profile = $rootScope.UserProfile;
            $scope.profile.CbNo = $scope.profile.UserPointer.ExotelNumber;
            $scope.profile.Speciality = $scope.profile.Specialist.Speciality;
        }
        //ionicMaterialInk.displayEffect();
    })
    cbApp.controller('SettingCtrl', function ($scope, $state, $ionicLoading, $rootScope, $http, $ionicPopup, $localstorage, $cordovaToast, $ionicHistory, $localstorage, ionicMaterialInk) {
        //console.log(Parse.User.current().getEmail())
        $scope.setting = {};
        $scope.chargesSetting = [];
        $scope.editable = false;
        $scope.ConsultSetting = false;
        $scope.changePassword = false;

        $scope.edit = function (id) {
            if ($rootScope.NetworkStatus) {
                $scope.editable = id;
                $scope.ConsultSetting = false;
                $scope.changePassword = false;
            } else
                $cordovaToast.show('no connection available', 'short', 'center')

        }

        $scope.ConsultSettingfn = function (param) {
            if ($rootScope.NetworkStatus) {
                $scope.ConsultSetting = param;
                $scope.editable = false;
                $scope.changePassword = false;
            } else
                $cordovaToast.show('no connection available', 'short', 'center')
        }

        $scope.getProfile = function () {
                //$ionicLoading.show();
                Parse.Cloud.run('GetProfile', {
                    UserObjectId: $rootScope.user.id,
                }, {
                    success: function (results) {
                        $ionicLoading.hide();
                        if (results != undefined && results != null) {
                            $scope.Profile = results;
                            $scope.chargesSetting.FirstMin = $scope.Profile.get('FirstMin');
                            $scope.chargesSetting.ChargesPerMin = $scope.Profile.get('ChargesPerMin');
                            $scope.chargesSetting.IsOfflineCall = $scope.Profile.get('IsOfflineCall');
                            $scope.chargesSetting.ForMins = $scope.Profile.get('ForMins');
                            $scope.chargesSetting.IsAnyOneCall = $scope.Profile.get('IsAnyoneCall');
                            if ($scope.chargesSetting.IsAnyOneCall)
                                $scope.chargesSetting.IsConnectedCall = false;
                            else
                                $scope.chargesSetting.IsConnectedCall = true;
                            if ($scope.chargesSetting.ForMins != 0)
                                $scope.chargesSetting.NA = true
                            else
                                $scope.chargesSetting.NA = false
                        }
                    },
                    error: function (error) {
                        $rootScope.handleParseError(error);
                        $ionicLoading.hide();
                    }
                });
            }
            //GetShareMsg
        $scope.GetShareMsg = function () {
            //$ionicLoading.show();
            Parse.Cloud.run('GetShareMsg', {
                //UserObjectId: $rootScope.user.id,
            }, {
                success: function (results) {
                    $ionicLoading.hide();
                    $scope.GetShareMsgdata = results;
                    console.log($scope.GetShareMsgdata[0])
                    console.log($scope.GetShareMsgdata[1])
                },
                error: function (error) {
                    $ionicLoading.hide();
                }
            });
        }
        $scope.shareApp = function () {
            var options = {
                message: 'share this', // not supported on some apps (Facebook, Instagram)
                subject: 'the subject', // fi. for email
                files: ['', ''], // an array of filenames either locally or remotely
                url: 'https://www.website.com/foo/#bar?a=b',
                chooserTitle: 'Pick an app' // Android only, you can override the default share sheet title
            }

            /*var onSuccess = function (result) {
                console.log("Share completed? " + result.completed); // On Android apps mostly return false even while it's true
                console.log("Shared to app: " + result.app); // On Android result.app is currently empty. On iOS it's empty when sharing is cancelled (result.completed=false)
            }

            var onError = function (msg) {
                console.log("Sharing failed with message: " + msg);
            }

            window.plugins.socialsharing.share(options, onSuccess, onError);*/
            window.plugins.socialsharing.share($scope.GetShareMsgdata[0], 'CureBooth', null, $scope.GetShareMsgdata[1]);
        }
        $scope.getSetting = function () {
            if ($localstorage.getObject('Doctorsetting') === null) {} //$ionicLoading.show();
            console.log('getSetting')
            var query = new Parse.Query('DocAccountSetting');
            query.equalTo('UserObjectId', $rootScope.user.id);
            query.find({
                success: function (results) {
                    $ionicLoading.hide();
                    if (results.length > 0) {
                        $scope.setting = results[0];
                        /*   $scope.setting.TimeFee = results[0].get('TimeFee');
                           $scope.setting.Charges = results[0].get('Charges');
                           $scope.setting.Amount = results[0].get('Amount');*/
                        //$scope.setting.BankName = results[0].get('BankName');
                        //$scope.setting.AccountNumber = results[0].get('AccountNumber');
                        //$scope.setting.BankCode = results[0].get('BankCode');
                        $localstorage.setObject('Doctorsetting', $scope.setting);
                        $scope.setting = $localstorage.getObject('Doctorsetting');
                        $scope.setting.AccountNumber = parseInt($scope.setting.AccountNumber)
                            ////alert(results.get('LastName'));
                    } else {
                        $scope.setting.result = null;
                    }
                },
                error: function (error) {
                    $ionicLoading.hide();

                    ////alert("Error: " + error.code + " " + error.message);
                }
            });
        }


        $scope.NotApplicable = function () {
            console.log($scope.chargesSetting.NA)
            if (!$scope.chargesSetting.NA) {
                $scope.chargesSetting.FirstMin = 0;
                $scope.chargesSetting.ForMins = 0;
            }
        }
        $scope.PatientAccess = function (id) {
            $scope.chargesSetting.IsConnectedCall = !id;
        }
        $scope.PatientAccess1 = function (id) {
            $scope.chargesSetting.IsAnyOneCall = !id;
        }
        $scope.SetDoctorCharges = function () {
            if ($scope.chargesSetting.NA) {
                if (typeof $scope.chargesSetting.FirstMin === 'undefined' || $scope.chargesSetting.FirstMin === null || $scope.chargesSetting.FirstMin < 0) {
                    $rootScope.showAlert("Please Enter Minimum Charges")
                    return false;
                }
                /*else if (typeof $scope.chargesSetting.ForMins === 'undefined' || $scope.chargesSetting.ForMins === null || $scope.chargesSetting.FirstMin <= 0) {
                                   $rootScope.showAlert("Please Enter For Minutes")
                                   return false;
                               }*/
            }
            if (typeof $scope.chargesSetting.ChargesPerMin === 'undefined' || $scope.chargesSetting.ChargesPerMin === null || $scope.chargesSetting.ChargesPerMin < 0) {
                $rootScope.showAlert("Please Enter Charges Per Minute");
                return false;
            } else {
                var confirmPopup = $ionicPopup.confirm({
                    title: 'CureBooth',
                    template: 'Are you sure ! <br/> You want to update your charges?'
                });

                confirmPopup.then(function (res) {
                    if (res) {
                        $ionicLoading.show();
                        Parse.Cloud.run('SetDoctorCharges', {
                            ProfileId: $scope.Profile.id,
                            FirstMin: $scope.chargesSetting.FirstMin,
                            PerMin: $scope.chargesSetting.ChargesPerMin,
                            OfflineCall: $scope.chargesSetting.IsOfflineCall,
                            IsAnyOneCall: $scope.chargesSetting.IsAnyOneCall
                        }, {
                            success: function (results) {
                                $ionicLoading.hide();
                                $scope.ConsultSetting = false;
                            },
                            error: function (error) {
                                $ionicLoading.hide();
                                $scope.getProfile();
                                //$rootScope.showAlert(error.message);
                                $cordovaToast.show(error.message, 'short', 'center')
                            }
                        });
                    }
                })
            }
        };

        $scope.changePass = function (param) {
            if ($rootScope.NetworkStatus) {
                $scope.changePassword = param;
                $scope.editable = false;
                $scope.ConsultSetting = false;
            } else
                $cordovaToast.show('no connection available', 'short', 'center')
        }
        $scope.changePasword = [];
        $scope.UpdatePassword = function () {
            if (typeof $scope.changePasword.Password === 'undefined' || $scope.changePasword.Password === null) {
                $rootScope.showAlert("Please enter Current Password");
                return false;
            } else if (typeof $scope.changePasword.NewPassword === 'undefined' || $scope.changePasword.NewPassword === null) {
                $rootScope.showAlert("Please enter New Password");
                return false;
            } else if (typeof $scope.changePasword.cNewPassword === 'undefined' || $scope.changePasword.cNewPassword === null) {
                $rootScope.showAlert("Please enter Confirm New Password");
                return false;
            } else if ($scope.changePasword.NewPassword != $scope.changePasword.cNewPassword) {
                $rootScope.showAlert("Please enter same New Password and Confirm New Password");
                return false;
            } else if ($scope.changePasword.Password == $scope.changePasword.cNewPassword) {
                $rootScope.showAlert("Please enter same New Password and Confirm New Password");
                return false;
            } else {
                var confirmPopup = $ionicPopup.confirm({
                    title: 'CureBooth',
                    template: 'Are you sure ! <br/> You want to change your password?'
                });

                confirmPopup.then(function (res) {
                    if (res) {
                        $ionicLoading.show();
                        //console.log(Parse.User.getSessionToken())
                        Parse.Cloud.run('UpdatePassword', {
                            //username: $scope.Profile.get('Phone'),
                            oldPassword: $scope.changePasword.Password,
                            newPassword: $scope.changePasword.NewPassword
                        }, {
                            success: function (results) {
                                $ionicLoading.hide();
                                $scope.changePassword = false;
                                var alertPopup = $ionicPopup.alert({
                                    title: 'CureBooth',
                                    cssClass: 'balance',
                                    template: 'Password changed successfully !<br> Please login again'
                                });
                                alertPopup.then(function (res) {
                                    $scope.getProfile();
                                });
                            },
                            error: function (error) {
                                console.log(error)
                                $ionicLoading.hide();
                                $rootScope.showAlert(error.message);
                            }
                        });

                    }
                });
            }

        };
        $scope.logOutfn = function () {
            $ionicLoading.show();
            Parse.User.logOut()
            var currentUser = Parse.User.current();
            console.log('CurrentUser : ' + currentUser)
            if (currentUser) {
                $rootScope.user = currentUser;
                $rootScope.isLoggedIn = true;
                $state.go('tab.Home');
            } else {
                $localstorage.clearAll();
                $ionicHistory.clearCache();
                $ionicHistory.clearHistory()
                $ionicLoading.hide();
                $rootScope.isDoctor = '';
                window.localStorage['isDoctor'] = '';
                $rootScope.isPatient = '';
                window.localStorage['isPatient'] = '';
                $state.go("login");
                navigator.app.exitApp();

            }
        };
        //$scope.ForgotPassword();
        $scope.saveSetting = function () {
            $ionicLoading.show();
            if ($scope.setting.result != null) {
                var point = $scope.setting.result[0];
                point.set("BankName", $scope.setting.BankName);
                point.set("AccountNumber", $scope.setting.AccountNumber);
                point.set("BankCode", $scope.setting.BankCode);
                point.set("UserObjectId", $rootScope.user.id);
                point.set("ProfileObjectId", $scope.Profile.id);
                point.save(null, {
                    success: function (point) {
                        $ionicLoading.hide();
                        $rootScope.showAlert('Setting Saved successfully.');
                        $scope.editable = false;
                        // Saved successfully.
                    },
                    error: function (point, error) {
                        $ionicLoading.hide();
                        $rootScope.showAlert(error);

                        // The save failed.
                        // error is a Parse.Error with an error code and description.
                    }
                });
            } else {

                var Point = Parse.Object.extend("DocAccountSetting");
                var point = new Point();
                point.set("BankName", $scope.setting.BankName);
                point.set("AccountNumber", $scope.setting.AccountNumber);
                point.set("BankCode", $scope.setting.BankCode);
                point.set("UserObjectId", $rootScope.user.id);
                point.set("ProfileObjectId", $scope.Profile.id);
                /*  point.set("Charges", $scope.setting.Charges);
                  point.set("Amount", $scope.setting.Amount);*/
                //point.set("usertypeobjectid", $scope.profile.usertypeobjectid);
                // Save
                point.save(null, {
                    success: function (point) {
                        $ionicLoading.hide();
                        $rootScope.showAlert('Setting Created successfully.');
                        $scope.editable = false;
                        // Saved successfully.
                    },
                    error: function (point, error) {
                        $ionicLoading.hide();
                        $rootScope.showAlert(error);

                        // The save failed.
                        // error is a Parse.Error with an error code and description.
                    }
                });
            }
        }
        if ($rootScope.NetworkStatus) {
            $scope.chargesSetting = $rootScope.UserProfile;
            $scope.chargesSetting.IsConnectedCall = !$scope.chargesSetting.IsAnyOneCall;
            $scope.setting = $localstorage.getObject('Doctorsetting');
            $scope.setting.AccountNumber = parseInt($scope.setting.AccountNumber)
            $scope.getSetting();
            $scope.getProfile();
            $scope.GetShareMsg();
        } else {
            $scope.chargesSetting = $rootScope.UserProfile;
            $scope.chargesSetting.IsConnectedCall = !$scope.chargesSetting.IsAnyOneCall;
            $scope.setting = $localstorage.getObject('Doctorsetting');
            $scope.setting.AccountNumber = parseInt($scope.setting.AccountNumber)
        }
        //ionicMaterialInk.displayEffect();
    })

    cbApp.controller('WalletStatmntCtrl', function ($scope, $state, $ionicLoading, $rootScope, $http, ionicMaterialInk) {
        $scope.TransactionHistory = [];
        $scope.GetTransactionHistory = function () {
            //$ionicLoading.show();
            Parse.Cloud.run('GetTransactionHistory', {
                UserProfileId: $rootScope.user.ProfileId
            }, {
                success: function (results) {
                    $ionicLoading.hide();
                    $scope.TransactionHistory = results;
                    /*for (i = 0; i < results.length; i++) {
                        $scope.TransactionHistory = results;
                        if ($scope.PtDrProfile.ObjectId == results[i].UserInfo.id)
                            $scope.calllist.push(results[i]);
                    }*/
                },
                error: function (error) {
                    $ionicLoading.hide();
                    // error
                }
            });
        };
        $scope.GetTransactionHistory();
        //ionicMaterialInk.displayEffect();
    })
    cbApp.controller('AddPatientCtrl', function ($scope, $state, $ionicLoading, $rootScope, $http, $ionicScrollDelegate, $ionicPopup, $cordovaToast, ionicMaterialInk) {
        $scope.Patient = {};
        $scope.selectedDiv = 'AddPatient'
        $scope.showTabCantent = function (option) {
            $scope.selectedDiv = option; //'Client';
            $ionicScrollDelegate.scrollTop();
        }
        $scope.Validate = function () {
            var ErrorArr = new Array();
            if (typeof $scope.user === 'undefined' || $scope.user === null)
                throw ' entered';
            else {
                if (typeof $scope.Patient.Name === 'undefined' || $scope.Patient.Name === null) {
                    $rootScope.showAlert('Please enter some valid value into - Name.');
                    ErrorArr.push('Client \'FirstName\' is required.');
                }
                /* else if (typeof $scope.Patient.email === 'undefined' || $scope.Patient.email === null) {
                                    $rootScope.showAlert('Please enter some valid value into - Email');
                                    ErrorArr.push('Client \'Surname\' is required.');
                                }*/
                else if (typeof $scope.Patient.phone === 'undefined' || $scope.Patient.phone === null) {
                    $rootScope.showAlert("Please enter Phone number");
                    ErrorArr.push('Client \'Date of Birth\' is required.');
                }

            }
            if (ErrorArr.length > 0)
                return false;

            return true; //_isValidVM
        }
        $scope.AddNewPatient = function () {
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {
                if ($scope.Validate()) {
                    $ionicLoading.show();
                    Parse.Cloud.run('AddNewPatient', {
                        DoctorUserId: $rootScope.user.id,
                        DoctorProfileId: $rootScope.UserProfile.objectId,
                        Phone: $scope.Patient.phone,
                        Name: $scope.Patient.Name,
                        Email: $scope.Patient.email,
                    }, {
                        success: function (results) {
                            $ionicLoading.hide();
                            if (results != undefined) {
                                $scope.Patient = []
                                var alertPopup = $ionicPopup.alert({
                                    title: 'CureBooth',
                                    template: 'Patient added successfully'
                                });
                                alertPopup.then(function (res) {
                                    $state.go('tab.home');
                                });
                                //$scope.FriendRequest = results;
                            } else {
                                $scope.FriendRequest = null;
                            }

                            // te Profile table updated successfully
                        },
                        error: function (error) {
                            $rootScope.showAlert(error.message);
                            $ionicLoading.hide();
                            // error
                        }
                    });
                }
            }
        }
        $scope.AddPatient = function (Phoneno) {
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {
                $ionicLoading.show();
                Parse.Cloud.run('AddPatient', {
                    DoctorUserId: $rootScope.user.id,
                    DoctorProfileId: $rootScope.UserProfile.objectId,
                    PatientUserId: Phoneno.UserObjectId,
                    PatientProfileId: Phoneno.objectId,
                    DoctorName: $rootScope.UserProfile.FullName
                }, {
                    success: function (results) {
                        $ionicLoading.hide();
                        $scope.PatientList = [];
                        if (results != undefined) {
                            $scope.PatientList = [];
                            var alertPopup = $ionicPopup.alert({
                                title: 'CureBooth',
                                template: 'Patient added successfully'
                            });
                            alertPopup.then(function (res) {
                                $state.go('tab.home');
                            });
                            //$rootScope.showAlert("Patient added successfully");
                            //$scope.FriendRequest = results;
                        } else {
                            $scope.FriendRequest = null;
                        }

                        // te Profile table updated successfully
                    },
                    error: function (error) {
                        $rootScope.showAlert(error.message);
                        $ionicLoading.hide();
                        // error
                    }
                });
            }
        }
        $scope.addnewPatient = false;
        $scope.PatientSearchResult = false;
        $scope.PatientSearchList = [];
        $scope.PatientSearch = function (search) {
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {
                if (search.toString().length != 10) {
                    $rootScope.showAlert('Please enter 10 digit mobile number');
                } else {
                    //$ionicLoading.show();
                    Parse.Cloud.run('PatientSearch', {
                        Phone: search
                    }, {
                        success: function (data) {
                            console.log(data.length)
                            $ionicLoading.hide();
                            if (data != undefined) {
                                $scope.PatientSearchList = data;
                                $scope.addnewPatient = false;
                                $scope.PatientSearchResult = true;
                            } else {
                                $scope.PatientSearchList = [];
                                $scope.addnewPatient = true;
                                $scope.PatientSearchResult = false;
                                $scope.Patient.phone = search;
                            }
                            $scope.$apply;
                        },
                        error: function (error) {
                            console.log(error)
                            $scope.PatientList = null
                            $scope.PatientSearchResult = false;
                            $scope.addnewPatient = true;
                            $scope.Patient.phone = search;
                            $ionicLoading.hide();
                        }
                    });
                }
            }
        };
        // Dr Patient list
        $scope.PatientListfn = function () {
            Parse.Cloud.run('PatientList', {
                DoctorProfileId: $rootScope.user.ProfileId,
                Archived: true //'PRpuqlmbtC'
            }, {
                success: function (status) {
                    if (status.length > 0) {
                        //console.log(JSON.stringify(status.object.toJSON()))
                        $scope.PatientList = [];
                        $scope.PatientList = status
                        $scope.$apply();
                    } else
                        $scope.PatientList = ''
                },
                error: function (error) {
                    // debugger;
                    // error
                }
            });
        }
        $scope.unlock = function (data) {
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {
                //$ionicLoading.show();
                Parse.Cloud.run('SetArchivePatient', {
                    //DocProfileId: $rootScope.user.ProfileId,
                    IsArchive: false,
                    PatientUserId: data.attributes.PatientUserObjectId
                }, {
                    success: function (status) {
                        $ionicLoading.hide();
                        $scope.PatientListfn();
                        $cordovaToast.show('Patient unblocked successfully', 'short', 'center')
                            // $rootScope.showAlert('patient priority updated');
                            // te Profile table updated successfully
                    },
                    error: function (error) {
                        console.log(error)
                        $ionicLoading.hide();
                        $rootScope.showAlert(error.message);
                        // debugger;
                        // error
                    }
                });
            }
        }

        $scope.FriendRequest = {};
        $scope.FriendRequestfn = function () {
            //$ionicLoading.show();
            Parse.Cloud.run('PatientRequestList', {
                ProfileId: $rootScope.user.ProfileId
            }, {
                success: function (results) {
                    $ionicLoading.hide();
                    if (results.length > 0) {
                        $scope.FriendRequest = results;
                    } else {
                        $scope.FriendRequest = null;
                    }
                },
                error: function (error) {
                    $ionicLoading.hide();
                    // error
                }
            });
        }
        $scope.GetDoctorAction = {};
        $scope.approvePatient;
        $scope.rejectPatient;
        $scope.GetDoctorAction = function () {
            //$ionicLoading.show();
            Parse.Cloud.run('GetDoctorAction', {
                //ProfileId: $rootScope.user.ProfileId
            }, {
                success: function (results) {
                    $ionicLoading.hide();
                    if (results.length > 0) {
                        for (i = 0; i < results.length; i++) {
                            if (results[i].get('actionName') == 'Rejected')
                                $scope.rejectPatient = results[i].id;
                            else if (results[i].get('actionName') == 'Approved')
                                $scope.approvePatient = results[i].id;
                        }
                        $scope.GetDoctorAction = results;
                    } else {
                        //$scope.FriendRequest = null;
                    }
                },
                error: function (error) {
                    $ionicLoading.hide();
                    // error
                }
            });
        }

        $scope.accept = function (data) {
            var confirmPopup = $ionicPopup.confirm({
                title: 'CureBooth',
                template: 'Accept  patient request?'
            });

            confirmPopup.then(function (res) {
                if (res) {
                    $ionicLoading.show();
                    Parse.Cloud.run('PatientConnectAction', {
                        ActionId: $scope.approvePatient,
                        ProfileLInkId: data
                    }, {
                        success: function (results) {
                            $ionicLoading.hide();
                            /* if (results.length > 0) {*/
                            $rootScope.showAlert("Patient Request Accepted Successfully");
                            //$scope.GetDoctorAction = results;
                            $scope.FriendRequestfn();
                            /* } else {
                                 $scope.FriendRequest = null;
                             }*/
                        },
                        error: function (error) {
                            $ionicLoading.hide();
                            $rootScope.showAlert(error.message);
                        }
                    })
                } else {
                    console.log('You are not sure');
                }
            });

        }
        $scope.reject = function (data) {
            var confirmPopup = $ionicPopup.confirm({
                title: 'CureBooth',
                template: 'Reject patient request?'
            });

            confirmPopup.then(function (res) {
                if (res) {
                    //$ionicLoading.show();
                    Parse.Cloud.run('PatientConnectAction', {
                        ActionId: $scope.rejectPatient,
                        ProfileLInkId: data
                    }, {
                        success: function (results) {
                            $ionicLoading.hide();
                            /* if (results.length > 0) {*/
                            //$cordovaToast.show('Doctor followed Successfully', 'short', 'center')
                            $rootScope.showAlert("Patient Request Rejected Successfully");
                            //$scope.GetDoctorAction = results;
                            $scope.FriendRequestfn();
                            /* } else {
                                 $scope.FriendRequest = null;
                             }*/
                        },
                        error: function (error) {
                            $ionicLoading.hide();
                            $rootScope.showAlert(error.message);
                        }
                    })
                } else {
                    console.log('You are not sure');
                }
            });
        }
        if ($rootScope.NetworkStatus) {
            $scope.PatientListfn();
            $scope.GetDoctorAction();
            $scope.FriendRequestfn();
        } else {}

        //ionicMaterialInk.displayEffect();
    })