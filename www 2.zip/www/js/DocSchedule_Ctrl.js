    cbApp.controller('AddClinicSchedule', function ($scope, $state, $ionicLoading, $rootScope, $http, $ionicPopup, $localstorage, $ionicHistory, $localstorage, ionicMaterialInk, $cordovaToast) {
        $scope.schedule = [];
        $scope.days = [];
        $scope.secondSeating = false;
        $scope.thirdSeating = false;
        if ($rootScope.ClinicScheduleData) {
            var ln = $rootScope.ClinicScheduleData.length;

            for (i = 0; i < ln; i++) {
                switch ($rootScope.ClinicScheduleData[i].Day) {
                case "Sunday":
                    if ($rootScope.ClinicScheduleData[i].schedule.length > 0)
                        $scope.days.Sun = true;
                    for (j = 0; j < $rootScope.ClinicScheduleData[i].schedule.length; j++) {
                        if ($rootScope.ClinicScheduleData[i].schedule[j].SlotId == "A") {
                            $scope.schedule.TokenDuration = $rootScope.ClinicScheduleData[i].schedule[j].TokenDuration
                            $scope.schedule.Start1 = $rootScope.ClinicScheduleData[i].schedule[j].start1
                            $scope.schedule.End1 = $rootScope.ClinicScheduleData[i].schedule[j].end1
                        } else if ($rootScope.ClinicScheduleData[i].schedule[j].SlotId == "B") {
                            $scope.secondSeating = true;
                            $scope.schedule.TokenDuration = $rootScope.ClinicScheduleData[i].schedule[j].TokenDuration
                            $scope.schedule.Start2 = $rootScope.ClinicScheduleData[i].schedule[j].start1
                            $scope.schedule.End2 = $rootScope.ClinicScheduleData[i].schedule[j].end1
                        } else if ($rootScope.ClinicScheduleData[i].schedule[j].SlotId == "C") {
                            $scope.thirdSeating = true;
                            $scope.schedule.TokenDuration = $rootScope.ClinicScheduleData[i].schedule[j].TokenDuration;
                            $scope.schedule.Start3 = $rootScope.ClinicScheduleData[i].schedule[j].ststart1
                            $scope.schedule.End3 = $rootScope.ClinicScheduleData[i].schedule[j].end1
                        }
                    }

                    break;
                case "Monday":
                    if ($rootScope.ClinicScheduleData[i].schedule.length > 0)
                        $scope.days.Mon = true;
                    for (j = 0; j < $rootScope.ClinicScheduleData[i].schedule.length; j++) {
                        if ($rootScope.ClinicScheduleData[i].schedule[j].SlotId == "A") {
                            $scope.schedule.TokenDuration = $rootScope.ClinicScheduleData[i].schedule[j].TokenDuration
                            $scope.schedule.Start1 = $rootScope.ClinicScheduleData[i].schedule[j].start1
                            $scope.schedule.End1 = $rootScope.ClinicScheduleData[i].schedule[j].end1
                        } else if ($rootScope.ClinicScheduleData[i].schedule[j].SlotId == "B") {
                            $scope.secondSeating = true;
                            $scope.schedule.TokenDuration = $rootScope.ClinicScheduleData[i].schedule[j].TokenDuration
                            $scope.schedule.Start2 = $rootScope.ClinicScheduleData[i].schedule[j].start1
                            $scope.schedule.End2 = $rootScope.ClinicScheduleData[i].schedule[j].end1
                        } else if ($rootScope.ClinicScheduleData[i].schedule[j].SlotId == "C") {
                            $scope.thirdSeating = true;
                            $scope.schedule.TokenDuration = $rootScope.ClinicScheduleData[i].schedule[j].TokenDuration;
                            $scope.schedule.Start3 = $rootScope.ClinicScheduleData[i].schedule[j].ststart1
                            $scope.schedule.End3 = $rootScope.ClinicScheduleData[i].schedule[j].end1
                        }
                    }
                    break;
                case "Tuesday":
                    if ($rootScope.ClinicScheduleData[i].schedule.length > 0)
                        $scope.days.Tue = true;
                    for (j = 0; j < $rootScope.ClinicScheduleData[i].schedule.length; j++) {
                        if ($rootScope.ClinicScheduleData[i].schedule[j].SlotId == "A") {
                            $scope.schedule.TokenDuration = $rootScope.ClinicScheduleData[i].schedule[j].TokenDuration
                            $scope.schedule.Start1 = $rootScope.ClinicScheduleData[i].schedule[j].start1
                            $scope.schedule.End1 = $rootScope.ClinicScheduleData[i].schedule[j].end1
                        } else if ($rootScope.ClinicScheduleData[i].schedule[j].SlotId == "B") {
                            $scope.secondSeating = true;
                            $scope.schedule.TokenDuration = $rootScope.ClinicScheduleData[i].schedule[j].TokenDuration
                            $scope.schedule.Start2 = $rootScope.ClinicScheduleData[i].schedule[j].start1
                            $scope.schedule.End2 = $rootScope.ClinicScheduleData[i].schedule[j].end1
                        } else if ($rootScope.ClinicScheduleData[i].schedule[j].SlotId == "C") {
                            $scope.thirdSeating = true;
                            $scope.schedule.TokenDuration = $rootScope.ClinicScheduleData[i].schedule[j].TokenDuration;
                            $scope.schedule.Start3 = $rootScope.ClinicScheduleData[i].schedule[j].ststart1
                            $scope.schedule.End3 = $rootScope.ClinicScheduleData[i].schedule[j].end1
                        }
                    }
                    break;
                case "Wednesday":
                    if ($rootScope.ClinicScheduleData[i].schedule.length > 0)
                        $scope.days.Wed = true;
                    for (j = 0; j < $rootScope.ClinicScheduleData[i].schedule.length; j++) {
                        if ($rootScope.ClinicScheduleData[i].schedule[j].SlotId == "A") {
                            $scope.schedule.TokenDuration = $rootScope.ClinicScheduleData[i].schedule[j].TokenDuration
                            $scope.schedule.Start1 = $rootScope.ClinicScheduleData[i].schedule[j].start1
                            $scope.schedule.End1 = $rootScope.ClinicScheduleData[i].schedule[j].end1
                        } else if ($rootScope.ClinicScheduleData[i].schedule[j].SlotId == "B") {
                            $scope.secondSeating = true;
                            $scope.schedule.TokenDuration = $rootScope.ClinicScheduleData[i].schedule[j].TokenDuration
                            $scope.schedule.Start2 = $rootScope.ClinicScheduleData[i].schedule[j].start1
                            $scope.schedule.End2 = $rootScope.ClinicScheduleData[i].schedule[j].end1
                        } else if ($rootScope.ClinicScheduleData[i].schedule[j].SlotId == "C") {
                            $scope.thirdSeating = true;
                            $scope.schedule.TokenDuration = $rootScope.ClinicScheduleData[i].schedule[j].TokenDuration;
                            $scope.schedule.Start3 = $rootScope.ClinicScheduleData[i].schedule[j].ststart1
                            $scope.schedule.End3 = $rootScope.ClinicScheduleData[i].schedule[j].end1
                        }
                    }
                    break;
                case "Thursday":
                    if ($rootScope.ClinicScheduleData[i].schedule.length > 0)
                        $scope.days.Thu = true;
                    for (j = 0; j < $rootScope.ClinicScheduleData[i].schedule.length; j++) {
                        if ($rootScope.ClinicScheduleData[i].schedule[j].SlotId == "A") {
                            $scope.schedule.TokenDuration = $rootScope.ClinicScheduleData[i].schedule[j].TokenDuration
                            $scope.schedule.Start1 = $rootScope.ClinicScheduleData[i].schedule[j].start1
                            $scope.schedule.End1 = $rootScope.ClinicScheduleData[i].schedule[j].end1
                        } else if ($rootScope.ClinicScheduleData[i].schedule[j].SlotId == "B") {
                            $scope.secondSeating = true;
                            $scope.schedule.TokenDuration = $rootScope.ClinicScheduleData[i].schedule[j].TokenDuration
                            $scope.schedule.Start2 = $rootScope.ClinicScheduleData[i].schedule[j].start1
                            $scope.schedule.End2 = $rootScope.ClinicScheduleData[i].schedule[j].end1
                        } else if ($rootScope.ClinicScheduleData[i].schedule[j].SlotId == "C") {
                            $scope.thirdSeating = true;
                            $scope.schedule.TokenDuration = $rootScope.ClinicScheduleData[i].schedule[j].TokenDuration;
                            $scope.schedule.Start3 = $rootScope.ClinicScheduleData[i].schedule[j].ststart1
                            $scope.schedule.End3 = $rootScope.ClinicScheduleData[i].schedule[j].end1
                        }
                    }
                    break;
                case "Friday":
                    if ($rootScope.ClinicScheduleData[i].schedule.length > 0)
                        $scope.days.Fri = true;
                    for (j = 0; j < $rootScope.ClinicScheduleData[i].schedule.length; j++) {
                        if ($rootScope.ClinicScheduleData[i].schedule[j].SlotId == "A") {
                            $scope.schedule.TokenDuration = $rootScope.ClinicScheduleData[i].schedule[j].TokenDuration
                            $scope.schedule.Start1 = $rootScope.ClinicScheduleData[i].schedule[j].start1
                            $scope.schedule.End1 = $rootScope.ClinicScheduleData[i].schedule[j].end1
                        } else if ($rootScope.ClinicScheduleData[i].schedule[j].SlotId == "B") {
                            $scope.secondSeating = true;
                            $scope.schedule.TokenDuration = $rootScope.ClinicScheduleData[i].schedule[j].TokenDuration
                            $scope.schedule.Start2 = $rootScope.ClinicScheduleData[i].schedule[j].start1
                            $scope.schedule.End2 = $rootScope.ClinicScheduleData[i].schedule[j].end1
                        } else if ($rootScope.ClinicScheduleData[i].schedule[j].SlotId == "C") {
                            $scope.thirdSeating = true;
                            $scope.schedule.TokenDuration = $rootScope.ClinicScheduleData[i].schedule[j].TokenDuration;
                            $scope.schedule.Start3 = $rootScope.ClinicScheduleData[i].schedule[j].ststart1
                            $scope.schedule.End3 = $rootScope.ClinicScheduleData[i].schedule[j].end1
                        }
                    }
                    break;
                case "Saturday":
                    if ($rootScope.ClinicScheduleData[i].schedule.length > 0)
                        $scope.days.Sat = true;
                    for (j = 0; j < $rootScope.ClinicScheduleData[i].schedule.length; j++) {
                        if ($rootScope.ClinicScheduleData[i].schedule[j].SlotId == "A") {
                            $scope.schedule.TokenDuration = $rootScope.ClinicScheduleData[i].schedule[j].TokenDuration
                            $scope.schedule.Start1 = $rootScope.ClinicScheduleData[i].schedule[j].start1
                            $scope.schedule.End1 = $rootScope.ClinicScheduleData[i].schedule[j].end1
                        } else if ($rootScope.ClinicScheduleData[i].schedule[j].SlotId == "B") {
                            $scope.secondSeating = true;
                            $scope.schedule.TokenDuration = $rootScope.ClinicScheduleData[i].schedule[j].TokenDuration
                            $scope.schedule.Start2 = $rootScope.ClinicScheduleData[i].schedule[j].start1
                            $scope.schedule.End2 = $rootScope.ClinicScheduleData[i].schedule[j].end1
                        } else if ($rootScope.ClinicScheduleData[i].schedule[j].SlotId == "C") {
                            $scope.thirdSeating = true;
                            $scope.schedule.TokenDuration = $rootScope.ClinicScheduleData[i].schedule[j].TokenDuration;
                            $scope.schedule.Start3 = $rootScope.ClinicScheduleData[i].schedule[j].ststart1
                            $scope.schedule.End3 = $rootScope.ClinicScheduleData[i].schedule[j].end1
                        }
                    }
                    break;

                }
            }
        } else {
            $scope.days = {
                Sun: true,
                Mon: true,
                Tue: true,
                Wed: true,
                Thu: true,
                Fri: true,
                Sat: true
            };
        }
        console.log($scope.schedule.Start1 + '-' + $scope.schedule.End1)
        $scope.DaysList = [{
            Name: "Sunday",
            id: 0
        }, {
            Name: "Monday",
            id: 1
        }, {
            Name: "Tuesday",
            id: 2
        }, {
            Name: "Wednesday",
            id: 3
        }, {
            Name: "Thursday",
            id: 4
        }, {
            Name: "Friday",
            id: 5
        }, {
            Name: "Saturday",
            id: 6
        }]
        $scope.timeSlot = [
            {
                Name: "OFF",
                id: "0000"
        }, {
                Name: "00:30 AM",
                id: "0:30"
        }, {
                Name: "1:00 AM",
                id: "1:00"
        }, {
                Name: "1:30 AM",
                id: "1:30"
        }, {
                Name: "2:00 AM",
                id: "2:00"
        }, {
                Name: "2:30 AM",
                id: "2:30"
        }, {
                Name: "3:00 AM",
                id: "3:00"
        }, {
                Name: "3:30 AM",
                id: "3:30 "
        }, {
                Name: "4:00 AM",
                id: "4:00"
        }, {
                Name: "4:30 AM",
                id: "4:30"
        }, {
                Name: "5:00 AM",
                id: "5:00"
        }, {
                Name: "5:30 AM",
                id: "5:30"
        }, {
                Name: "6:00 AM",
                id: "6:00"
        }, {
                Name: "6:30 AM",
                id: "6:30 "
        }, {
                Name: "7:00 AM",
                id: "7:00"
        }, {
                Name: "7:30 AM",
                id: "7:30"
        }, {
                Name: "8:00 AM",
                id: "8:00"
        }, {
                Name: "8:30 AM",
                id: "8:30"
        }, {
                Name: "9:00 AM",
                id: "9:00"
        }, {
                Name: "9:30 AM",
                id: "9:30"
        }, {
                Name: "10:00 AM",
                id: "10:00"
        }, {
                Name: "10:30 AM",
                id: "10:30"
        }, {
                Name: "11:00 AM",
                id: "11:00"
        }, {
                Name: "11:30 AM",
                id: "11:30 "
        }, {
                Name: "12:00 PM",
                id: "12:00"
        }, {
                Name: "12:30 PM",
                id: "12:30"
        }, {
                Name: "1:00 PM",
                id: "13:00"
        }, {
                Name: "1:30 PM",
                id: "13:30"
        }, {
                Name: "2:00 PM",
                id: "14:00"
        }, {
                Name: "2:30 PM",
                id: "14:30 "
        }, {
                Name: "3:00 PM",
                id: "15:00"
        }, {
                Name: "3:30 PM",
                id: "15:30"
        }, {
                Name: "4:00 PM",
                id: "16:00"
        }, {
                Name: "4:30 PM",
                id: "16:30"
        }, {
                Name: "5:00 PM",
                id: "17:00"
        }, {
                Name: "5:30 PM",
                id: "17:30 "
        }, {
                Name: "6:00 PM",
                id: "18:00"
        }, {
                Name: "6:30 PM",
                id: "18:30"
        }, {
                Name: "7:00 PM",
                id: "19:00"
        }, {
                Name: "7:30 PM",
                id: "19:30"
        }, {
                Name: "8:00 PM",
                id: "20:00"
        }, {
                Name: "8:30 PM",
                id: "20:30 "
        }, {
                Name: "9:00 PM",
                id: "21:00"
        }, {
                Name: "9:30 PM",
                id: "21:30"
        }, {
                Name: "10:00 PM",
                id: "22:00"
        }, {
                Name: "10:30 PM",
                id: "22:30"
        }, {
                Name: "11:00 PM",
                id: "23:00"
        }, {
                Name: "11:30 PM",
                id: "23:30 "
        }, {
                Name: "00:00 AM",
                id: "00:00"
        }]
        $scope.DaysList = [];
        var weekday = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
        var now = new Date();
        $scope.currentDay = [1, 2, 3, 4, 5, 6, 0];
        for (i = 0; i < 7; i++) {
            //var dayName = weekday[(now.getDay() + i) % 7];
            var temp = {
                name: weekday[(now.getDay() + i) % 7],
                id: (now.getDay() + i) % 7
            }

            $scope.DaysList.push(temp);
        }
        $scope.changeDay = function (id) {
            var index = $scope.currentDay.indexOf(id);
            if (index > -1) {
                $scope.currentDay.splice(index, 1);
                console.log($scope.currentDay)
            }
        }

        // Add new seating
        $scope.addNewSeating = function () {
            if ($scope.secondSeating)
                $scope.thirdSeating = true;
            else
                $scope.secondSeating = true
        }
        $scope.validateSchedule = function () {
            var ErrorArr = new Array();
            var selectedDays = "";
            if ($scope.days.Mon)
                selectedDays = 1 + ','
            if ($scope.days.Tue)
                selectedDays += 2 + ','
            if ($scope.days.Wed)
                selectedDays += 3 + ','
            if ($scope.days.Thu)
                selectedDays += 4 + ','
            if ($scope.days.Fri)
                selectedDays += 5 + ','
            if ($scope.days.Sat)
                selectedDays += 6 + ','
            if ($scope.days.Sun)
                selectedDays += 0

            if (selectedDays == "") {
                $cordovaToast.show('Please choose working days ', 'short', 'center')
                ErrorArr.push('number.');
            } else if ($scope.schedule.Start1 == "" || $scope.schedule.Start1 == undefined) {
                $cordovaToast.show('Please enter start time', 'short', 'center')
                ErrorArr.push('number.');
            } else if ($scope.schedule.End1 == "" || $scope.schedule.End1 == undefined) {
                $cordovaToast.show('Please enter end time', 'short', 'center')
                ErrorArr.push('number.');
            } else if (parseInt($scope.schedule.Start1) > parseInt($scope.schedule.End1)) {
                $cordovaToast.show('End time should be later start time', 'short', 'center')
                ErrorArr.push('number.');
            } else if ($scope.schedule.TokenDuration == "" || $scope.schedule.TokenDuration == undefined) {
                $cordovaToast.show('Please enter consultation time', 'short', 'center')
                ErrorArr.push('number.');

            }
            if ($scope.secondSeating) {
                if ($scope.schedule.Start2 == "" || $scope.schedule.Start2 == undefined) {
                    $cordovaToast.show('Please enter start time', 'short', 'center')
                    ErrorArr.push('number.');
                } else if ($scope.schedule.End2 == "" || $scope.schedule.End2 == undefined) {
                    $cordovaToast.show('Please enter end time', 'short', 'center')
                    ErrorArr.push('number.');
                } else if (parseInt($scope.schedule.Start2) > parseInt($scope.schedule.End2)) {
                    $cordovaToast.show('End time should be later start time', 'short', 'center')
                    ErrorArr.push('number.');
                }
            }
            if ($scope.thirdSeating) {
                if ($scope.schedule.Start3 == "" || $scope.schedule.Start3 == undefined) {
                    $cordovaToast.show('Please enter start time', 'short', 'center')
                    ErrorArr.push('number.');
                } else if ($scope.schedule.End3 == "" || $scope.schedule.End3 == undefined) {
                    $cordovaToast.show('Please enter end time', 'short', 'center')
                    ErrorArr.push('number.');
                } else if (parseInt($scope.schedule.Start3) > parseInt($scope.schedule.End3)) {
                    $cordovaToast.show('End time should be later start time', 'short', 'center')
                    ErrorArr.push('number.');
                }
            }

            if (ErrorArr.length > 0)
                return false;

            return true; //_isValidVM
        }
        $scope.SetDoctorSchedule = function () {

            var selectedDays = "";
            if ($scope.days.Mon)
                selectedDays = 1 + ','
            if ($scope.days.Tue)
                selectedDays += 2 + ','
            if ($scope.days.Wed)
                selectedDays += 3 + ','
            if ($scope.days.Thu)
                selectedDays += 4 + ','
            if ($scope.days.Fri)
                selectedDays += 5 + ','
            if ($scope.days.Sat)
                selectedDays += 6 + ','
            if ($scope.days.Sun)
                selectedDays += 0 + ','
            console.log(selectedDays);
            if ($scope.validateSchedule()) {
                $ionicLoading.show();
                Parse.Cloud.run('SetDoctorSchedule', {
                    DoctorProfile: $rootScope.user.ProfileId,
                    ClinicId: $rootScope.ScheduleClinic,
                    DayIds: selectedDays,
                    TokenDuration: $scope.schedule.TokenDuration,
                    Start1: $scope.schedule.Start1 == 0000 ? null : $scope.schedule.Start1,
                    End1: $scope.schedule.End1 == 0000 ? null : $scope.schedule.End1,
                    Start2: $scope.schedule.Start2 == 0000 ? null : $scope.schedule.Start2,
                    End2: $scope.schedule.End2 == 0000 ? null : $scope.schedule.End2,
                    Start3: $scope.schedule.Start3 == 0000 ? null : $scope.schedule.Start3,
                    End3: $scope.schedule.End3 == 0000 ? null : $scope.schedule.End3
                }, {
                    success: function (results) {
                        $ionicLoading.hide();
                        $scope.changePassword = false;
                        var alertPopup = $ionicPopup.alert({
                            title: 'CureBooth',
                            cssClass: 'balance',
                            template: 'Schedule saved Successfully'
                        });
                        alertPopup.then(function (res) {
                            //$scope.getSetting()
                            $state.go('tab.ClinicDetails')
                        });
                    },
                    error: function (error) {
                        console.log(error)
                        $ionicLoading.hide();
                        $rootScope.showAlert(error.message);
                    }
                });
            }

        };

        $scope.addSeating = function () {

        }

        // Intialize the controller 
        if ($rootScope.NetworkStatus) {} else {}
    });
    cbApp.controller('CancelSchedule', function ($scope, $state, $ionicLoading, $rootScope, $http, $ionicPopup, $localstorage, $ionicHistory, $localstorage, ionicMaterialInk) {
        $scope.ClinicListdata = [];
        $scope.ScheduleListdata = [];
        $scope.unavailability = false;
        $scope.docOnLeave = function () {
            $scope.unavailability = true;
        }
        $scope.ClinicList = function () {
            if (!$rootScope.NetworkStatus) {} else {
                Parse.Cloud.run('ClinicList', {
                    DoctorProfile: $rootScope.user.ProfileId
                }, {
                    success: function (status) {
                        if (status.length > 0) {
                            var ln = status.length;
                            for (i = 0; i < ln; i++) {
                                var tmp = {
                                    Name: status[i].get('Name'),
                                    Admin: status[i].get('AdminProfile').id,
                                    Address: status[i].get('Address'),
                                    PinCode: parseInt(status[i].get('Pincode')),
                                    id: status[i].id
                                }
                                $scope.ClinicListdata.push(tmp)
                            }
                            //$scope.ClinicListdata = status;
                            $scope.$apply;
                        }
                        $ionicLoading.hide();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                    }
                });
            }
        };
        $scope.clinic = [];
        $scope.SetDoctorUnavailable = function () {
            if (!$rootScope.NetworkStatus) {

            } else {
                if ($scope.clinic.clinicid === undefined || $scope.clinic.clinicid === null) {
                    $rootScope.showAlert("Please choose Clinic");
                } else if (typeof $scope.clinic.StartTime === 'undefined' || $scope.clinic.StartTime === null) {
                    $rootScope.showAlert("Please choose StartDate and StartTime");
                } else if (typeof $scope.clinic.EndTime === 'undefined' || $scope.clinic.EndTime === null) {
                    $rootScope.showAlert("Please choose EndDate and EndTime");
                } else if (new Date($scope.clinic.StartTime) > new Date($scope.clinic.EndTime)) {
                    $rootScope.showAlert("Please choose proper EndDate and EndTime");
                } else {
                    $ionicLoading.show();
                    console.log($scope.clinic.StartTime)
                    console.log($scope.clinic.EndTime)
                    Parse.Cloud.run('SetDoctorUnavailable', {
                        DoctorProfile: $rootScope.user.ProfileId,
                        ClinicId: $scope.clinic.clinicid,
                        StartTime: $scope.clinic.StartTime, //.toISOString(),
                        EndTime: $scope.clinic.EndTime //.toISOString()
                    }, {
                        success: function (status) {

                            var alertPopup = $ionicPopup.alert({
                                title: 'CureBooth',
                                cssClass: 'balance',
                                template: 'Unavailability saved Successfully'
                            });
                            alertPopup.then(function (res) {
                                $state.go('tab.profile')
                            });
                            $ionicLoading.hide();
                        },
                        error: function (error) {
                            $ionicLoading.hide();
                            $rootScope.showAlert(error.message);
                        }
                    });
                }
            }
        };
        $scope.ScheduleList = function (id) {
            if (!$rootScope.NetworkStatus) {

            } else {
                $scope.CurrentClinic = id;
                $ionicLoading.show();
                Parse.Cloud.run('ScheduleList', {
                    ClinicId: id
                }, {
                    success: function (status) {
                        if (status.length > 0) {
                            var ln = status.length;
                            $scope.ScheduleListdata = [];
                            for (i = 0; i < ln; i++) {
                                var tmp = {
                                    Name: status[i].get('Day') + ' - ' + status[i].get('SlotId') + ' (' + status[i].get('StartSlot') + ' - ' + status[i].get('EndSlot') + ')',
                                    Day: status[i].get('Day'),
                                    SlotId: status[i].get('SlotId'),
                                    EndSlot: status[i].get('EndSlot'),
                                    StartSlot: status[i].get('StartSlot'),
                                    TokenDuration: status[i].get('TokenDuration'),
                                    id: status[i].id
                                }
                                $scope.ScheduleListdata.push(tmp)
                            }
                            console.log($scope.ScheduleListdata);
                            $scope.$apply;
                        }
                        $ionicLoading.hide();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                    }
                });
            }
        };
        // Intialize the controller 
        if ($rootScope.NetworkStatus) {
            $scope.ClinicList();
        } else {

        }
    });
    cbApp.controller('QueueManagement', function ($scope, $state, $ionicLoading, $rootScope, $http, $ionicPopup, $localstorage, $ionicHistory, $localstorage, $ionicModal, $cordovaToast, ionicMaterialInk) {

        // Appointment list
        $scope.TokenList = [];
        $scope.Patient = {};
        $scope.ClinicListdata = [];
        $scope.ScheduleListdata = [];
        $scope.afterFinish = false;
        $scope.addTokenflag = false;
        // get current day
        var now = new Date();
        $scope.currentDay = now.getDay();
        // token status
        $scope.TokenStatus = TokenStatus;
        //change clinic
        $scope.changeClinic = function (id) {
                if (($localstorage.getObject($scope.CurrentSchedule) != null || $localstorage.getObject($scope.CurrentSchedule).length > 0) && $localstorage.getObject(id).Day == $scope.currentDay) {
                    $scope.CurrentToken = $localstorage.getObject(id).CurrentToken;
                    $scope.CurrentSchedule = $localstorage.getObject(id).CurrentSchedule;
                    $scope.CurrentTokenPatientName = $localstorage.getObject(id).CurrentTokenPatientName;
                    $scope.CurrentClinic = $localstorage.getObject(id).CurrentClinic;
                    $scope.clinicid = $scope.CurrentClinic;
                    $scope.ScheduleList($scope.CurrentClinic)
                    $scope.sceduleId = $scope.CurrentSchedule;
                    $scope.getTokenList($scope.sceduleId);
                } else {
                    $scope.CurrentToken = false;
                    $scope.ScheduleList(id)
                }

            }
            //chnage clinic
        $scope.changeSchedule = function (id) {
                if (($localstorage.getObject(id) != null || $localstorage.getObject(id).length > 0) && $localstorage.getObject(id).Day == $scope.currentDay) {
                    $scope.CurrentToken = $localstorage.getObject(id).CurrentToken;
                    $scope.CurrentSchedule = $localstorage.getObject(id).CurrentSchedule;
                    $scope.CurrentTokenPatientName = $localstorage.getObject(id).CurrentTokenPatientName;
                    $scope.CurrentClinic = $localstorage.getObject(id).CurrentClinic;
                    $scope.clinicid = $scope.CurrentClinic;
                    $scope.ScheduleList($scope.CurrentClinic)
                    $scope.sceduleId = $scope.CurrentSchedule;
                    $scope.getTokenList($scope.sceduleId);
                } else {
                    $scope.CurrentToken = false;
                    $scope.getTokenList(id)
                }
                //$scope.getTokenList(id)
            }
            //finish  seating
        $scope.FinishSeating = function () {
                var alertPopup = $ionicPopup.confirm({
                    title: 'CureBooth',
                    template: 'Do you like to finish the seating ?'
                });
                alertPopup.then(function (res) {
                    if (res) {
                        $ionicLoading.show();
                        Parse.Cloud.run('FinishSchedule', {
                            ScheduleId: $scope.CurrentSchedule,
                        }, {
                            success: function (results) {
                                $ionicLoading.hide();
                                $localstorage.removeItem($scope.CurrentSchedule);
                                $localstorage.removeItem("CurrentQueue");
                                $state.go('tab.profile');
                            },
                            error: function (error) {
                                $rootScope.showAlert(error.message);
                                if (error.message == "No more bookings in seating.") {
                                    $localstorage.removeItem($scope.CurrentSchedule);
                                    $localstorage.removeItem("CurrentQueue");
                                    $state.go('tab.profile');
                                }
                                $ionicLoading.hide();
                                // error
                            }
                        });
                    } else {
                        console.log('You are not sure');
                    }
                });

            }
            // Clinic list
        $scope.ClinicList = function () {
            if (!$rootScope.NetworkStatus) {} else {
                //$scope.CurrentToken = false;
                $ionicLoading.show();
                Parse.Cloud.run('ClinicList', {
                    DoctorProfile: $rootScope.user.ProfileId
                }, {
                    success: function (status) {
                        if (status.length > 0) {
                            var ln = status.length;
                            for (i = 0; i < ln; i++) {
                                var tmp = {
                                    Name: status[i].get('Name'),
                                    Admin: status[i].get('AdminProfile').id,
                                    Address: status[i].get('Address'),
                                    PinCode: parseInt(status[i].get('Pincode')),
                                    id: status[i].id
                                }
                                $scope.ClinicListdata.push(tmp)
                            }
                            //$scope.ClinicListdata = status;
                            $scope.$apply;
                        }
                        $ionicLoading.hide();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                    }
                });
            }
        };
        $scope.ScheduleList = function (id) {
            if (!$rootScope.NetworkStatus) {} else {
                $scope.CurrentClinic = id;
                $ionicLoading.show();
                Parse.Cloud.run('ScheduleList', {
                    ClinicId: id
                }, {
                    success: function (status) {
                        if (status.length > 0) {
                            $scope.ScheduleListdata = [];
                            var ln = status.length;
                            for (i = 0; i < ln; i++) {
                                var tmp = {
                                    Name: status[i].get('Day') + ' - ' + status[i].get('SlotId') + ' (' + status[i].get('StartSlot') + ' - ' + status[i].get('EndSlot') + ')',
                                    Day: status[i].get('Day'),
                                    SlotId: status[i].get('SlotId'),
                                    EndSlot: status[i].get('EndSlot'),
                                    StartSlot: status[i].get('TokenDuration'),
                                    TokenDuration: status[i].get('TokenDuration'),
                                    id: status[i].id
                                }
                                $scope.ScheduleListdata.push(tmp)
                            }

                            $scope.$apply;
                        }
                        $ionicLoading.hide();
                    },
                    error: function (error) {
                        $scope.ScheduleListdata = [];
                        $ionicLoading.hide();
                    }
                });
            }
        };
        // StartSchedule Tokens
        $scope.StartSchedule = function () {
            if (!$rootScope.NetworkStatus) {} else {
                $ionicLoading.show();
                Parse.Cloud.run('StartScheduleTokens', {
                    ScheduleId: $scope.CurrentSchedule
                }, {
                    success: function (status) {
                        if (status != undefined) {
                            var currentQueue = {
                                Day: $scope.currentDay,
                                CurrentToken: status.get('TokenId'),
                                CurrentSchedule: $scope.CurrentSchedule,
                                CurrentClinic: $scope.CurrentClinic,
                                CurrentTokenPatientName: status.get('PatientProfile').get('FullName')
                            }
                            $localstorage.setObject($scope.CurrentSchedule, currentQueue);
                            $localstorage.setObject('CurrentQueue', currentQueue);
                            $scope.CurrentToken = status.get('TokenId');
                            $scope.CurrentTokenPatientName = status.get('PatientProfile').get('FullName');
                            $scope.CurrentTokenId = status.id;
                            $scope.getTokenList($scope.CurrentSchedule);
                            $scope.$apply;
                        }
                        $ionicLoading.hide();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        $cordovaToast.show(error.message, 'short', 'center')

                    }
                });
            }
        };
        // Schedule Next Token
        $scope.ScheduleNextToken = function (id) {
            if (!$rootScope.NetworkStatus) {} else {
                $ionicLoading.show();
                Parse.Cloud.run('ScheduleNextToken', {
                    ScheduleId: $scope.CurrentSchedule,
                    IsSkip: id,
                    TokenId: $scope.CurrentTokenId
                }, {
                    success: function (status) {
                        if (status != undefined) {
                            var currentQueue = {
                                Day: $scope.currentDay,
                                CurrentToken: status.get('TokenId'),
                                CurrentSchedule: $scope.CurrentSchedule,
                                CurrentClinic: $scope.CurrentClinic,
                                CurrentTokenPatientName: status.get('PatientProfile').get('FullName')
                            }
                            $localstorage.setObject($scope.CurrentSchedule, currentQueue);
                            $localstorage.setObject('CurrentQueue', currentQueue);
                            $scope.CurrentToken = status.get('TokenId');
                            $scope.CurrentTokenPatientName = status.get('PatientProfile').get('FullName');
                            $scope.CurrentTokenId = status.id;
                            $scope.getTokenList($scope.CurrentSchedule);
                            $scope.$apply;
                        }
                        $ionicLoading.hide();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        if (error.message == "No more bookings in seating.") {
                            //$cordovaToast.show('No more bookings,finishing seating', 'short', 'center');
                            var alertPopup = $ionicPopup.show({
                                title: 'CureBooth',
                                template: 'No more bookings,you can finish seating now?',
                                scope: $scope,
                                buttons: [
                                    {
                                        text: 'Add Token'
                                                },
                                    {
                                        text: 'Finish',
                                        type: 'button-assertive',
                                        onTap: function (e) {
                                            return $scope;
                                            console.log(e)
                                        }
                                    }]
                            });
                            alertPopup.then(function (res) {
                                    console.log(res)
                                    if (res) {
                                        $ionicLoading.show();
                                        Parse.Cloud.run('FinishSchedule', {
                                            ScheduleId: $scope.CurrentSchedule,
                                        }, {
                                            success: function (results) {
                                                $ionicLoading.hide();
                                                $localstorage.removeItem($scope.CurrentSchedule);
                                                $localstorage.removeItem("CurrentQueue");
                                                $state.go('tab.profile');
                                            },
                                            error: function (error) {
                                                $rootScope.showAlert(error.message);
                                                if (error.message == "No more bookings in seating.") {
                                                    $localstorage.removeItem($scope.CurrentSchedule);
                                                    $localstorage.removeItem("CurrentQueue");
                                                    $state.go('tab.profile');
                                                }
                                                $ionicLoading.hide();
                                                // error
                                            }
                                        });
                                    } else {
                                        $scope.afterFinish = true;
                                        $scope.addNewToken();

                                    }
                                })
                                /*$localstorage.removeItem($scope.CurrentSchedule);
$localstorage.removeItem("CurrentQueue");
$state.go('tab.profile');*/

                        }
                        //$cordovaToast.show(error.message, 'short', 'center')

                    }
                });
            }
        };
        // Schedule Token Using Id
        $scope.ScheduleTokenUsingId = function (id) {
            if (!$rootScope.NetworkStatus) {} else {
                $ionicLoading.show();
                Parse.Cloud.run('ScheduleTokenUsingId', {
                    ScheduleId: $scope.CurrentSchedule,
                    //IsSkip: "false",
                    TokenId: id
                }, {
                    success: function (status) {
                        if (status != undefined) {
                            $scope.CurrentToken = status.get('TokenId');
                            $scope.CurrentTokenId = status.id;
                            $scope.getTokenList($scope.CurrentSchedule);
                            $scope.$apply;
                        }
                        $ionicLoading.hide();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        $rootScope.showAlert(error.message);
                    }
                });
            }
        };
        // get appointment list 
        $scope.getTokenList = function (id) {
                if (id != null)
                    $scope.CurrentSchedule = id;

                //$cordovaToast.show('Please choose clinic', 'short', 'center')
                if ($localstorage.getObject('DoctorProfile') === null) {} //$ionicLoading.show();
                Parse.Cloud.run('TokenListUsingSchedule', {
                    ScheduleId: $scope.CurrentSchedule
                }, {
                    success: function (results) {
                        $ionicLoading.hide();
                        if (results.length > 0) {
                            $scope.TokenList = []
                            var ln = results.length;
                            for (i = 0; i < ln; i++) {
                                var tmp = '';
                                if (i + 2 < ln) {
                                    //console.log(i + 2)
                                    tmp = results[i].get('Start') + ' - ' + results[i + 2].get('End');
                                } else {
                                    tmp = results[i].get('Start') + ' - ' + results[ln - 1].get('End');
                                }

                                var tmp = {
                                    timestamp: tmp,
                                    id: results[i].id,
                                    ClinicId: results[i].get('ClinicId'),
                                    End: results[i].get('End'),
                                    EndTime: results[i].attributes.EndTime.toString(),
                                    ScheduleId: results[i].get('ScheduleId'),
                                    Start: results[i].get('Start'),
                                    StartTime: results[i].attributes.StartTime.toString(), //.get('StartTime').ios,
                                    Status: results[i].get('Status').get('Name'),
                                    StatusId: results[i].get('Status').id,
                                    TokenId: results[i].get('TokenId'),
                                    TokenType: results[i].get('TokenType')
                                }
                                $scope.TokenList.push(tmp);
                            }
                            /* if ($localstorage.getObject('CurrentQueue') != null) {
                                 //$scope.CurrentToken = $localstorage.getObject('CurrentQueue').CurrentToken;
                                 $scope.CurrentSchedule = $localstorage.getObject('CurrentQueue').CurrentSchedule;
                                 //$scope.CurrentClinic = $localstorage.getObject('CurrentQueue').CurrentClinic;
                                 //$scope.clinicid = $scope.CurrentClinic;
                                 //getTokenList($scope.CurrentSchedule)
                             }*/
                            //console.log($scope.TokenList)
                            var element = document.getElementsByClassName("ActiveToken");
                            if (element.length > 0) {
                                element.scrollIntoView();
                                element.scrollIntoView(false);
                                element.scrollIntoView({
                                    block: "end"
                                });
                                element.scrollIntoView({
                                    block: "end",
                                    behavior: "smooth"
                                });
                            }
                            $scope.$apply();
                        } else {
                            $scope.TokenList = []
                                //$scope.profile.result = null;

                        }
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                        $scope.TokenList = []
                        if (error.code == 209)
                            $state.go('login');
                        //$rootScope.showAlert(error);
                    }
                });
            }
            // Change token for service
        $scope.ChangeToken = function (item) {
            if (!$scope.CurrentToken) {
                //$cordovaToast.show('no connection available', 'short', 'center')
            } else {

                if (item.StatusId == $scope.TokenStatus.Booked && parseInt(item.TokenId.replace(/[A-Z]/g, '')) < parseInt($scope.CurrentToken.replace(/[A-Z]/g, '')) && item.TokenType == 1) {
                    var alertPopup = $ionicPopup.confirm({
                        title: 'CureBooth',
                        template: 'Service Now ?'
                    });
                    alertPopup.then(function (res) {
                        if (res)
                            $scope.ScheduleTokenUsingId(item.id)
                    });
                }

                if (item.StatusId == $scope.TokenStatus.Available && parseInt(item.TokenId.replace(/[A-Z]/g, '')) > parseInt($scope.CurrentToken.replace(/[A-Z]/g, '')) && item.TokenType == 1) {
                    $scope.bookingTokenId = item.id;
                    $scope.openBookAppoitmentModal();
                } else if (item.StatusId == $scope.TokenStatus.Available && parseInt(item.TokenId.replace(/[A-Z]/g, '')) < parseInt($scope.CurrentToken.replace(/[A-Z]/g, '')) && item.TokenType == 1) {
                    $cordovaToast.show('Cannot book previous token', 'short', 'center');
                }


                if ((item.TokenId.replace(/[0-9]/g, '') === 'AZ' && item.TokenType == 2) || (item.TokenId.replace(/[0-9]/g, '') === 'BZ' && item.TokenType == 2) || (item.TokenId.replace(/[0-9]/g, '') === 'CZ' && item.TokenType == 2)) {
                    var alertPopup = $ionicPopup.confirm({
                        title: 'CureBooth',
                        template: 'Service Now ?',
                        /*buttons: [
                            {
                                text: 'Cancel'
                                    }, {
                                text: 'Skip'
                                    }, {
                                text: 'Next'
                                    }]*/
                    });
                    alertPopup.then(function (res) {
                        console.log(res)
                        if (res)
                            $scope.ScheduleTokenUsingId(item.id)
                    });
                } else if (item.StatusId == $scope.TokenStatus.Booked && parseInt(item.TokenId.replace(/[A-Z]/g, '')) > parseInt($scope.CurrentToken.replace(/[A-Z]/g, '')) && item.TokenType == 1) {
                    var alertPopup = $ionicPopup.confirm({
                        title: 'CureBooth',
                        template: 'Do you like to cancel the appointment ?'
                    });
                    alertPopup.then(function (res) {
                        if (res) {
                            $ionicLoading.show();
                            Parse.Cloud.run('CancelAppointment', {
                                TokenId: item.id
                            }, {
                                success: function (results) {
                                    $ionicLoading.hide();
                                    $scope.getTokenList();
                                    // te Profile table updated successfully
                                },
                                error: function (error) {
                                    $rootScope.showAlert(error.message);
                                    $ionicLoading.hide();
                                    // error
                                }
                            });
                        } else {
                            console.log('You are not sure');
                        }
                    });
                }
                //$scope.ScheduleTokenUsingId(item.id)
            }
        }
        $scope.addNewToken = function () {
                $scope.addTokenflag = true;
                $scope.openBookAppoitmentModal();
            }
            // search patient to book for appoitment
        $scope.PatientSearchResult = false;
        $scope.PatientSearchList = [];
        $scope.PatientSearch = function (search) {
            if (!$rootScope.NetworkStatus) {
                $cordovaToast.show('no connection available', 'short', 'center')
            } else {
                if (search.toString().length != 10) {
                    $rootScope.showAlert('Please enter 10 digit mobile number');
                } else {
                    //$ionicLoading.show();
                    Parse.Cloud.run('PatientSearch', {
                        Phone: search
                    }, {
                        success: function (data) {
                            console.log(data.length)
                            $ionicLoading.hide();
                            if (data != undefined) {
                                $scope.PatientSearchList = data;
                                $scope.addnewPatient = false;
                                $scope.PatientSearchResult = true;
                            } else {
                                $scope.PatientSearchList = [];
                                $scope.addnewPatient = true;
                                $scope.PatientSearchResult = false;
                                $scope.Patient.phone = search;
                            }
                            $scope.$apply;
                        },
                        error: function (error) {
                            console.log(error)
                            $scope.PatientList = null
                            $scope.PatientSearchResult = false;
                            $scope.addnewPatient = true;
                            $scope.Patient.phone = search;
                            $ionicLoading.hide();
                        }
                    });
                }
            }
        };
        // validate new patient request
        $scope.Validate = function () {
            var ErrorArr = new Array();
            if (typeof $scope.user === 'undefined' || $scope.user === null)
                throw ' entered';
            else {
                if (typeof $scope.Patient.Name === 'undefined' || $scope.Patient.Name === null) {
                    $rootScope.showAlert('Please enter some valid value into - Name.');
                    ErrorArr.push('name.');
                }
                /* else if (typeof $scope.Patient.email === 'undefined' || $scope.Patient.email === null) {
                                    $rootScope.showAlert('Please enter some valid value into - Email');
                                    ErrorArr.push('Client \'Surname\' is required.');
                                }*/
                else if (typeof $scope.Patient.phone === 'undefined' || $scope.Patient.phone === null) {
                    $rootScope.showAlert("Please enter Phone number");
                    ErrorArr.push('number.');
                }

            }
            if (ErrorArr.length > 0)
                return false;

            return true; //_isValidVM
        }

        $scope.AddNewPatient = function () {
                if (!$rootScope.NetworkStatus) {
                    $cordovaToast.show('no connection available', 'short', 'center')
                } else {
                    if ($scope.Validate()) {
                        $ionicLoading.show();
                        Parse.Cloud.run('AddNewPatient', {
                            DoctorUserId: $rootScope.user.id,
                            DoctorProfileId: $rootScope.UserProfile.objectId,
                            Phone: $scope.Patient.phone,
                            Name: $scope.Patient.Name,
                            Email: $scope.Patient.email,
                        }, {
                            success: function (results) {
                                $ionicLoading.hide();
                                if (results != undefined) {
                                    $scope.Patient = []
                                    var item = {}
                                    item.objectId = results.id;
                                    $scope.addnewPatient = false;
                                    $scope.BookAppointment(item);
                                    PatientSearchResult
                                    /*var alertPopup = $ionicPopup.alert({
                                        title: 'CureBooth',
                                        template: 'Patient added successfully'
                                    });
                                    alertPopup.then(function (res) {
                                        $state.go('tab.home');
                                    });*/

                                    //$scope.closeBookAppoitmentModal();
                                    //$scope.FriendRequest = results;
                                } else {
                                    $scope.FriendRequest = null;
                                }

                                // te Profile table updated successfully
                            },
                            error: function (error) {
                                $rootScope.showAlert(error.message);
                                $ionicLoading.hide();
                                // error
                            }
                        });
                    }
                }
            }
            // BookAppointment

        $scope.BookAppointment = function (item) {
            if (!$rootScope.NetworkStatus) {} else {
                if ($scope.addTokenflag) {
                    Parse.Cloud.run('AddTokenInSchedule', {
                        ScheduleId: $scope.CurrentSchedule,
                        BookedProfile: item.objectId,
                        afterFinish: $scope.afterFinish
                    }, {
                        success: function (status) {
                            if (status != undefined) {
                                $scope.addnewPatient = false;
                                $scope.addTokenflag = false;
                                $scope.getTokenList();
                                $scope.closeBookAppoitmentModal();
                                if ($scope.afterFinish) {
                                    var currentQueue = {
                                        Day: $scope.currentDay,
                                        CurrentToken: status.get('TokenId'),
                                        CurrentSchedule: $scope.CurrentSchedule,
                                        CurrentClinic: $scope.CurrentClinic,
                                        CurrentTokenPatientName: status.get('PatientProfile').get('FullName')
                                    }
                                    $localstorage.setObject($scope.CurrentSchedule, currentQueue);
                                    $localstorage.setObject('CurrentQueue', currentQueue);
                                    $scope.CurrentToken = status.get('TokenId');
                                    $scope.CurrentTokenPatientName = status.get('PatientProfile').get('FullName');
                                    $scope.CurrentTokenId = status.id;
                                }
                                $scope.$apply;
                            }
                            $ionicLoading.hide();
                        },
                        error: function (error) {
                            $ionicLoading.hide();
                            $rootScope.showAlert(error.message);
                            $scope.closeBookAppoitmentModal();
                        }
                    });
                } else {
                    Parse.Cloud.run('BookAppointment', {
                        TokenId: $scope.bookingTokenId,
                        isQueue: true,
                        BookedProfile: item.objectId
                    }, {
                        success: function (status) {
                            if (status != undefined) {
                                $scope.getTokenList();
                                $scope.closeBookAppoitmentModal();
                                $scope.$apply;
                            }
                            $ionicLoading.hide();
                        },
                        error: function (error) {
                            $ionicLoading.hide();
                        }
                    });
                }
            }
        };
        $ionicModal.fromTemplateUrl('bookAppoitment.html', {
            scope: $scope,
            animation: 'fade-in-up'
        }).then(function (modal) {
            $scope.bookAppoitmentModal = modal;
        });
        $scope.openBookAppoitmentModal = function () {
            if ($rootScope.NetworkStatus) {
                $scope.PatientSearchResult = false;
                $scope.addnewPatient = false;
                $scope.PatientSearchList = [];
                $scope.search = [];
                $scope.bookAppoitmentModal.show();
            } else
                $cordovaToast.show('no connection available', 'short', 'center')

        };
        $scope.closeBookAppoitmentModal = function () {
            $scope.PatientSearchList = [];
            $scope.bookAppoitmentModal.hide();
        };
        //Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function () {
            $scope.bookAppoitmentModal.remove();
        });
        // Intialize the controller 
        if ($rootScope.NetworkStatus) {
            $scope.ClinicList();
            if (($localstorage.getObject('CurrentQueue') != null || $localstorage.getObject('CurrentQueue').length > 0) && $localstorage.getObject('CurrentQueue').Day == $scope.currentDay) {
                $scope.CurrentToken = $localstorage.getObject('CurrentQueue').CurrentToken;
                $scope.CurrentTokenPatientName = $localstorage.getObject('CurrentQueue').CurrentTokenPatientName;
                $scope.CurrentSchedule = $localstorage.getObject('CurrentQueue').CurrentSchedule;
                $scope.CurrentClinic = $localstorage.getObject('CurrentQueue').CurrentClinic;
                $scope.clinicid = $scope.CurrentClinic;
                $scope.ScheduleList($scope.CurrentClinic)
                $scope.sceduleId = $scope.CurrentSchedule;
                $scope.getTokenList($scope.sceduleId);
            } else {
                //$scope.CurrentToken = null;
                // $scope.CurrentSchedule = null;
                //$scope.CurrentClinic = null;
            }
        } else {

        }
    });

    cbApp.controller('ClinicDetailsCtrl', function ($scope, $state, $filter, $ionicLoading, $rootScope,$ionicModal, $http, $ionicPopup, $localstorage, $ionicHistory, $localstorage, ionicMaterialInk) {
        $scope.Cliniceditable = false;
        $scope.clinic = $rootScope.ClinicData;
        var now = new Date();
        $scope.currentDay = now.getDay();
        $scope.editClinic = function (id) {
            $scope.Cliniceditable = id;
        }
        $rootScope.$ionicGoBack = function () {
            console.log('heheheh back pressed')
            $scope.myGoBack();
        };
        $scope.myGoBack = function () {
            $state.go("tab.profile")
        };
        $scope.addSchedule = function () {
                $rootScope.ScheduleClinic = $scope.clinic.id
                $rootScope.ClinicScheduleData = $scope.ClinicListWithSchedule;
                $state.go("tab.AddClinicSchedule")
            }
            // update Clinic
        $scope.UpdateClinic = function (data) {
            if (!$rootScope.NetworkStatus) {} else {
                $ionicLoading.show();
                if (data.Pincode.length < 4) {
                    $rootScope.showAlert("Please enter PinCode");
                } else {
                    Parse.Cloud.run('UpdateClinic', {
                        ClinicId: data.id,
                        DoctorProfile: $rootScope.user.ProfileId,
                        Name: data.Name,
                        Address: data.Address,
                        Area: data.area,
                        City: data.city,
                        AdminProfile: data.Admin,
                        Pincode: data.Pincode.toString(),
                        ConsultationFee: data.ConsultationFee
                    }, {
                        success: function (results) {
                            $ionicLoading.hide();
                            if (results) {
                                $scope.Cliniceditable = false;
                                $cordovaToast.show('Clinic updated successfully', 'short', 'center');
                                $scope.$apply;
                            }
                        },
                        error: function (error) {
                            $ionicLoading.hide();
                            $rootScope.showAlert(error.message);
                        }
                    });
                }
            }
        }
        $scope.ClinicListWithSchedule = function () {
            if (!$rootScope.NetworkStatus) {} else {
                Parse.Cloud.run('ClinicListWithSchedule', {
                    DoctorProfile: $rootScope.user.ProfileId,
                    ClinicId: $scope.clinic.id
                }, {
                    success: function (status) {
                        if (status.length > 0) {
                            var ln = status.length;
                            var start = status[0].get('StartSlot');
                            var end = status[0].get('EndSlot');
                            $scope.tmpdata = [];
                            var clinic = {}
                            $scope.ClinicListWithSchedule = [];
                            var sun = []
                            var mon = []
                            var tue = []
                            var wed = []
                            var thu = []
                            var fri = []
                            var sat = []
                            for (i = 0; i < ln; i++) {
                                switch (status[i].get('DayId')) {
                                case 0:
                                    var tmp1 = {
                                        start: formatTimeToAMPM(status[i].get('StartSlot')),
                                        end: formatTimeToAMPM(status[i].get('EndSlot')),
                                        start1: status[i].get('StartSlot'),
                                        end1: status[i].get('EndSlot'),
                                        TokenDuration: status[i].get('TokenDuration'),
                                        SlotId: status[i].get('SlotId')
                                    }
                                    sun.push(tmp1);
                                    break;
                                case 1:
                                    var tmp2 = {
                                        start: formatTimeToAMPM(status[i].get('StartSlot')),
                                        end: formatTimeToAMPM(status[i].get('EndSlot')),
                                        start1: status[i].get('StartSlot'),
                                        end1: status[i].get('EndSlot'),
                                        TokenDuration: status[i].get('TokenDuration'),
                                        SlotId: status[i].get('SlotId')
                                    }
                                    mon.push(tmp2);
                                    break;
                                case 2:
                                    var tmp3 = {
                                        start: formatTimeToAMPM(status[i].get('StartSlot')),
                                        end: formatTimeToAMPM(status[i].get('EndSlot')),
                                        start1: status[i].get('StartSlot'),
                                        end1: status[i].get('EndSlot'),
                                        TokenDuration: status[i].get('TokenDuration'),
                                        SlotId: status[i].get('SlotId')
                                    }
                                    tue.push(tmp3);
                                    break;
                                case 3:
                                    var tmp4 = {
                                        start: formatTimeToAMPM(status[i].get('StartSlot')),
                                        end: formatTimeToAMPM(status[i].get('EndSlot')),
                                        start1: status[i].get('StartSlot'),
                                        end1: status[i].get('EndSlot'),
                                        TokenDuration: status[i].get('TokenDuration'),
                                        SlotId: status[i].get('SlotId')
                                    }
                                    wed.push(tmp4);
                                    break;
                                case 4:
                                    var tmp5 = {
                                        start: formatTimeToAMPM(status[i].get('StartSlot')),
                                        end: formatTimeToAMPM(status[i].get('EndSlot')),
                                        start1: status[i].get('StartSlot'),
                                        end1: status[i].get('EndSlot'),
                                        TokenDuration: status[i].get('TokenDuration'),
                                        SlotId: status[i].get('SlotId')
                                    }
                                    thu.push(tmp5);
                                    break;
                                case 5:
                                    var tmp6 = {
                                        start: formatTimeToAMPM(status[i].get('StartSlot')),
                                        end: formatTimeToAMPM(status[i].get('EndSlot')),
                                        start1: status[i].get('StartSlot'),
                                        end1: status[i].get('EndSlot'),
                                        TokenDuration: status[i].get('TokenDuration'),
                                        SlotId: status[i].get('SlotId')
                                    }
                                    fri.push(tmp6);
                                    break;
                                case 6:
                                    var tmp7 = {
                                        start: formatTimeToAMPM(status[i].get('StartSlot')),
                                        end: formatTimeToAMPM(status[i].get('EndSlot')),
                                        start1: status[i].get('StartSlot'),
                                        end1: status[i].get('EndSlot'),
                                        TokenDuration: status[i].get('TokenDuration'),
                                        SlotId: status[i].get('SlotId')
                                    }
                                    sat.push(tmp7);
                                    break;
                                }


                            }
                            var t1 = {
                                Day: "Sunday",
                                Dayid: "0",
                                schedule: sun
                            }
                            $scope.ClinicListWithSchedule.push(t1)
                            var t2 = {
                                Day: "Monday",
                                Dayid: "1",
                                schedule: mon
                            }
                            $scope.ClinicListWithSchedule.push(t2)
                            var t3 = {
                                Day: "Tuesday",
                                Dayid: "2",
                                schedule: tue
                            }
                            $scope.ClinicListWithSchedule.push(t3)
                            var t4 = {
                                Day: "Wednesday",
                                Dayid: "3",
                                schedule: wed
                            }
                            $scope.ClinicListWithSchedule.push(t4)
                            var t5 = {
                                Day: "Thursday",
                                Dayid: "4",
                                schedule: thu
                            }
                            $scope.ClinicListWithSchedule.push(t5)
                            var t6 = {
                                Day: "Friday",
                                Dayid: "5",
                                schedule: fri
                            }
                            $scope.ClinicListWithSchedule.push(t6)
                            var t7 = {
                                Day: "Saturday",
                                Dayid: "6",
                                schedule: sat
                            }
                            $scope.ClinicListWithSchedule.push(t7)
                            console.log($scope.ClinicListWithSchedule);

                            $scope.$apply;
                        }
                        $ionicLoading.hide();
                    },
                    error: function (error) {
                        $ionicLoading.hide();
                    }
                });
            }
        };

        function formatTimeToAMPM(date) {
            var hours = date.split(":")[0];
            var minutes = date.split(":")[1];
            var ampm = hours >= 12 ? 'PM' : 'AM';
            hours = hours % 12;
            hours = hours ? hours : 12;
            var strTime = hours + ':' + minutes + ' ' + ampm;
            return strTime;
        }
        /*Show Clinic Details*/
        $ionicModal.fromTemplateUrl('ClinicTiming.html', {
            scope: $scope,
            animation: 'fade-in-up'
        }).then(function (modal) {
            $scope.ClinicTimingModal = modal;
        });
        $scope.showallTimings = function () {
            $scope.ClinicTimingModal.show();
        };
        $scope.closeClinicTimingModal = function () {
            $scope.PatientSearchList = [];
            $scope.ClinicTimingModal.hide();
        };
        //Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function () {
            $scope.ClinicTimingModal.remove();
        });
        if ($rootScope.NetworkStatus) {
            $scope.ClinicListWithSchedule();
            $scope.AdminList = $localstorage.getObject('AdminDoctorList');
        } else {
            $scope.AdminList = $localstorage.getObject('AdminDoctorList');
        }
    });